</div> <!-- نهاية container -->

<!-- Bootstrap Bundle (ضروري للتبويبات والمودال) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


<!-- Modal تعليمات التثبيت اليدوي (للأيفون أو المتصفحات غير المدعومة) -->
<div class="modal fade" id="pwaGuideModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content text-center p-4 border-0 shadow">
            <h5 class="fw-bold text-primary mb-3"><i class="fas fa-download me-2"></i> طريقة تثبيت التطبيق</h5>
            <p class="text-muted">لتثبيت التطبيق على شاشة هاتفك بسهولة:</p>
            
            <div class="text-start bg-light p-3 rounded-3 mb-3 fs-6">
                <p class="mb-2"><b>لأجهزة الأندرويد (Chrome):</b><br> اضغط على قائمة الخيارات (<b>⋮</b>) أعلى المتصفح ثم اختر <b>"الإضافة إلى الشاشة الرئيسية"</b> أو <b>"تثبيت التطبيق"</b>.</p>
                <hr>
                <p class="mb-0"><b>لأجهزة الأيفون (Safari):</b><br> اضغط على زر المشاركة ( <i class="fas fa-share-square"></i> ) أسفل الشاشة ثم اختر <b>"إضافة إلى الشاشة الرئيسية"</b>.</p>
            </div>
            
            <button type="button" class="btn btn-secondary w-100 fw-bold" data-bs-dismiss="modal">إغلاق</button>
        </div>
    </div>
</div>

<script>
let deferredPrompt;
const installBtn = document.getElementById('pwaInstallBtn');

// تسجيل الـ Service Worker
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(err => console.log(err));
}

// التقاط حدث التثبيت التلقائي إذا كان متاحاً
window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
});

// عند الضغط على الزر
installBtn.addEventListener('click', () => {
    if (deferredPrompt) {
        // إذا كان المتصفح يوفر نافذة تثبيت جاهزة
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then((choiceResult) => {
            deferredPrompt = null;
        });
    } else {
        // إذا لم توجد نافذة جاهزة (مثلاً iPhone أو متصفح يحظر التثبيت المباشر)
        const guideModal = new bootstrap.Modal(document.getElementById('pwaGuideModal'));
        guideModal.show();
    }
});
</script>
</body>
</html>
