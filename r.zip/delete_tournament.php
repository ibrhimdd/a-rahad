<?php
include 'db.php';
include 'header.php';

// التحقق من صلاحيات المدير (Admin)
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "<div class='container py-5'><div class='alert alert-danger text-center'>عذراً، هذه الصفحة مخصصة للمشرفين فقط.</div></div>";
    include 'footer.php';
    exit;
}

// جلب وتأمين رقم البطولة
$t_id = isset($_GET['id']) ? (int)$_GET['id'] : (isset($_GET['tour_id']) ? (int)$_GET['tour_id'] : 0);

if ($t_id <= 0) {
    echo "<div class='container py-5'><div class='alert alert-danger text-center'>لم يتم تحديد البطولة بشكل صحيح.</div></div>";
    include 'footer.php';
    exit;
}

// 1. جلب تفاصيل البطولة للتحقق من وجودها
$stmt = $conn->prepare("SELECT * FROM tournaments WHERE id = ?");
$stmt->bind_param("i", $t_id);
$stmt->execute();
$tournament = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$tournament) {
    echo "<div class='container py-5'><div class='alert alert-danger text-center'>البطولة غير موجودة بالنظام.</div></div>";
    include 'footer.php';
    exit;
}

$error_msg = "";
$success_msg = "";

// 2. معالجة الحذف عند التأكيد
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
    
    // بدء Transaction للضمان
    $conn->begin_transaction();

    try {
        // أ. حذف إحصائيات تقييم اللاعبين في مباريات البطولة
        $stmt1 = $conn->prepare("DELETE ps FROM player_match_stats ps JOIN matches m ON ps.match_id = m.id WHERE m.tournament_id = ?");
        $stmt1->bind_param("i", $t_id);
        $stmt1->execute();
        $stmt1->close();

        // ب. حذف الأهداف المسجلة في مباريات البطولة
        $stmt2 = $conn->prepare("DELETE g FROM goals g JOIN matches m ON g.match_id = m.id WHERE m.tournament_id = ?");
        $stmt2->bind_param("i", $t_id);
        $stmt2->execute();
        $stmt2->close();

        // ج. حذف التوقعات المرتبطة بمباريات البطولة
        $stmt3 = $conn->prepare("DELETE p FROM predictions p JOIN matches m ON p.match_id = m.id WHERE m.tournament_id = ?");
        $stmt3->bind_param("i", $t_id);
        $stmt3->execute();
        $stmt3->close();

        // د. حذف نقاط المتوقعين الخاصة بالبطولة
        $stmt4 = $conn->prepare("DELETE FROM user_tournament_points WHERE tournament_id = ?");
        $stmt4->bind_param("i", $t_id);
        $stmt4->execute();
        $stmt4->close();

        // هـ. حذف كافة مباريات البطولة
        $stmt5 = $conn->prepare("DELETE FROM matches WHERE tournament_id = ?");
        $stmt5->bind_param("i", $t_id);
        $stmt5->execute();
        $stmt5->close();

        // و. حذف البطولة نفسها
        $stmt6 = $conn->prepare("DELETE FROM tournaments WHERE id = ?");
        $stmt6->bind_param("i", $t_id);
        $stmt6->execute();
        $stmt6->close();

        // اعتماد التغييرات
        $conn->commit();
        $success_msg = "تم حذف البطولة بجميع مبارياتها وإحصائياتها بنجاح.";
        
    } catch (Exception $e) {
        // إلغاء التغييرات في حال حدوث خطأ
        $conn->rollback();
        $error_msg = "حدث خطأ أثناء الحذف: " . $e->getMessage();
    }
}

// 3. حساب إجمالي المباريات المسجلة للبطولة
$stmt_m_count = $conn->prepare("SELECT COUNT(id) as total_matches FROM matches WHERE tournament_id = ?");
$stmt_m_count->bind_param("i", $t_id);
$stmt_m_count->execute();
$total_matches = $stmt_m_count->get_result()->fetch_assoc()['total_matches'] ?? 0;
$stmt_m_count->close();
?>

<style>
    body { background-color: #f8fafc; font-family: 'Cairo', sans-serif; direction: rtl; text-align: right; }
    .delete-card { border-radius: 16px; border: 1px solid #fee2e2; }
    .warning-icon { font-size: 3rem; color: #dc3545; }
</style>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-7">
            
            <?php if (!empty($success_msg)): ?>
                <div class="card border-0 shadow-sm rounded-4 text-center p-4">
                    <div class="text-success mb-3"><i class="fas fa-check-circle fa-4x"></i></div>
                    <h4 class="fw-bold mb-3"><?php echo $success_msg; ?></h4>
                    <div class="mt-3">
                        <a href="tournaments.php" class="btn btn-primary rounded-pill px-4">العودة لقائمة البطولات</a>
                    </div>
                </div>
            <?php else: ?>

                <?php if (!empty($error_msg)): ?>
                    <div class="alert alert-danger text-center rounded-3 mb-4"><?php echo $error_msg; ?></div>
                <?php endif; ?>

                <div class="card border-0 shadow-sm delete-card bg-white p-4 text-center">
                    <div class="warning-icon mb-2">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    
                    <h3 class="fw-bold text-danger mb-3">تأكيد حذف البطولة</h3>
                    <p class="text-muted fs-6 mb-4">
                        هل أنت تأكد من رغبتك في حذف بطولة <strong class="text-dark"><?php echo htmlspecialchars($tournament['name']); ?></strong>؟
                    </p>

                    <div class="alert alert-warning text-end mb-4">
                        <div class="fw-bold mb-2"><i class="fas fa-info-circle me-1"></i> تنبيه: إجراء الحذف سيؤدي إلى مسح البيانات التالية نهائياً:</div>
                        <ul class="mb-0 ps-3">
                            <li>جميع المباريات المجدولة والمنتهية (إجمالي <strong><?php echo $total_matches; ?></strong> مباراة).</li>
                            <li>سجلات الأهداف وصناعة الأهداف وتقييمات اللاعبين.</li>
                            <li>توقعات المستخدمين والنقاط المسجلة لهذه البطولة.</li>
                        </ul>
                    </div>

                    <form method="POST" action="">
                        <div class="d-flex justify-content-center gap-3">
                            <button type="submit" name="confirm_delete" class="btn btn-danger rounded-pill px-4 fw-bold">
                                <i class="fas fa-trash-alt me-1"></i> تأكيد الحذف النهائي
                            </button>
                            <a href="tournament_details.php?id=<?php echo $t_id; ?>" class="btn btn-secondary rounded-pill px-4 fw-bold">
                                إلغاء
                            </a>
                        </div>
                    </form>
                </div>

            <?php endif; ?>

        </div>
    </div>
</div>

<?php include 'footer.php'; ?>