<?php
// إعدادات السيرفر
$host   = "sql100.infinityfree.com";
$user   = "if0_41044340";
$pass   = "uGcZolvXP7yzX";
$dbname = "if0_41044340_dbanm";

// 1. الاتصال بنظام MySQLi (عشان يشغل ملفاتك القديمة اللي بتستخدم $conn)
$conn = new mysqli($host, $user, $pass, $dbname);

// التأكد من نجاح اتصال mysqli
if ($conn->connect_error) {
    die("خطأ في اتصال MySQLi: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// 2. الاتصال بنظام PDO (عشان يشغل التقارير والرسائل الذكية والـ $pdo)
try {
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("خطأ في اتصال PDO: " . $e->getMessage());
}

// كدة الملف ده بيقدم "خدمتين" في نفس الوقت: $conn و $pdo
?>