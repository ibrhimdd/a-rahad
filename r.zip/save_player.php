<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $player_name  = mysqli_real_escape_string($conn, $_POST['player_name']);
    $team_id      = intval($_POST['team_id']);
    $position     = mysqli_real_escape_string($conn, $_POST['position']);
    
    // 💡 استقبال رقم القميص
    $shirt_number = !empty($_POST['shirt_number']) ? intval($_POST['shirt_number']) : "NULL";

    // معالجة رفع الصورة
    $image_name = "default.png";
    if (!empty($_FILES['player_image']['name'])) {
        $image_name = time() . '_' . $_FILES['player_image']['name'];
        move_uploaded_file($_FILES['player_image']['tmp_name'], "uploads/players/" . $image_name);
    }

    // 💡 إضافة shirt_number للاستعلام
    $query = "INSERT INTO players (player_name, team_id, position, shirt_number, image) 
              VALUES ('$player_name', $team_id, '$position', $shirt_number, '$image_name')";

    if (mysqli_query($conn, $query)) {
        // إعادة التوجيه لصفحة الفريق بعد الحفظ بنجاح
        header("Location: team_profile.php?id=" . $team_id);
        exit;
    } else {
        echo "حدث خطأ أثناء الحفظ: " . mysqli_error($conn);
    }
}
?>