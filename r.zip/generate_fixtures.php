<?php
include 'db.php';
<?php include 'check_admin.php'; ?>
if (isset($_POST['generate_league'])) {
    $tournament_id = $_POST['tournament_id'];
    $teams = $_POST['teams']; // مصفوفة تحتوي على IDs الفرق المشتركة

    if (count($teams) % 2 != 0) {
        $teams[] = null; // إضافة فريق وهمي (Bye) إذا كان العدد فردياً
    }

    $num_teams = count($teams);
    $num_rounds = $num_teams - 1;

    for ($round = 0; $round < $num_rounds; $round++) {
        for ($i = 0; $i < $num_teams / 2; $i++) {
            $home = $teams[$i];
            $away = $teams[$num_teams - 1 - $i];

            if ($home !== null && $away !== null) {
                // إدخال المباراة في قاعدة البيانات
                $query = "INSERT INTO matches (tournament_id, team_home_id, team_away_id, match_date, referee, commentator, status) 
                          VALUES ('$tournament_id', '$home', '$away', NULL, 'سيحدد لاحقاً', 'سيحدد لاحقاً', 'pending')";
                mysqli_query($conn, $query);
            }
        }
        // تدوير الفرق (Round Robin rotation)
        $last_team = array_pop($teams);
        array_splice($teams, 1, 0, [$last_team]);
    }
    echo "تم توليد جدول الدوري بنجاح!";
}
?>