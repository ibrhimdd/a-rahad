<?php
include 'db.php';
// تأكد من أن الأدمن فقط هو من يطلب هذه الصفحة
include 'check_admin.php'; 

// 1. تحديد الجداول التي لا تريد مسحها
$excluded_tables = ['teams', 'users', 'players'];

// 2. جلب جميع جداول قاعدة البيانات
$tables_query = mysqli_query($conn, "SHOW TABLES");
$all_tables = [];

while ($row = mysqli_fetch_array($tables_query)) {
    $all_tables[] = $row[0];
}

// 3. إيقاف التحقق من القيود (Foreign Key Checks) عشان الجداول المترابطة تتمسح بدون مشاكل
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 0");

$deleted_count = 0;
foreach ($all_tables as $table) {
    // التحقق إذا كان الجدول الحالي ليس ضمن المستثنيات
    if (!in_array($table, $excluded_tables)) {
        // TRUNCATE تمسح البيانات وتصفر الـ ID (Auto-increment)
        if (mysqli_query($conn, "TRUNCATE TABLE `$table`")) {
            $deleted_count++;
        }
    }
}

// 4. إعادة تفعيل التحقق من القيود
mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 1");

echo "<div style='direction:rtl; text-align:center; margin-top:50px; font-family:Tahoma;'>";
echo "<h2>تمت عملية الفرمتة بنجاح!</h2>";
echo "<p>تم مسح بيانات $deleted_count جدول.</p>";
echo "<p>الجداول المستثناة (لم تُمسح): " . implode(', ', $excluded_tables) . "</p>";
echo "<br><a href='index.php'>العودة للرئيسية</a>";
echo "</div>";
?>