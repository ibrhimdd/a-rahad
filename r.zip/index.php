<?php 
include 'db.php'; 

// 1. ضبط المنطقة الزمنية في PHP و MySQL (توقيت مصر)
date_default_timezone_set('Africa/Cairo');
$conn->query("SET time_zone = '+02:00'"); // أو '+03:00' حسب التوقيت الصيفي/الشتوي الحالي

include 'header.php'; 

// 2. تحديد الفلاتر
$filter      = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$date_filter = isset($_GET['date']) ? $_GET['date'] : '';
$day_btn     = isset($_GET['day']) ? $_GET['day'] : 'all'; 

$where_clauses = ["1=1"];

// فلتر حالة المباراة
if ($filter == 'finished') { 
    $where_clauses[] = "(matches.status = 'finished' OR matches.is_finished = 1)"; 
} elseif ($filter == 'upcoming') { 
    $where_clauses[] = "(matches.status = 'upcoming' AND matches.is_finished = 0)"; 
} elseif ($filter == 'live') { 
    $where_clauses[] = "matches.status = 'live'"; 
}

// 3. حساب التواريخ داخل PHP لضمان دقة التوقيت بغض النظر عن سيرفر الاستضافة
$today_date     = date('Y-m-d');
$yesterday_date = date('Y-m-d', strtotime('-1 day'));
$tomorrow_date  = date('Y-m-d', strtotime('+1 day'));

if ($day_btn == 'today') { 
    $where_clauses[] = "DATE(matches.match_date) = '$today_date'"; 
} elseif ($day_btn == 'yesterday') { 
    $where_clauses[] = "DATE(matches.match_date) = '$yesterday_date'"; 
} elseif ($day_btn == 'tomorrow') { 
    $where_clauses[] = "DATE(matches.match_date) = '$tomorrow_date'"; 
} else {
    $where_clauses[] = "matches.match_date IS NOT NULL AND matches.match_date != '0000-00-00 00:00:00'";
}

// فلتر اختيار تاريخ محدد من الـ Input
if (!empty($date_filter)) { 
    $where_clauses[] = "DATE(matches.match_date) = '" . mysqli_real_escape_string($conn, $date_filter) . "'"; 
}

$where_sql = " WHERE " . implode(" AND ", $where_clauses);
$sql = "SELECT matches.*, 
               COALESCE(t1.team_name, 'فريق غير محدد') AS h_team, 
               COALESCE(t1.logo, 'default.png') AS h_logo, 
               COALESCE(t2.team_name, 'فريق غير محدد') AS a_team, 
               COALESCE(t2.logo, 'default.png') AS a_logo, 
               COALESCE(tournaments.name, 'بطولات أخرى') AS tour_name
        FROM matches 
        LEFT JOIN teams t1 ON matches.team_home_id = t1.id 
        LEFT JOIN teams t2 ON matches.team_away_id = t2.id
        LEFT JOIN tournaments ON matches.tournament_id = tournaments.id 
        $where_sql
        ORDER BY matches.match_date ASC, matches.id DESC";

$result = mysqli_query($conn, $sql);

// 2. تجميع المباريات حسب البطولة
$grouped_matches = [];
if ($result) {
    while($row = mysqli_fetch_assoc($result)) {
        $t_name = !empty($row['tour_name']) ? $row['tour_name'] : 'بطولات أخرى';
        $grouped_matches[$t_name][] = $row;
    }
}

// فحص وجود دالة الأدمن لتجنب Fatal Error في حال عدم تعريفها
$is_admin_user = function_exists('isAdmin') ? isAdmin() : (isset($_SESSION['role']) && $_SESSION['role'] == 'admin');
?>

<style>
    body { background-color: #f4f7f6; font-family: 'Cairo', sans-serif; direction: rtl; }
    
    /* تنسيق أزرار الأيام الرئيسية */
    .day-selector .btn {
        border-radius: 12px;
        padding: 8px 20px;
        font-weight: bold;
        transition: 0.3s;
        border: 2px solid #1a2a6c;
        color: #1a2a6c;
        background: #1a2238;
    }
    .day-selector .btn.active {
        background: #1a2a6c;
        color: #ffffff;
        box-shadow: 0 4px 15px rgba(26, 42, 108, 0.3);
    }
    .day-selector .btn:hover:not(.active) {
        background: #1a2a6c;
        color: #ffffff;
    }

    /* تنسيق أقسام البطولات */
    .tour-card-header {
        border-right: 6px solid #1a2a6c;
        padding: 10px 20px;
        background: #fff;
        margin-bottom: 20px;
        border-radius: 0 10px 10px 0;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    }
    
    .match-card {
        border-radius: 15px;
        border: none;
        transition: 0.3s;
    }
    .match-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important; }
    
    .team-img { width: 55px; height: 55px; object-fit: contain; }
    .score-box { background: #1a221a; border-radius: 10px; min-width: 90px; padding: 10px; }

    /* أنيميشن الحالات للمباريات المباشرة */
    .pulse-live {
        animation: pulse 1.5s infinite;
    }
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.5; }
        100% { opacity: 1; }
    }
</style>

<div class="container py-4">
    <div class="row mb-4 align-items-center">
        <div class="col-md-6">
            <h2 class="fw-bold" style="color: #1a2a6c;">📅 جدول المباريات</h2>
        </div>
        <div class="col-md-6 text-md-start">
            <form action="matches.php" method="GET" class="d-flex gap-2 justify-content-md-end">
                <input type="date" name="date" class="form-control form-control-sm w-auto rounded-3" value="<?php echo htmlspecialchars($date_filter); ?>">
                <button type="submit" class="btn btn-dark btn-sm rounded-3 px-4">بحث بالتاريخ</button>
            </form>
        </div>
    </div>

    <!-- أزرار الاختيار السريع للأيام -->
    <div class="day-selector d-flex justify-content-center flex-wrap gap-2 mb-5">
        <a href="matches.php?day=all" class="btn <?php echo $day_btn=='all'?'active':''; ?>">الكل</a>
        <a href="matches.php?day=yesterday" class="btn <?php echo $day_btn=='yesterday'?'active':''; ?>">أمس</a>
        <a href="matches.php?day=today" class="btn <?php echo $day_btn=='today'?'active':''; ?>">اليوم</a>
        <a href="matches.php?day=tomorrow" class="btn <?php echo $day_btn=='tomorrow'?'active':''; ?>">غداً</a>
    </div>

    <?php if (empty($grouped_matches)): ?>
        <div class="text-center py-5 bg-white rounded-4 shadow-sm">
            <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
            <p class="text-muted fw-bold fs-5 mb-0">لا توجد مباريات متاحة لهذا الفلتر أو التاريخ.</p>
        </div>
    <?php else: ?>

        <!-- أزرار فلترة البطولات -->
        <div class="text-center mb-4">
            <div class="btn-group flex-wrap justify-content-center gap-2">
                <button class="btn btn-sm btn-primary rounded-pill filter-tour-btn active" data-target="all">جميع البطولات</button>
                <?php foreach(array_keys($grouped_matches) as $t_name): ?>
                    <button class="btn btn-sm btn-outline-secondary rounded-pill filter-tour-btn" data-target="tour-<?php echo md5($t_name); ?>">
                        <?php echo htmlspecialchars($t_name); ?>
                    </button>
                <?php endforeach; ?>
            </div>
        </div>

        <div id="matches-wrapper">
            <?php foreach($grouped_matches as $tour_name => $matches): 
                $tour_id = md5($tour_name); 
            ?>
                <div class="tour-group tour-container" id="tour-<?php echo $tour_id; ?>">
                    <div class="tour-card-header animate__animated animate__fadeInRight">
                        <h5 class="m-0 fw-bold text-primary"><i class="fas fa-trophy ms-2"></i> <?php echo htmlspecialchars($tour_name); ?></h5>
                    </div>
                    
                    <div class="row g-4 mb-5">
                        <?php foreach($matches as $m): 
                            // حساب أبعاد الحالة
                            $m_status    = $m['status'] ?? 'upcoming';
                            $is_finished = ($m_status === 'finished' || (int)$m['is_finished'] === 1);
                            $is_live     = ($m_status === 'live');

                            $has_date    = !empty($m['match_date']) && $m['match_date'] != '0000-00-00 00:00:00';
                            $m_time      = $has_date ? date('H:i', strtotime($m['match_date'])) : 'غير محدد';
                            $m_date      = $has_date ? date('d/m', strtotime($m['match_date'])) : '';
                        ?>
                            <div class="col-lg-6">
                                <div class="card match-card shadow-sm">
                                    <div class="card-body py-4">
                                        <div class="row align-items-center text-center">
                                            <!-- الفريق الأول -->
                                            <div class="col-4">
                                                <img src="uploads/logos/<?php echo htmlspecialchars($m['h_logo']); ?>" 
                                                     class="team-img mb-2" 
                                                     onerror="this.src='uploads/logos/default.png';">
                                                <div class="fw-bold small"><?php echo htmlspecialchars($m['h_team']); ?></div>
                                            </div>

                                            <!-- النتيجة أو التوقيت -->
                                            <div class="col-4">
                                                <div class="score-box border">
                                                    <?php if($is_live): ?>
                                                        <h4 class="fw-bold m-0 text-danger"><?php echo (int)$m['score_home']; ?> - <?php echo (int)$m['score_away']; ?></h4>
                                                        <small class="text-danger fw-bold pulse-live" style="font-size: 11px;"><i class="fas fa-circle me-1" style="font-size:8px;"></i> مباشر الآن</small>
                                                    <?php elseif($is_finished): ?>
                                                        <h4 class="fw-bold m-0"><?php echo (int)$m['score_home']; ?> - <?php echo (int)$m['score_away']; ?></h4>
                                                        <small class="text-secondary fw-bold" style="font-size: 11px;">انتهت</small>
                                                    <?php else: ?>
                                                        <h5 class="fw-bold m-0 text-primary"><?php echo $m_time; ?></h5>
                                                        <?php if($m_date): ?>
                                                            <small class="text-white d-block fw-bold" style="font-size: 10px; font-color"><?php echo $m_date; ?></small>
                                                        <?php endif; ?>
                                                        <small class="text-success fw-bold" style="font-size: 10px;">قادمة</small>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <!-- الفريق الثاني -->
                                            <div class="col-4">
                                                <img src="uploads/logos/<?php echo htmlspecialchars($m['a_logo']); ?>" 
                                                     class="team-img mb-2" 
                                                     onerror="this.src='uploads/logos/default.png';">
                                                <div class="fw-bold small"><?php echo htmlspecialchars($m['a_team']); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer bg-transparent border-0 d-flex gap-2 pb-3">
                                        <a href="match_details.php?id=<?php echo $m['id']; ?>" class="btn btn-outline-primary btn-sm w-100 rounded-pill"><i class="fas fa-info-circle me-1"></i> التفاصيل</a>
                                        
                                        <!-- زر التوقع للمباريات القادمة فقط -->
                                        <?php if(!$is_finished && !$is_live): ?>
                                            <a href="predict.php?match_id=<?php echo $m['id']; ?>" class="btn btn-warning btn-sm w-100 rounded-pill fw-bold"><i class="fas fa-bullhorn me-1"></i> توقّع</a>
                                        <?php endif; ?>

                                        <?php if($is_admin_user && !$is_finished): ?>
                                            <a href="finish_match.php?id=<?php echo $m['id']; ?>" class="btn btn-success btn-sm w-100 rounded-pill">رصد</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<script>
// جافاسكريبت للتبديل بين البطولات
document.querySelectorAll('.filter-tour-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.filter-tour-btn').forEach(b => {
            b.classList.remove('active', 'btn-primary');
            b.classList.add('btn-outline-secondary');
        });
        this.classList.add('active', 'btn-primary');
        this.classList.remove('btn-outline-secondary');

        const target = this.getAttribute('data-target');
        const groups = document.querySelectorAll('.tour-container');

        if(target === 'all') {
            groups.forEach(g => g.style.display = 'block');
        } else {
            groups.forEach(g => {
                g.style.display = (g.id === target) ? 'block' : 'none';
            });
        }
    });
});
</script>

<?php include 'footer.php'; ?>