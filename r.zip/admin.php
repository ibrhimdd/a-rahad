<?php include 'db.php'; include 'header.php'; ?>
<?php include 'check_admin.php'; ?>
<div class="container py-5">
    <div class="text-center mb-5">
        <h1 class="fw-bold text-primary"><i class="fas fa-user-shield"></i> لوحة الإدارة الشاملة</h1>
        <p class="text-muted">تحكم في كل تفاصيل نظامك الرياضي من مكان واحد</p>
    </div>

    <div class="row g-4">
        <div class="col-md-4">
            <div class="card h-100 shadow-sm border-0">
                <div class="card-header bg-danger text-white text-center fw-bold">إدارة المنافسات</div>
                <div class="card-body">
                    <div class="list-group">
                        <a href="add_tournament.php" class="list-group-item list-group-item-action border-0">
                            <i class="fas fa-trophy text-warning me-2"></i> إنشاء بطولة جديدة
                        </a>
                        <a href="add_match.php" class="list-group-item list-group-item-action border-0">
                            <i class="fas fa-calendar-plus text-danger me-2"></i> جدولة مباراة جديدة
                        </a>
                        <a href="generate_tournament.php" class="list-group-item list-group-item-action border-0">
                     <i class="fas fa-calendar-plus text-danger me-2"></i> جدولة مباراة  بطولة 
                    </a>    
                        <a href="matches.php" class="list-group-item list-group-item-action border-0">
                            <i class="fas fa-list-ul text-primary me-2"></i> قائمة المباريات الحالية
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card h-100 shadow-sm border-0">
                <div class="card-header bg-primary text-white text-center fw-bold">الأندية والنجوم</div>
                <div class="card-body">
                    <div class="list-group">
                        <a href="add_team.php" class="list-group-item list-group-item-action border-0">
                            <i class="fas fa-shield-alt text-primary me-2"></i> إضافة فريق جديد
                        </a>
                        <a href="add_player.php" class="list-group-item list-group-item-action border-0">
                            <i class="fas fa-user-plus text-success me-2"></i> تسجيل لاعب جديد
                        </a>
                        <a href="players.php" class="list-group-item list-group-item-action border-0">
                            <i class="fas fa-users text-secondary me-2"></i> عرض جميع اللاعبين
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card h-100 shadow-sm border-0">
                <div class="card-header bg-dark text-white text-center fw-bold">الطاقم الفني والإداري</div>
                <div class="card-body">
                    <div class="list-group">
                        <a href="add_official.php" class="list-group-item list-group-item-action border-0">
                            <i class="fas fa-whistle text-info me-2"></i> إضافة (حكم / معلق)
                        </a>
                        <div class="mt-3 px-3">
                            <small class="text-muted d-block mb-2">إحصائيات سريعة:</small>
                            <?php 
                                $res_ref = mysqli_query($conn, "SELECT COUNT(*) as total FROM officials WHERE role='referee'");
                                $res_com = mysqli_query($conn, "SELECT COUNT(*) as total FROM officials WHERE role='commentator'");
                            ?>
                            <span class="badge bg-info me-1">الحكام: <?php echo mysqli_fetch_assoc($res_ref)['total']; ?></span>
                            <span class="badge bg-secondary">المعلقين: <?php echo mysqli_fetch_assoc($res_com)['total']; ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-5">
        <div class="col-12">
            <div class="bg-white p-4 rounded shadow-sm d-flex justify-content-around align-items-center text-center">
                <div>
                    <h3 class="fw-bold mb-0"><?php echo mysqli_num_rows(mysqli_query($conn, "SELECT id FROM teams")); ?></h3>
                    <small class="text-muted">فريق مسجل</small>
                </div>
                <div class="vr"></div>
                <div>
                    <h3 class="fw-bold mb-0"><?php echo mysqli_num_rows(mysqli_query($conn, "SELECT id FROM matches WHERE status='finished'")); ?></h3>
                    <small class="text-muted">مباراة مكتملة</small>
                </div>
                <div class="vr"></div>
                <div>
                    <h3 class="fw-bold mb-0"><?php echo mysqli_num_rows(mysqli_query($conn, "SELECT id FROM goals")); ?></h3>
                    <small class="text-muted">هدف مسجل</small>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>