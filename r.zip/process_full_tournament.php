<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tournament_id = (int)$_POST['tournament_id'];

    // --- أولاً: إنشاء مباريات المجموعات ---
    if (isset($_POST['group_teams'])) {
        foreach ($_POST['group_teams'] as $groupId => $teams_array) {
            $group_label = $_POST['group_names'][$groupId][0]; 
            $group_teams = array_filter($teams_array);
            $group_teams = array_values($group_teams);
            $count = count($group_teams);

            for ($i = 0; $i < $count; $i++) {
                for ($j = $i + 1; $j < $count; $j++) {
                    $home = $group_teams[$i];
                    $away = $group_teams[$j];

                    $sql = "INSERT INTO matches (tournament_id, group_name, team_home_id, team_away_id, match_type, is_finished) 
                            VALUES ($tournament_id, '$group_label', $home, $away, 'group', 0)";
                    mysqli_query($conn, $sql);
                }
            }
        }
    }

    // --- ثانياً: إنشاء هيكل الأدوار النهائية (الـ Bracket) ---
    // سنستخدم R1 للدور الأول بعد المجموعات، R2 للدور التالي وهكذا
    $round = 1;
    while (isset($_POST["match_r{$round}_home"])) {
        foreach ($_POST["match_r{$round}_home"] as $match_num => $home_src) {
            $away_src = $_POST["match_r{$round}_away"][$match_num];
            
            // تخزين المصدر (مثل G1_1) في أعمدة home_source و away_source
            $sql_bracket = "INSERT INTO matches (tournament_id, match_type, home_source, away_source, round_level, is_finished) 
                            VALUES ($tournament_id, 'knockout', '$home_src', '$away_src', $round, 0)";
            mysqli_query($conn, $sql_bracket);
        }
        $round++;
    }

    header("Location: tournament_dashboard.php?id=$tournament_id");
}