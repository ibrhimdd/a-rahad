<?php
include 'db.php';
include 'header.php';

// التأكد من تسجيل دخول المستخدم
if (!isset($_SESSION['user_id'])) {
    echo "<div class='container py-5 text-center'><div class='alert alert-warning'>عذراً، يجب عليك تسجيل الدخول أولاً لرؤية التوقعات والنقاط.</div></div>";
    include 'footer.php';
    exit;
}

$user_id = intval($_SESSION['user_id']);

// 1. جلب إجمالي نقاط المستخدم
$total_points = 0;
$points_q = mysqli_query($conn, "SELECT SUM(total_points) AS grand_total FROM user_tournament_points WHERE user_id = $user_id");

if ($points_q && $p_row = mysqli_fetch_assoc($points_q)) {
    $total_points = (int)$p_row['grand_total'];
}

// 2. جلب سجل توقعات المستخدم مع تفاصيل المباريات والفرق
$sql_preds = "SELECT p.*, 
                     m.match_date, m.score_home, m.score_away, m.status, m.is_finished,
                     t1.team_name AS h_team, t1.logo AS h_logo,
                     t2.team_name AS a_team, t2.logo AS a_logo,
                     tour.name AS tour_name
              FROM predictions p
              JOIN matches m ON p.match_id = m.id
              LEFT JOIN teams t1 ON m.team_home_id = t1.id
              LEFT JOIN teams t2 ON m.team_away_id = t2.id
              LEFT JOIN tournaments tour ON m.tournament_id = tour.id
              WHERE p.user_id = $user_id
              ORDER BY p.id DESC";

$preds_result = mysqli_query($conn, $sql_preds);

// حماية ضد استعلامات SQL الخاطئة لتجنب Fatal Error
if (!$preds_result) {
    echo "<div class='container py-5'><div class='alert alert-danger text-center'>";
    echo "<strong>خطأ في قاعدة البيانات:</strong> " . mysqli_error($conn);
    echo "</div></div>";
    include 'footer.php';
    exit;
}
?>

<style>
    body { background-color: #0f172a; color: #f8fafc; font-family: 'Cairo', sans-serif; direction: rtl; }
    .card-custom { background-color: #1e293b; border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; }
    .stat-box { background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border: 1px solid #00d285; border-radius: 16px; }
    .team-img-sm { width: 35px; height: 35px; object-fit: contain; }
    .badge-result { font-size: 0.85rem; padding: 6px 12px; border-radius: 20px; }
</style>

<div class="container py-4">
    
    <!-- كارت إحصائيات النقاط والرصيد -->
    <div class="row mb-4">
        <div class="col-md-6 mx-auto">
            <div class="stat-box p-4 text-center shadow-lg">
                <h5 class="text-muted mb-2"><i class="fas fa-trophy text-warning me-2"></i> مركز التوقعات</h5>
                <h2 class="fw-bold mb-1" style="color: #00d285;"><?php echo $total_points; ?> <span class="fs-6 text-white">نقطة</span></h2>
                <small class="text-secondary">إجمالي نقاطك المستحقة من التوقعات الصحيحة</small>
            </div>
        </div>
    </div>

    <h4 class="fw-bold mb-3"><i class="fas fa-history me-2 text-primary"></i> سجل توقعاتك</h4>

    <?php if (mysqli_num_rows($preds_result) == 0): ?>
        <div class="card-custom p-5 text-center shadow-sm">
            <i class="fas fa-bullhorn fa-3x text-muted mb-3"></i>
            <p class="text-muted fw-bold fs-5 mb-0">لم تقم بإجراء أي توقعات حتى الآن.</p>
        </div>
    <?php else: ?>
        <div class="row g-3">
            <?php while($row = mysqli_fetch_assoc($preds_result)): 
                $pred_text = '';
                if ($row['predicted_result'] == 'home_win') $pred_text = 'فوز ' . $row['h_team'];
                elseif ($row['predicted_result'] == 'away_win') $pred_text = 'فوز ' . $row['a_team'];
                elseif ($row['predicted_result'] == 'draw') $pred_text = 'تعادل الفريقين';

                $is_finished = $row['is_finished'] || $row['status'] == 'finished';
            ?>
                <div class="col-md-6">
                    <div class="card-custom p-3 shadow-sm">
                        <div class="d-flex justify-content-between align-items-center mb-2 pb-2 border-bottom border-secondary">
                            <span class="badge bg-secondary"><?php echo htmlspecialchars($row['tour_name'] ?? 'بطولة'); ?></span>
                            <small class="text-muted"><?php echo date('d/m/Y - h:i A', strtotime($row['match_date'])); ?></small>
                        </div>

                        <!-- تفاصيل المباراة -->
                        <div class="row align-items-center text-center my-2">
                            <div class="col-5">
                                <img src="uploads/logos/<?php echo htmlspecialchars($row['h_logo']); ?>" class="team-img-sm mb-1" onerror="this.src='uploads/logos/default.png';">
                                <div class="fw-bold small"><?php echo htmlspecialchars($row['h_team']); ?></div>
                            </div>
                            <div class="col-2">
                                <span class="fw-bold text-muted fs-6">VS</span>
                            </div>
                            <div class="col-5">
                                <img src="uploads/logos/<?php echo htmlspecialchars($row['a_logo']); ?>" class="team-img-sm mb-1" onerror="this.src='uploads/logos/default.png';">
                                <div class="fw-bold small"><?php echo htmlspecialchars($row['a_team']); ?></div>
                            </div>
                        </div>

                        <!-- تفاصيل التوقع والنقاط -->
                        <div class="d-flex justify-content-between align-items-center mt-3 pt-2 bg-dark rounded p-2">
                            <div>
                                <small class="text-muted d-block" style="font-size: 11px;">توقعك:</small>
                                <span class="fw-bold text-warning small"><?php echo $pred_text; ?></span>
                            </div>

                            <div>
                                <?php if (!$is_finished): ?>
                                    <span class="badge bg-info text-dark badge-result">في الانتظار ⏳</span>
                                <?php else: ?>
                                    <?php if ($row['points_awarded'] > 0): ?>
                                        <span class="badge bg-success badge-result">+<?php echo $row['points_awarded']; ?> نقاط 🎯</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger badge-result">توقع خاطئ ❌</span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php endif; ?>

</div>

<?php include 'footer.php'; ?>