<?php 
include 'db.php'; 
include 'header.php'; 

// استقبال id البطولة من الرابط
$t_id = isset($_GET['tour_id']) ? intval($_GET['tour_id']) : 0;

// 1. حفظ مباراة واحدة فقط منفردة
if (isset($_POST['save_single'])) {
    $m_id = intval($_POST['single_m_id']);
    $m_date = !empty($_POST['m_date_single']) ? $_POST['m_date_single'] : NULL;
    $m_ref_id = intval($_POST['m_ref_id_single']);
    $m_com = trim($_POST['m_com_single']);
    $m_stadium = trim($_POST['m_stadium_single']);

    $status = !empty($m_date) ? 'upcoming' : 'pending';

    $stmt_single = $conn->prepare("UPDATE matches SET match_date = ?, referee_id = ?, commentator = ?, stadium = ?, status = ? WHERE id = ? AND tournament_id = ?");
    $stmt_single->bind_param("sisssii", $m_date, $m_ref_id, $m_com, $m_stadium, $status, $m_id, $t_id);
    
    if ($stmt_single->execute()) {
        echo "<script>alert('تم حفظ بيانات المباراة بنجاح!'); window.location='?tour_id=$t_id';</script>";
    }
    $stmt_single->close();
}

// 2. حفظ كافة التعديلات دفعة واحدة
if (isset($_POST['save_all'])) {
    if (isset($_POST['m_id']) && is_array($_POST['m_id'])) {
        $stmt_all = $conn->prepare("UPDATE matches SET match_date = ?, referee_id = ?, commentator = ?, stadium = ?, status = ? WHERE id = ? AND tournament_id = ?");

        foreach ($_POST['m_id'] as $index => $id) {
            $m_id = intval($id);
            $m_date = !empty($_POST['m_date'][$index]) ? $_POST['m_date'][$index] : NULL;
            $m_ref_id = intval($_POST['m_ref_id'][$index]);
            $m_com = trim($_POST['m_com'][$index]);
            $m_stadium = trim($_POST['m_stadium'][$index]);
            
            $status = !empty($m_date) ? 'upcoming' : 'pending';

            $stmt_all->bind_param("sisssii", $m_date, $m_ref_id, $m_com, $m_stadium, $status, $m_id, $t_id);
            $stmt_all->execute();
        }
        $stmt_all->close();
        echo "<script>alert('تم حفظ ونشر جدول البطولة بنجاح!'); window.location='tournament_dashboard.php?id=$t_id';</script>";
    }
}

// 3. جلب الحكام والمعلقين من جدول officials
$officials_list = [];
$res_off = mysqli_query($conn, "SELECT id, name FROM officials ORDER BY name ASC");
if ($res_off && mysqli_num_rows($res_off) > 0) {
    while($row = mysqli_fetch_assoc($res_off)) {
        $officials_list[] = $row;
    }
}
?>

<div class="container py-4" style="direction: rtl; text-align: right;">
    <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
        <!-- Header -->
        <div class="card-header bg-dark text-white p-4 d-flex justify-content-between align-items-center">
            <div>
                <h4 class="mb-1 fw-bold text-warning"><i class="fas fa-calendar-alt me-2"></i>تجهيز جدول مباريات البطولة</h4>
                <small class="text-white-50">يمكنك تحديد موعد أي مباراة بشكل منفصل أو تحديد المواعيد دفعة واحدة</small>
            </div>
            <span class="badge bg-warning text-dark fs-6 px-3 py-2 rounded-pill shadow-sm">بطولة #<?php echo $t_id; ?></span>
        </div>
        
        <div class="card-body p-4 bg-light">
            <form method="POST" id="mainScheduleForm">
                <div class="table-responsive rounded-3 bg-white shadow-sm border">
                    <table class="table table-hover align-middle mb-0 text-center custom-schedule-table">
                        <thead>
                            <tr>
                                <th class="p-3">المباراة / الدور</th>
                                <th class="p-3" style="width: 22%;">التاريخ والوقت</th>
                                <th class="p-3" style="width: 18%;">الحكم</th>
                                <th class="p-3" style="width: 18%;">المعلق</th>
                                <th class="p-3" style="width: 18%;">الملعب</th>
                                <th class="p-3" style="width: 10%;">إجراء</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $stmt_matches = $conn->prepare("
                                SELECT m.*, t1.team_name as h_name, t2.team_name as a_name 
                                FROM matches m 
                                LEFT JOIN teams t1 ON m.team_home_id = t1.id 
                                LEFT JOIN teams t2 ON m.team_away_id = t2.id 
                                WHERE m.tournament_id = ? 
                                ORDER BY m.match_type DESC, m.round_level ASC, m.group_name ASC
                            ");
                            $stmt_matches->bind_param("i", $t_id);
                            $stmt_matches->execute();
                            $query = $stmt_matches->get_result();

                            if ($query && $query->num_rows > 0):
                                while($row = $query->fetch_assoc()): 
                                    $home_display = !empty($row['h_name']) ? $row['h_name'] : "<span class='badge bg-light text-primary border'>".$row['home_source']."</span>";
                                    $away_display = !empty($row['a_name']) ? $row['a_name'] : "<span class='badge bg-light text-primary border'>".$row['away_source']."</span>";
                                    
                                    // ضبط صيغة الوقت للعرض بدون فرض قيمة إجبارية عند الفراغ
                                    $current_date = ($row['match_date'] != '0000-00-00 00:00:00' && $row['match_date'] != NULL) 
                                                    ? date('Y-m-d\TH:i', strtotime($row['match_date'])) 
                                                    : '';
                                ?>
                            <tr class="<?php echo !empty($current_date) ? 'row-scheduled' : 'row-pending'; ?>">
                                <!-- اسم المباراة والدور -->
                                <td class="p-3 text-start ps-4">
                                    <input type="hidden" name="m_id[]" value="<?php echo $row['id']; ?>">
                                    <div class="fw-bold fs-6 mb-1 text-white">
                                        <?php echo $home_display; ?> <span class="text-danger mx-1">×</span> <?php echo $away_display; ?>
                                    </div>
                                    <small class="badge bg-secondary-subtle text-secondary fw-normal">
                                        <?php 
                                            if($row['match_type'] == 'group') echo "المجموعة: " . htmlspecialchars($row['group_name']);
                                            else echo "الدور الإقصائي: " . htmlspecialchars($row['round_level']);
                                        ?>
                                    </small>
                                </td>

                                <!-- التاريخ والوقت -->
                                <td>
                                    <input type="datetime-local" name="m_date[]" 
                                           value="<?php echo $current_date; ?>" 
                                           class="form-control form-control-sm border shadow-sm text-center">
                                </td>

                                <!-- الحكم -->
                                <td>
                                    <select name="m_ref_id[]" class="form-select form-select-sm border shadow-sm">
                                        <option value="0">اختر الحكم</option>
                                        <?php foreach($officials_list as $off): ?>
                                            <option value="<?php echo $off['id']; ?>" <?php echo ($off['id'] == $row['referee_id']) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($off['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>

                                <!-- المعلق -->
                                <td>
                                    <select name="m_com[]" class="form-select form-select-sm border shadow-sm">
                                        <option value="يحدد لاحقاً">اختر المعلق</option>
                                        <?php foreach($officials_list as $off): ?>
                                            <option value="<?php echo htmlspecialchars($off['name']); ?>" <?php echo ($off['name'] == $row['commentator']) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($off['name']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>

                                <!-- الملعب -->
                                <td>
                                    <input type="text" name="m_stadium[]" 
                                           value="<?php echo ($row['stadium'] == '' || $row['stadium'] == 'يحدد لاحقاً') ? 'ملعب احمد رشاد' : htmlspecialchars($row['stadium']); ?>" 
                                           class="form-control form-control-sm border shadow-sm text-center">
                                </td>

                                <!-- زر حفظ المباراة المنفردة -->
                                <td>
                                    <button type="submit" 
                                            formaction="?tour_id=<?php echo $t_id; ?>" 
                                            onclick="saveSingleMatch(this, <?php echo $row['id']; ?>)" 
                                            class="btn btn-sm btn-outline-success fw-bold rounded-3 px-3 shadow-sm"
                                            title="حفظ هذه المباراة فقط">
                                        <i class="fas fa-check"></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-5">
                                    <div class="text-muted">
                                        <i class="fas fa-calendar-times fa-3x mb-3 text-secondary"></i>
                                        <p class="mb-0 fs-6">لا توجد مباريات منشأة لهذه البطولة. يرجى التأكد من توليد الجدول أولاً.</p>
                                    </div>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <?php if ($query && $query->num_rows > 0): ?>
                    <!-- مدخلات مخفية للحفظ المنفرد -->
                    <input type="hidden" name="single_m_id" id="single_m_id" value="">
                    <input type="hidden" name="m_date_single" id="m_date_single" value="">
                    <input type="hidden" name="m_ref_id_single" id="m_ref_id_single" value="">
                    <input type="hidden" name="m_com_single" id="m_com_single" value="">
                    <input type="hidden" name="m_stadium_single" id="m_stadium_single" value="">
                    <input type="hidden" name="save_single" id="save_single_btn" value="" disabled>

                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <a href="tournament_dashboard.php?id=<?php echo $t_id; ?>" class="btn btn-outline-secondary rounded-pill px-4 fw-bold">
                            <i class="fas fa-arrow-right ms-2"></i>العودة للوحة التحكم
                        </a>
                        <button type="submit" name="save_all" class="btn btn-success btn-lg px-5 shadow-sm fw-bold rounded-pill">
                            <i class="fas fa-save ms-2"></i>حفظ الجدول بالكامل ونشره
                        </button>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>

<script>
// دالة لالتقاط بيانات الصف المحدد عند ضغط زر الحفظ المنفصل
function saveSingleMatch(btn, matchId) {
    const row = btn.closest('tr');
    
    document.getElementById('single_m_id').value = matchId;
    document.getElementById('m_date_single').value = row.querySelector('[name="m_date[]"]').value;
    document.getElementById('m_ref_id_single').value = row.querySelector('[name="m_ref_id[]"]').value;
    document.getElementById('m_com_single').value = row.querySelector('[name="m_com[]"]').value;
    document.getElementById('m_stadium_single').value = row.querySelector('[name="m_stadium[]"]').value;
    
    const singleInput = document.getElementById('save_single_btn');
    singleInput.disabled = false;
    singleInput.value = "1";
}
</script>

<style>
    /* تنسيقات رأس الجدول */
    .custom-schedule-table thead {
        background-color: #1e293b !important;
        color: #ffffff !important;
    }
    .custom-schedule-table thead th {
        font-weight: 600;
        font-size: 0.88rem;
        border: none;
    }

    /* ألوان وقراءة عناصر المدخلات */
    .custom-schedule-table .form-control, 
    .custom-schedule-table .form-select {
        background-color: #ffffff !important;
        color: #0f172a !important;
        font-size: 0.85rem;
        border-color: #cbd5e1 !important;
    }

    .custom-schedule-table .form-control:focus, 
    .custom-schedule-table .form-select:focus {
        border-color: #0d6efd !important;
        box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.15) !important;
    }

    /* تمييز الصفوف المحددة والجديدة */
    .row-scheduled {
        background-color: #f8fafc;
    }
    .row-pending {
        background-color: #fffba615;
    }
    
    .custom-schedule-table tbody tr:hover {
        background-color: #f1f5f9 !important;
    }

    tbody td { 
        font-size: 0.88rem; 
        vertical-align: middle;
    }
</style>

<?php include 'footer.php'; ?>