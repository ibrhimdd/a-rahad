<?php
// بدء الجلسة
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// الاتصال بقاعدة البيانات لتمكين جلب الرعاة (إذا لم تكن متصلة مسبقاً)
if (file_exists('db.php') && !isset($conn)) {
    include_once 'db.php';
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function isLogged() {
    return isset($_SESSION['user_id']);
}

// تحديد الصفحة الحالية لإضافة لون تمييز للرابط النشط (Active)
$current_page = basename($_SERVER['PHP_SELF']);

// جلب الرعاة المعلنين النشطين من قاعدة البيانات
$sponsors_list = [];
if (isset($conn)) {
    $sponsors_query = $conn->query("SELECT * FROM sponsors WHERE is_active = 1 ORDER BY id DESC");
    if ($sponsors_query) {
        while ($sp = $sponsors_query->fetch_assoc()) {
            $sponsors_list[] = $sp;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=100%, initial-scale=0.85, maximum-scale=3.0, user-scalable=yes">

    <title>ملعب أحمد رشاد - إدارة البطولات</title>

    <!-- Bootstrap RTL -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">

    <!-- Icons & Animations -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

    <!-- Google Font & Dark Theme Styles -->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap');

        /* توحيد لون النصوص باللون الأبيض على مستوى الصفحة ككل */
        body, p, h1, h2, h3, h4, h5, h6, span, a, div, th, td, label, input, button {
            color: #ffffff !important;
        }

        /* خلفية الموقع الأساسية */
        body {
            background-color: #121829 !important;
            font-family: 'Cairo', sans-serif;
            padding-bottom: 75px;
        }

        /* ---------------------------------------------------- */
        /*   تنسيقات الشريط العلوي المتحرك (Ticker)             */
        /* ---------------------------------------------------- */
        .sponsor-ticker-wrapper {
            background: #0d121d;
            border-bottom: 1px solid #ffc107;
            overflow: hidden;
            white-space: nowrap;
            position: relative;
            display: flex;
            align-items: center;
            height: 38px;
            z-index: 1040;
        }
        .sponsor-ticker-label {
            background: #ffc107;
            color: #121829 !important;
            font-weight: 800;
            padding: 0 12px;
            height: 100%;
            display: flex;
            align-items: center;
            z-index: 3;
            box-shadow: 2px 0 10px rgba(0,0,0,0.5);
            font-size: 0.8rem;
            flex-shrink: 0;
        }
        .sponsor-ticker-track {
            display: inline-block;
            white-space: nowrap;
            animation: ticker-ltr 25s linear infinite;
        }
        .sponsor-ticker-wrapper:hover .sponsor-ticker-track {
            animation-play-state: paused; /* إيقاف الحركة عند تحريك الماوس فوق الشريط */
        }
        .sponsor-item {
            display: inline-block;
            margin: 0 20px;
            color: #e0e6ed !important;
            font-weight: 700;
            font-size: 0.85rem;
            text-decoration: none;
            transition: color 0.2s;
        }
        .sponsor-item:hover {
            color: #00d285 !important;
        }
        .sponsor-icon {
            color: #ffc107 !important;
            margin-left: 6px;
        }

        /* أنيميشن الحركة السلسة من اليسار إلى اليمين LTR */
        @keyframes ticker-ltr {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        /* الهيدر العلوي */
        .top-header {
            background: #1a2238 !important;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
            padding: 10px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .user-avatar {
            width: 32px;
            height: 32px;
            background: #00d285;
            color: #121829 !important;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-left: 8px;
        }

        /* الشريط السفلي (Bottom Navigation Bar) */
        .bottom-nav-bar {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: #1a2238;
            box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.5);
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            z-index: 1030;
            height: 65px;
            display: flex;
            align-items: center;
            justify-content: space-around;
            padding: 0 2px;
        }

        .bottom-nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            flex: 1;
            text-decoration: none;
            color: #ffffff !important;
            font-size: 0.68rem;
            font-weight: 700;
            transition: all 0.2s ease-in-out;
            padding: 4px 0;
            border: none;
            background: none;
        }

        .bottom-nav-item i {
            font-size: 1.15rem;
            margin-bottom: 3px;
            color: #ffffff !important;
            transition: all 0.2s ease-in-out;
        }

        /* العنصر النشط بلمسة تركواز */
        .bottom-nav-item.active,
        .bottom-nav-item.active i,
        .bottom-nav-item.active span {
            color: #00d285 !important;
        }

        .bottom-nav-item.active i {
            transform: translateY(-2px);
        }

        /* التنسيق العام للكروت والقوائم */
        .card, .stat-card {
            background-color: #1a2238 !important;
            color: #ffffff !important;
            border: 1px solid rgba(255, 255, 255, 0.05) !important;
        }

        .card-header {
            background-color: #222b45 !important;
            color: #ffffff !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
        }

        .dropdown-menu {
            background-color: #1a2238;
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }

        .dropdown-item {
            color: #ffffff !important;
        }

        .dropdown-item:hover {
            background-color: #222b45;
            color: #00d285 !important;
        }

        .text-danger {
            color: #ff4d4d !important;
        }

        /* إصلاح المودال */
        .modal-backdrop { opacity: 0.7 !important; }
        .modal { z-index: 1055; }
        
        .table {
            color: #ffffff !important;
            background-color: transparent !important;
            border-color: rgba(255, 255, 255, 0.08) !important;
        }

        .table th, .table td {
            background-color: #1a2238 !important;
            color: #ffffff !important;
            border-color: rgba(255, 255, 255, 0.05) !important;
        }

        .table-hover tbody tr:hover td {
            background-color: #222b45 !important;
            color: #00d285 !important;
        }
    </style>
    
    <style>
        /* 📱 تحسين عرض المحتوى على شاشات الموبايل */
        @media (max-width: 768px) {
            html {
                font-size: 88% !important; 
            }

            .container, .container-fluid {
                padding-left: 10px !important;
                padding-right: 10px !important;
            }

            .py-5 {
                padding-top: 1.5rem !important;
                padding-bottom: 1.5rem !important;
            }

            .row.g-4 {
                --bs-gutter-y: 0.75rem !important;
                --bs-gutter-x: 0.75rem !important;
            }
        }
    </style>
</head>
<body>

<!-- حاوية تثبيت الشريط والهيدر معاً في الأعلى -->
<div class="sticky-top">

    <!-- 1. الشريط العلوي المتحرك للرعاة -->
    <?php if (!empty($sponsors_list)): ?>
    <div class="sponsor-ticker-wrapper">
        <div class="sponsor-ticker-label">
            <i class="fas fa-bullhorn me-1"></i> الرعاة والرعايات
        </div>
        <div class="sponsor-ticker-track">
            <?php foreach ($sponsors_list as $sponsor): ?>
                <a href="<?php echo htmlspecialchars($sponsor['link'] ?: '#'); ?>" target="_blank" class="sponsor-item">
                    <i class="fas fa-star sponsor-icon"></i>
                    <?php echo htmlspecialchars($sponsor['title']); ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- 2. الهيدر العلوي: الشعار ومعلومات الحساب -->
    <header class="top-header">
        <div class="container d-flex align-items-center justify-content-between">
            <a class="navbar-brand text-white fw-bold m-0" href="index.php">
                <i class="fas fa-trophy text-warning me-2"></i> ملعب أحمد رشاد
            </a>

            <div class="d-flex align-items-center">
                <?php if(isLogged()): ?>
                    <div class="dropdown">
                        <a class="btn btn-outline-light rounded-pill dropdown-toggle d-flex align-items-center px-3 border-0 bg-dark-subtle" href="#" data-bs-toggle="dropdown">
                            <span class="user-avatar">
                                <?php echo mb_substr($_SESSION['username'], 0, 1, 'utf-8'); ?>
                            </span>
                            <span class="fw-bold small text-white"><?php echo $_SESSION['username']; ?></span>
                        </a>

                        <ul class="dropdown-menu dropdown-menu-end shadow mt-2">
                            <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-circle me-2"></i>ملفي الشخصي</a></li>
                            <li><a class="dropdown-item" href="predictions.php"><i class="fas fa-bullhorn me-2 text-warning"></i>توقعاتي ورصيدي</a></li>
                            <li><a class="dropdown-item" href="user_points.php"><i class="fas fa-medal me-2 text-success"></i>جدول الترتيب والنقاط</a></li>
                            <?php if(isAdmin()): ?>
                                <li><hr class="dropdown-divider border-secondary"></li>
                                <li><a class="dropdown-item" href="admin_sponsors.php"><i class="fas fa-ad me-2"></i>إدارة الرعاة</a></li>
                                <li><a class="dropdown-item" href="add_match.php"><i class="fas fa-plus me-2"></i>إضافة مباراة</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider border-secondary"></li>
                            <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>تسجيل الخروج</a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="btn btn-outline-light btn-sm rounded-pill px-3 me-2">دخول</a>
                    <a href="register.php" class="btn btn-success btn-sm rounded-pill px-3 fw-bold" style="background-color: #00d285; border: none; color: #121829 !important;">اشتراك</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

</div>

<!-- الشريط السفلي (Bottom Navigation) -->
<nav class="bottom-nav-bar">
    <a href="matches.php" class="bottom-nav-item <?php echo ($current_page == 'matches.php') ? 'active' : ''; ?>">
        <i class="fas fa-futbol"></i>
        <span>المباريات</span>
    </a>

   

    <a href="tournaments_list.php" class="bottom-nav-item <?php echo ($current_page == 'tournaments_list.php') ? 'active' : ''; ?>">
        <i class="fas fa-trophy"></i>
        <span>البطولات</span>
    </a>

    <a href="players.php" class="bottom-nav-item <?php echo ($current_page == 'players.php') ? 'active' : ''; ?>">
        <i class="fas fa-users"></i>
        <span>اللاعبين</span>
    </a>
    <a href="teams.php" class="bottom-nav-item <?php echo ($current_page == 'teams.php') ? 'active' : ''; ?>">
        <i class="fas fa-shield-alt"></i>
        <span>الفرق</span>
    </a>

    <?php if(isAdmin()): ?>
        <div class="dropup">
            <button class="bottom-nav-item dropdown-toggle border-0 bg-transparent <?php echo in_array($current_page, ['admin.php', 'setup_matches.php', 'reset_db.php', 'admin_sponsors.php']) ? 'active' : ''; ?>" type="button" data-bs-toggle="dropdown">
                <i class="fas fa-cog"></i>
                <span>الإدارة</span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow mb-2">
                <li><a class="dropdown-item" href="admin.php"><i class="fas fa-tachometer-alt me-2"></i>لوحة التحكم</a></li>
                <li><a class="dropdown-item" href="admin_sponsors.php"><i class="fas fa-ad me-2"></i>إدارة الرعاة</a></li>
                <li><a class="dropdown-item" href="setup_matches.php"><i class="fas fa-tools me-2"></i>تجهيز المباريات</a></li>
                <li><hr class="dropdown-divider border-secondary"></li>
                <li><a class="dropdown-item text-danger" href="reset_db.php"><i class="fas fa-trash-alt me-2"></i>تصفير البيانات</a></li>
            </ul>
        </div>
    <?php endif; ?>
</nav>

<div class="container mt-4 animate__animated animate__fadeIn">