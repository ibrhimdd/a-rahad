<?php
// ملف حماية صفحات الإدارة - ملعب أحمد رشاد
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// التحقق من أن المستخدم أدمن
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    // إذا لم يكن أدمن، يتم توجيهه للرئيسية مع رسالة تنبيه (اختياري)
    header("Location: index.php?error=access_denied");
    exit();
}
?>