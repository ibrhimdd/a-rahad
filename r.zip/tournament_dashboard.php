<?php 
include 'db.php'; 
include 'header.php'; 

// جلب وتأمين رقم البطولة
$t_id = isset($_GET['id']) ? (int)$_GET['id'] : (isset($_GET['tour_id']) ? (int)$_GET['tour_id'] : 0);

if ($t_id <= 0) {
    echo "<div class='container py-5'><div class='alert alert-danger text-center'>عذراً، لم يتم تحديد البطولة بشكل صحيح.</div></div>";
    include 'footer.php';
    exit;
}

// 1. جلب تفاصيل البطولة بـ Prepared Statement
$stmt = $conn->prepare("SELECT * FROM tournaments WHERE id = ?");
$stmt->bind_param("i", $t_id);
$stmt->execute();
$tournament = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$tournament) { 
    echo "<div class='container py-5'><div class='alert alert-danger text-center'>البطولة غير موجودة بالنظام.</div></div>";
    include 'footer.php';
    exit;
}

// 2. إحصائيات سريعة
$stmt_teams = $conn->prepare("SELECT COUNT(DISTINCT team_home_id) as total FROM matches WHERE tournament_id = ?");
$stmt_teams->bind_param("i", $t_id);
$stmt_teams->execute();
$total_teams = $stmt_teams->get_result()->fetch_assoc()['total'] ?? 0;
$stmt_teams->close();

// 3. جلب جميع المجموعات
$groups = [];
$stmt_groups = $conn->prepare("SELECT DISTINCT group_name FROM matches WHERE tournament_id = ? AND (group_name IS NOT NULL AND group_name != '') ORDER BY group_name ASC");
$stmt_groups->bind_param("i", $t_id);
$stmt_groups->execute();
$g_res = $stmt_groups->get_result();
while ($row = $g_res->fetch_assoc()) {
    $groups[] = $row['group_name'];
}
$stmt_groups->close();
?>

<style>
    body { background-color: #f8fafc; font-family: 'Cairo', sans-serif; direction: rtl; text-align: right; }
    
    .tournament-hero {
        background: linear-gradient(135deg, #1a237e 0%, #0d47a1 100%);
        border-radius: 20px;
        box-shadow: 0 10px 25px rgba(26, 35, 126, 0.2);
    }

    .custom-pills .nav-link {
        color: #1e293b !important;
        background: #e2e8f0;
        border: 1px solid #cbd5e1 !important;
        margin: 4px;
        border-radius: 12px !important;
        font-weight: 700;
        padding: 10px 22px;
        transition: all 0.3s ease;
    }
    .custom-pills .nav-link:hover {
        background: #cbd5e1;
        color: #0f172a !important;
    }
    .custom-pills .nav-link.active {
        background: #1a237e !important;
        color: #ffffff !important;
        border-color: #1a237e !important;
        box-shadow: 0 4px 12px rgba(26, 35, 126, 0.3);
    }

    .match-row { 
        background: #131b4d;
        border-radius: 16px; 
        margin-bottom: 14px; 
        border: 1px solid #283593; 
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .match-row:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(19, 27, 77, 0.25);
    }
    
    .team-box { display: flex; align-items: center; gap: 12px; width: 32%; }
    .team-name { color: #ffffff; font-weight: 700; font-size: 1rem; }
    .team-logo { width: 42px; height: 42px; object-fit: contain; background: #ffffff; border-radius: 50%; padding: 3px; }
    
    .score-box { 
        background: #0a0e29; 
        color: #ffc107; 
        padding: 6px 18px; 
        border-radius: 10px; 
        font-weight: 900; 
        font-size: 1.25rem; 
        min-width: 85px; 
        border: 1px solid #1a237e;
        letter-spacing: 2px;
    }
    
    .match-status { font-size: 0.72rem; padding: 3px 10px; border-radius: 20px; font-weight: 800; margin-bottom: 6px; display: inline-block; }
    .status-finished { background: #1b5e20; color: #a5d6a7; border: 1px solid #2e7d32; }
    .status-upcoming { background: #37474f; color: #cfd8dc; border: 1px solid #455a64; }

    .match-info-center { text-align: center; min-width: 130px; }
    .datetime-text { font-size: 0.78rem; color: #90caf9; display: block; margin-top: 5px; font-weight: 600; }

    .stats-table { width: 100%; border-collapse: separate; border-spacing: 0 8px; }
    .stats-table tr { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; }
    .stats-table td { padding: 10px 14px; }
    .rank-num { 
        width: 24px; height: 24px; 
        background: #1a237e; color: #ffffff; 
        border-radius: 50%; display: inline-flex; 
        align-items: center; justify-content: center; 
        font-size: 0.75rem; font-weight: 700; margin-left: 8px; 
    }

    .action-btn {
        border-radius: 8px;
        font-size: 0.82rem;
        font-weight: 700;
        padding: 6px 14px;
        display: inline-flex;
        align-items: center;
        gap: 5px;
    }
</style>

<div class="container py-4">
    <!-- هيدر البطولة -->
    <div class="card border-0 tournament-hero p-4 mb-4 text-white text-center">
        <h1 class="fw-bold text-warning mb-2"><?php echo htmlspecialchars($tournament['name']); ?></h1>
        <p class="text-white-50 mb-3">عدد الفرق المشاركة: <span class="badge bg-warning text-dark fs-6"><?php echo $total_teams; ?></span></p>
        
        <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <form action="process_group_promotion.php" method="POST" class="d-inline-block">
            <input type="hidden" name="tournament_id" value="<?php echo $t_id; ?>">
            <button type="submit" name="promote_groups" class="btn btn-warning rounded-pill px-4 fw-bold shadow-sm">
                <i class="fas fa-sync-alt me-1"></i> تحديث المتأهلين للأدوار القادمة
            </button>
        </form>
        <?php endif; ?>
    </div>

    <!-- التبويبات -->
    <ul class="nav nav-pills custom-pills mb-4 justify-content-center" role="tablist">
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="pill" data-bs-target="#matches-tab"><i class="fas fa-calendar-alt me-1"></i> المباريات</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#standings-tab"><i class="fas fa-table me-1"></i> الترتيب</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#teams-tab"><i class="fas fa-users me-1"></i> الفرق</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#stats-tab"><i class="fas fa-chart-line me-1"></i> الإحصائيات</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#knockout-tab"><i class="fas fa-trophy me-1"></i> الأدوار النهائية</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#predictors-tab"><i class="fas fa-medal me-1"></i> أفضل المتوقعين</button></li>
    </ul>

    <div class="tab-content">
          <style>
                /* تنسيق الحاوية الرئيسية للمباراة */
                .match-card {
                    background: #131b4d`;
                    border-radius: 14px;
                    border: 1px solid #eef2f6;
                    transition: all 0.25s ease-in-out;
                    position: relative;
                    overflow: hidden;
                }

                .match-card:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.06) !important;
                }

                /* أطراف الفرق والأسماء */
                .team-box {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    flex: 1;
                    min-width: 0;
                }

                .team-logo {
                    width: 42px;
                    height: 42px;
                    object-fit: contain;
                    border-radius: 50%;
                    background-color: #f8fafc;
                    padding: 4px;
                    border: 1px solid #e2e8f0;
                    flex-shrink: 0;
                }

                .team-name {
                    font-weight: 700;
                    font-size: 0.95rem;
                    color: #1e293b;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }

                /* الجزء الأوسط (حالة المبارة، النتيجة، التوقيت) */
                .match-info-center {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    min-width: 140px;
                }

                .match-status-badge {
                    font-size: 0.72rem;
                    font-weight: 700;
                    padding: 3px 10px;
                    border-radius: 50px;
                    letter-spacing: 0.3px;
                }

                /* ألوان الحالات المختلفة */
                .status-finished {
                    background-color: #002d845;
                    color: #475569;
                }

                .status-upcoming {
                    background-color: #002d845;
                    color: #0369a1;
                }

                .status-live {
                    background-color: #002d845;
                    color: #e11d48;
                    animation: pulse 1.5s infinite;
                }

                @keyframes pulse {
                    0% { opacity: 1; }
                    50% { opacity: 0.6; }
                    100% { opacity: 1; }
                }

                .score-box {
                    background: #0f172a;
                    color: #ffffff;
                    font-weight: 800;
                    font-size: 1.1rem;
                    padding: 4px 16px;
                    border-radius: 8px;
                    letter-spacing: 1px;
                    box-shadow: inset 0 2px 4px rgba(0,0,0,0.2);
                }

                .datetime-text {
                    font-size: 0.78rem;
                    color: #64748b;
                    font-weight: 600;
                }

                /* أزرار التحكم */
                .action-btn {
                    border-radius: 8px;
                    font-weight: 600;
                    font-size: 0.82rem;
                    padding: 6px 14px;
                    display: inline-flex;
                    align-items: center;
                    gap: 6px;
                }

                /* استجابة الشاشات الصغيرة (الموبايل) */
                @media (max-width: 767.98px) {
                    .match-card {
                        padding: 16px 12px !important;
                    }
                    
                    .team-name {
                        font-size: 0.88rem;
                    }

                    .team-logo {
                        width: 34px;
                        height: 34px;
                    }

                    .score-box {
                        font-size: 0.95rem;
                        padding: 2px 12px;
                    }

                    .actions-wrapper {
                        width: 100%;
                        justify-content: flex-end;
                        border-top: 1px dashed #e2e8f0;
                        padding-top: 10px;
                        margin-top: 6px;
                    }

                    .action-btn {
                        flex: 1;
                        justify-content: center;
                    }
                }
            </style>

        <!-- 1. تبويب المباريات -->
        <div class="tab-pane fade show active" id="matches-tab">
            <?php if (empty($groups)): ?>
                <div class="alert alert-info text-center rounded-3 border-0 shadow-sm py-4">
                    <i class="fas fa-info-circle fa-lg me-2"></i> لا يوجد مجموعات أو مباريات مسجلة لهذه البطولة حالياً.
                </div>
            <?php else: ?>
                <?php foreach ($groups as $g_name): ?>
                    <div class="d-flex align-items-center justify-content-between mb-3 mt-4 pb-2 border-bottom">
                        <h6 class="fw-bold text-primary mb-0">
                            <i class="fas fa-layer-group me-1"></i> <?php echo htmlspecialchars($g_name); ?>
                        </h6>
                    </div>

                    <?php
                    $stmt_m = $conn->prepare("SELECT m.*, t1.team_name as home, t1.logo as home_logo, t2.team_name as away, t2.logo as away_logo 
                                            FROM matches m 
                                            LEFT JOIN teams t1 ON m.team_home_id = t1.id 
                                            LEFT JOIN teams t2 ON m.team_away_id = t2.id 
                                            WHERE m.tournament_id = ? AND m.group_name = ? 
                                            ORDER BY m.match_date ASC");
                    $stmt_m->bind_param("is", $t_id, $g_name);
                    $stmt_m->execute();
                    $m_sql = $stmt_m->get_result();

                    while($m = $m_sql->fetch_assoc()):
                        // قراءة الحالة من حقل status وحقل is_finished
                        $match_status = $m['status'] ?? 'upcoming';
                        $is_finished  = ($match_status === 'finished' || (int)$m['is_finished'] === 1);
                        $is_live      = ($match_status === 'live');
                    ?>
                    
                    <div class="match-card p-3 mb-3 shadow-sm d-flex flex-wrap align-items-center justify-content-between gap-3">
                        
                        <!-- الفريق المستضيف -->
                        <div class="team-box justify-content-start text-start">
                            <img src="uploads/logos/<?php echo htmlspecialchars($m['home_logo'] ?: 'default.png'); ?>" 
                                class="team-logo" 
                                alt="<?php echo htmlspecialchars($m['home']); ?>"
                                onerror="this.src='uploads/logos/default.png';">
                            <span class="team-name" title="<?php echo htmlspecialchars($m['home']); ?>">
                                <?php echo htmlspecialchars($m['home'] ?: '---'); ?>
                            </span>
                        </div>

                        <!-- نتيجة ووقت المباراة -->
                        <div class="match-info-center my-1">
                            <?php if ($is_live): ?>
                                <span class="match-status-badge mb-1 status-live">
                                    <i class="fas fa-circle text-danger me-1" style="font-size:8px;"></i> مباشر الآن
                                </span>
                            <?php elseif ($is_finished): ?>
                                <span class="match-status-badge mb-1 status-finished">
                                    انتهت
                                </span>
                            <?php else: ?>
                                <span class="match-status-badge mb-1 status-upcoming">
                                    قادمة
                                </span>
                            <?php endif; ?>
                            
                            <div class="score-box my-1">
                                <?php if ($is_finished || $is_live): ?>
                                    <?php echo (int)$m['score_home']; ?> - <?php echo (int)$m['score_away']; ?>
                                <?php else: ?>
                                    <span class="text-white-50 fs-6">VS</span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="datetime-text mt-1 d-flex gap-2">
                                <span><i class="far fa-calendar-alt me-1"></i><?php echo date('Y/m/d', strtotime($m['match_date'])); ?></span>
                                <span><i class="far fa-clock me-1"></i><?php echo date('H:i', strtotime($m['match_date'])); ?></span>
                            </div>
                        </div>

                        <!-- الفريق الضيف -->
                        <div class="team-box justify-content-end text-end flex-row-reverse">
                            <img src="uploads/logos/<?php echo htmlspecialchars($m['away_logo'] ?: 'default.png'); ?>" 
                                class="team-logo" 
                                alt="<?php echo htmlspecialchars($m['away']); ?>"
                                onerror="this.src='uploads/logos/default.png';">
                            <span class="team-name" title="<?php echo htmlspecialchars($m['away']); ?>">
                                <?php echo htmlspecialchars($m['away'] ?: '---'); ?>
                            </span>
                        </div>

                        <!-- أزرار الإجراءات -->
                        <div class="actions-wrapper d-flex align-items-center gap-2">
                            <a href="match_details.php?id=<?php echo $m['id']; ?>" class="btn btn-primary action-btn shadow-sm">
                                <i class="fas fa-info-circle"></i> <span>التفاصيل</span>
                            </a>
                            
                            <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                                <a href="match_details.php?id=<?php echo $m['id']; ?>" class="btn btn-warning action-btn shadow-sm">
                                    <i class="fas fa-edit"></i> <span>إدارة</span>
                                </a>
                            <?php endif; ?>
                        </div>

                    </div>

                    <?php 
                    endwhile; 
                    $stmt_m->close();
                    ?>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

       
         <!-- 2. تبويب الترتيب -->
         <div class="tab-pane fade" id="standings-tab">
            <div class="row">
                <?php foreach ($groups as $g_name): ?>
                <div class="col-lg-6 mb-4">
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
                        <div class="card-header bg-dark text-white text-center fw-bold small py-2">جدول ترتيب <?php echo htmlspecialchars($g_name); ?></div>
                        <div class="table-responsive">
                            <table class="table table-hover text-center align-middle mb-0 bg-white" style="color: #212529;">
                                <thead class="table-light">
                                    <tr class="text-white">
                                        <th>#</th>
                                        <th class="text-start">الفريق</th>
                                        <th>ل</th>
                                        <th>ف</th>
                                        <th>ت</th>
                                        <th>خ</th>
                                        <th>له</th>
                                        <th>عليه</th>
                                        <th>+/-</th>
                                        <th>ن</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // جلب كافة فرق المجموعة أولاً
                                    $stmt_gt = $conn->prepare("
                                        SELECT DISTINCT t.id, t.team_name, t.logo 
                                        FROM teams t 
                                        JOIN matches m ON (t.id = m.team_home_id OR t.id = m.team_away_id) 
                                        WHERE m.tournament_id = ? AND m.group_name = ?
                                    ");
                                    $stmt_gt->bind_param("is", $t_id, $g_name);
                                    $stmt_gt->execute();
                                    $group_teams = $stmt_gt->get_result()->fetch_all(MYSQLI_ASSOC);
                                    $stmt_gt->close();

                                    $standings = [];

                                    foreach ($group_teams as $team) {
                                        $tid = $team['id'];

                                        // جلب مباريات الفريق المنتهية في هذا الجروب
                                        $stmt_tm = $conn->prepare("
                                            SELECT team_home_id, team_away_id, score_home, score_away 
                                            FROM matches 
                                            WHERE tournament_id = ? AND group_name = ? 
                                            AND (team_home_id = ? OR team_away_id = ?) 
                                            AND (is_finished = 1 OR is_finished = '1' OR status = 'finished')
                                        ");
                                        $stmt_tm->bind_param("isii", $t_id, $g_name, $tid, $tid);
                                        $stmt_tm->execute();
                                        $team_matches = $stmt_tm->get_result();

                                        $pld = 0; $wins = 0; $draws = 0; $loss = 0;
                                        $gf = 0; $ga = 0; $pts = 0;

                                        while ($m = $team_matches->fetch_assoc()) {
                                            $pld++;
                                            $is_home = ($m['team_home_id'] == $tid);
                                            $my_score = $is_home ? (int)$m['score_home'] : (int)$m['score_away'];
                                            $opp_score = $is_home ? (int)$m['score_away'] : (int)$m['score_home'];

                                            $gf += $my_score;
                                            $ga += $opp_score;

                                            if ($my_score > $opp_score) {
                                                $wins++;
                                                $pts += 3;
                                            } elseif ($my_score == $opp_score) {
                                                $draws++;
                                                $pts += 1;
                                            } else {
                                                $loss++;
                                            }
                                        }
                                        $stmt_tm->close();

                                        $gd = $gf - $ga;

                                        $standings[] = [
                                            'team_name' => $team['team_name'],
                                            'logo' => $team['logo'],
                                            'pld' => $pld,
                                            'wins' => $wins,
                                            'draws' => $draws,
                                            'loss' => $loss,
                                            'gf' => $gf,
                                            'ga' => $ga,
                                            'gd' => $gd,
                                            'pts' => $pts
                                        ];
                                    }

                                    // ترتيب الفرق حسب النقاط ثم فارق الأهداف ثم له
                                    usort($standings, function($a, $b) {
                                        if ($a['pts'] != $b['pts']) return $b['pts'] - $a['pts'];
                                        if ($a['gd'] != $b['gd']) return $b['gd'] - $a['gd'];
                                        return $b['gf'] - $a['gf'];
                                    });

                                    $rank = 1;
                                    foreach ($standings as $s): 
                                        $is_qualified = ($rank <= 2);
                                    ?>
                                    <tr class="<?php echo $is_qualified ? 'table-success' : 'bg-white text-white'; ?>">
                                        <td class="fw-bold <?php echo $is_qualified ? 'text-success' : 'text-white'; ?>"><?php echo $rank++; ?></td>
                                        <td class="text-start">
                                            <img src="uploads/logos/<?php echo htmlspecialchars($s['logo'] ?: 'default.png'); ?>" width="24" height="24" class="me-2 rounded-circle" onerror="this.src='uploads/logos/default.png';">
                                            <span class="fw-bold <?php echo $is_qualified ? 'text-success' : 'text-white'; ?>">
                                                <?php echo htmlspecialchars($s['team_name']); ?>
                                            </span>
                                        </td>
                                        <td class="<?php echo $is_qualified ? '' : 'text-white'; ?>"><?php echo $s['pld']; ?></td>
                                        <td class="text-success fw-bold"><?php echo $s['wins']; ?></td>
                                        <td class="text-warning fw-bold"><?php echo $s['draws']; ?></td>
                                        <td class="text-danger fw-bold"><?php echo $s['loss']; ?></td>
                                        <td class="<?php echo $is_qualified ? '' : 'text-dark'; ?>"><?php echo $s['gf']; ?></td>
                                        <td class="<?php echo $is_qualified ? '' : 'text-dark'; ?>"><?php echo $s['ga']; ?></td>
                                        <td class="fw-bold <?php echo ($s['gd'] > 0) ? 'text-success' : (($s['gd'] < 0) ? 'text-danger' : 'text-muted'); ?>">
                                            <?php echo ($s['gd'] > 0 ? '+' : '') . $s['gd']; ?>
                                        </td>
                                        <td class="fw-bold text-primary fs-6"><?php echo $s['pts']; ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>


        <!-- 3. تبويب الفرق -->
        <div class="tab-pane fade" id="teams-tab">
            <div class="row">
                <?php foreach ($groups as $g_name): ?>
                <div class="col-md-4 mb-4">
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                        <div class="card-header bg-primary text-white text-center fw-bold py-2"><?php echo htmlspecialchars($g_name); ?></div>
                        <div class="list-group list-group-flush">
                            <?php 
                            $stmt_t = $conn->prepare("SELECT DISTINCT t.team_name, t.logo FROM teams t JOIN matches m ON (t.id = m.team_home_id OR t.id = m.team_away_id) WHERE m.tournament_id = ? AND m.group_name = ?");
                            $stmt_t->bind_param("is", $t_id, $g_name);
                            $stmt_t->execute();
                            $teams_q = $stmt_t->get_result();
                            while($tm = $teams_q->fetch_assoc()): ?>
                            <div class="list-group-item d-flex align-items-center p-3">
                                <img src="uploads/logos/<?php echo htmlspecialchars($tm['logo'] ?: 'default.png'); ?>" width="35" height="35" class="rounded-circle me-3" onerror="this.src='uploads/logos/default.png';">
                                <span class="fw-bold text-dark"><?php echo htmlspecialchars($tm['team_name']); ?></span>
                            </div>
                            <?php 
                            endwhile; 
                            $stmt_t->close();
                            ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- 4. تبويب الإحصائيات -->
        <div class="tab-pane fade" id="stats-tab">
            <div class="row g-4">
                <div class="col-md-4">
                    <h6 class="fw-bold mb-3 text-danger"><i class="fas fa-fire me-1"></i> الهدافين</h6>
                    <table class="stats-table">
                        <?php 
                        $stmt_sc = $conn->prepare("SELECT p.player_name, COUNT(g.id) as goals FROM goals g JOIN players p ON g.player_id = p.id JOIN matches m ON g.match_id = m.id WHERE m.tournament_id = ? GROUP BY p.id ORDER BY goals DESC LIMIT 5");
                        $stmt_sc->bind_param("i", $t_id);
                        $stmt_sc->execute();
                        $scorers = $stmt_sc->get_result();
                        $r = 1; 
                        while($ps = $scorers->fetch_assoc()): ?>
                        <tr>
                            <td class="text-start"><span class="rank-num"><?php echo $r++; ?></span> <span class="fw-bold text-dark"><?php echo htmlspecialchars($ps['player_name']); ?></span></td>
                            <td class="fw-bold text-danger text-center"><?php echo $ps['goals']; ?> ⚽</td>
                        </tr>
                        <?php 
                        endwhile; 
                        $stmt_sc->close();
                        ?>
                    </table>
                </div>

                <div class="col-md-4">
                    <h6 class="fw-bold mb-3 text-primary"><i class="fas fa-magic me-1"></i> صناع الأهداف</h6>
                    <table class="stats-table">
                        <?php 
                        $stmt_as = $conn->prepare("SELECT p.player_name, COUNT(g.id) as assists FROM goals g JOIN players p ON g.assist_player_id = p.id JOIN matches m ON g.match_id = m.id WHERE m.tournament_id = ? GROUP BY p.id ORDER BY assists DESC LIMIT 5");
                        $stmt_as->bind_param("i", $t_id);
                        $stmt_as->execute();
                        $assists = $stmt_as->get_result();
                        $r = 1; 
                        while($as = $assists->fetch_assoc()): ?>
                        <tr>
                            <td class="text-start"><span class="rank-num"><?php echo $r++; ?></span> <span class="fw-bold text-dark"><?php echo htmlspecialchars($as['player_name']); ?></span></td>
                            <td class="fw-bold text-primary text-center"><?php echo $as['assists']; ?> 👟</td>
                        </tr>
                        <?php 
                        endwhile; 
                        $stmt_as->close();
                        ?>
                    </table>
                </div>

                <div class="col-md-4">
                    <h6 class="fw-bold mb-3 text-warning"><i class="fas fa-star me-1"></i> الأفضل تقييماً</h6>
                    <table class="stats-table">
                        <?php 
                        $stmt_top = $conn->prepare("SELECT p.player_name, AVG(ps.rating) as avg_rating FROM player_match_stats ps JOIN players p ON ps.player_id = p.id JOIN matches m ON ps.match_id = m.id WHERE m.tournament_id = ? GROUP BY p.id ORDER BY avg_rating DESC LIMIT 5");
                        $stmt_top->bind_param("i", $t_id);
                        $stmt_top->execute();
                        $top = $stmt_top->get_result();
                        $r = 1; 
                        while($tr = $top->fetch_assoc()): ?>
                        <tr>
                            <td class="text-start"><span class="rank-num"><?php echo $r++; ?></span> <span class="fw-bold text-dark"><?php echo htmlspecialchars($tr['player_name']); ?></span></td>
                            <td class="fw-bold text-warning text-center"><?php echo number_format($tr['avg_rating'], 1); ?> ⭐</td>
                        </tr>
                        <?php 
                        endwhile; 
                        $stmt_top->close();
                        ?>
                    </table>
                </div>
            </div>
        </div>

        <!-- 5. تبويب الأدوار النهائية -->
        <div class="tab-pane fade" id="knockout-tab">
            <?php
            $stmt_r = $conn->prepare("SELECT DISTINCT round_level FROM matches WHERE tournament_id = ? AND round_level > 0 ORDER BY round_level ASC");
            $stmt_r->bind_param("i", $t_id);
            $stmt_r->execute();
            $rounds = $stmt_r->get_result();

            if ($rounds->num_rows === 0) {
                echo "<div class='alert alert-secondary text-center'>لم تبدأ الأدوار الإقصائية بعد.</div>";
            }

            while($r = $rounds->fetch_assoc()):
                $lvl = (int)$r['round_level'];

                $stmt_cnt = $conn->prepare("SELECT COUNT(id) as count FROM matches WHERE tournament_id = ? AND round_level = ?");
                $stmt_cnt->bind_param("ii", $t_id, $lvl);
                $stmt_cnt->execute();
                $m_count = $stmt_cnt->get_result()->fetch_assoc()['count'] ?? 0;
                $stmt_cnt->close();

                $title = ($m_count == 1) ? "المباراة النهائية" : (($m_count == 2) ? "نصف النهائي" : "دور الـ " . ($m_count * 2));
            ?>
            <h5 class="fw-bold mb-3 mt-4 text-dark border-start border-4 border-warning ps-2"><?php echo $title; ?></h5>
            <div class="row g-3">
                <?php
                $stmt_km = $conn->prepare("SELECT m.*, t1.team_name as home, t1.logo as home_logo, t2.team_name as away, t2.logo as away_logo 
                                          FROM matches m 
                                          LEFT JOIN teams t1 ON m.team_home_id = t1.id 
                                          LEFT JOIN teams t2 ON m.team_away_id = t2.id 
                                          WHERE m.tournament_id = ? AND m.round_level = ?");
                $stmt_km->bind_param("ii", $t_id, $lvl);
                $stmt_km->execute();
                $km_sql = $stmt_km->get_result();

                while($km = $km_sql->fetch_assoc()): ?>
                <div class="col-md-6">
                    <div class="match-row p-3 d-flex align-items-center justify-content-between shadow-sm">
                        <div class="team-box justify-content-start">
                            <img src="uploads/logos/<?php echo htmlspecialchars($km['home_logo'] ?: 'default.png'); ?>" class="team-logo shadow-sm" onerror="this.src='uploads/logos/default.png';">
                            <span class="team-name small"><?php echo htmlspecialchars($km['home'] ?: ($km['home_source'] ?? 'لم يحدد')); ?></span>
                        </div>

                        <div class="match-info-center">
                            <span class="match-status <?php echo $km['is_finished'] ? 'status-finished' : 'status-upcoming'; ?>">
                                <?php echo $km['is_finished'] ? 'انتهت' : 'قادمة'; ?>
                            </span>
                            <div class="score-box mx-auto"><?php echo (int)$km['score_home']; ?> - <?php echo (int)$km['score_away']; ?></div>
                            <span class="datetime-text"><?php echo date('Y/m/d H:i', strtotime($km['match_date'])); ?></span>
                        </div>

                        <div class="team-box justify-content-end text-end">
                            <span class="team-name small"><?php echo htmlspecialchars($km['away'] ?: ($km['away_source'] ?? 'لم يحدد')); ?></span>
                            <img src="uploads/logos/<?php echo htmlspecialchars($km['away_logo'] ?: 'default.png'); ?>" class="team-logo shadow-sm" onerror="this.src='uploads/logos/default.png';">
                        </div>
                    </div>
                </div>
                <?php 
                endwhile; 
                $stmt_km->close();
                ?>
            </div>
            <?php 
            endwhile; 
            $stmt_r->close();
            ?>
        </div>

        <!-- 6. تبويب أفضل المتوقعين -->
        <div class="tab-pane fade" id="predictors-tab">
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                <div class="card-header bg-dark text-white text-center fw-bold py-3">
                    <i class="fas fa-trophy text-warning me-2"></i> ترتيب أفضل المتوقعين في البطولة
                </div>
                <div class="table-responsive">
                    <table class="table table-hover text-center align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 80px;">#</th>
                                <th class="text-start">المستخدم</th>
                                <th>التوقعات الصحيحة</th>
                                <th>إجمالي النقاط</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $p_sql = "SELECT 
                                        u.username, 
                                        utp.total_points,
                                        COUNT(CASE WHEN p.points_awarded > 0 THEN 1 END) as correct_predictions
                                      FROM user_tournament_points utp
                                      JOIN users u ON utp.user_id = u.id 
                                      LEFT JOIN matches m ON m.tournament_id = utp.tournament_id
                                      LEFT JOIN predictions p ON p.match_id = m.id AND p.user_id = utp.user_id
                                      WHERE utp.tournament_id = ? 
                                      GROUP BY utp.user_id, u.username, utp.total_points
                                      ORDER BY utp.total_points DESC, correct_predictions DESC 
                                      LIMIT 10";

                            $stmt_p = $conn->prepare($p_sql);
                            $stmt_p->bind_param("i", $t_id);
                            $stmt_p->execute();
                            $p_res = $stmt_p->get_result();
                            $p_rank = 1;

                            if ($p_res && $p_res->num_rows > 0):
                                while ($pred = $p_res->fetch_assoc()): 
                                    $badge_class = 'bg-secondary';
                                    if ($p_rank == 1) $badge_class = 'bg-warning text-dark';
                                    elseif ($p_rank == 2) $badge_class = 'bg-light text-dark border';
                                    elseif ($p_rank == 3) $badge_class = 'bg-danger text-white';
                            ?>
                                    <tr>
                                        <td>
                                            <span class="badge rounded-circle p-2 <?php echo $badge_class; ?>" style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center;">
                                                <?php echo $p_rank++; ?>
                                            </span>
                                        </td>
                                        <td class="text-start fw-bold text-dark">
                                            <i class="fas fa-user-circle text-primary me-2 fs-5"></i>
                                            <?php echo htmlspecialchars($pred['username']); ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-info text-dark fs-6">
                                                <?php echo (int)$pred['correct_predictions']; ?>
                                            </span>
                                        </td>
                                        <td class="fw-bold text-success fs-5">
                                            <?php echo (int)$pred['total_points']; ?> <small class="fs-6 text-muted">نقطة</small>
                                        </td>
                                    </tr>
                            <?php 
                                endwhile;
                            else:
                            ?>
                                <tr>
                                    <td colspan="4" class="text-muted py-4">
                                        <i class="fas fa-info-circle me-1"></i> لا توجد توقعات مسجلة لهذه البطولة حتى الآن.
                                    </td>
                                </tr>
                            <?php 
                            endif;
                            $stmt_p->close();
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

<?php include 'footer.php'; ?>