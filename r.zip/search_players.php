<?php include 'db.php'; include 'header.php'; ?>

<div class="container mt-4">
    <div class="row justify-content-center mb-5">
        <div class="col-md-8">
            <div class="card shadow-sm border-0 bg-primary text-white p-4">
                <h3 class="text-center mb-4"><i class="fas fa-search"></i> ابحث عن نجمك المفضل</h3>
                <form action="" method="GET" class="d-flex gap-2">
                    <input type="text" name="query" class="form-control form-control-lg border-0 shadow-none" 
                           placeholder="اكتب اسم اللاعب، المركز، أو الفريق..." 
                           value="<?php echo $_GET['query'] ?? ''; ?>">
                    <button type="submit" class="btn btn-warning btn-lg px-4 shadow">بحث</button>
                </form>
            </div>
        </div>
    </div>

    <div class="row">
        <?php
        $search = $_GET['query'] ?? '';
        $sql = "SELECT players.*, teams.team_name, teams.logo as team_logo 
                FROM players 
                JOIN teams ON players.team_id = teams.id";

        if (!empty($search)) {
            $search = mysqli_real_escape_string($conn, $search);
            $sql .= " WHERE players.player_name LIKE '%$search%' 
                      OR players.position LIKE '%$search%' 
                      OR teams.team_name LIKE '%$search%'";
        }

        $sql .= " ORDER BY players.player_name ASC";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            while($player = mysqli_fetch_assoc($result)) {
                $img = !empty($player['image']) ? $player['image'] : 'default_player.png';
                ?>
                <div class="col-md-4 col-lg-3 mb-4">
                    <div class="card h-100 shadow-sm border-0 player-card overflow-hidden">
                        <div class="position-relative">
                            <img src="uploads/players/<?php echo $img; ?>" class="card-img-top" style="height: 250px; object-fit: cover;">
                            <div class="position-absolute bottom-0 start-0 p-2 w-100 text-white bg-dark bg-opacity-50">
                                <small class="fw-bold"><?php echo $player['position']; ?></small>
                            </div>
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title fw-bold mb-1"><?php echo $player['player_name']; ?></h5>
                            <div class="d-flex align-items-center justify-content-center gap-2 mb-3">
                                <img src="uploads/logos/<?php echo $player['team_logo']; ?>" width="20">
                                <span class="text-muted small"><?php echo $player['team_name']; ?></span>
                            </div>
                            <a href="player_profile.php?id=<?php echo $player['id']; ?>" class="btn btn-outline-primary btn-sm rounded-pill px-4">مشاهدة البروفايل</a>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<div class='text-center py-5'><h4 class='text-muted'>عذراً، لم نجد أي لاعب يطابق بحثك.</h4></div>";
        }
        ?>
    </div>
</div>

<style>
    .player-card { transition: 0.3s; }
    .player-card:hover { transform: scale(1.03); box-shadow: 0 10px 25px rgba(0,0,0,0.1) !important; }
    .form-control:focus { box-shadow: none; border-color: #ffca28; }
</style>

<?php include 'footer.php'; ?>