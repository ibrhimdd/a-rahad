self.addEventListener('install', (e) => {
  self.skipWaiting();
});

self.addEventListener('fetch', (e) => {
  // يترك الطلبات تعمل بشكل طبيعي
});