<?php
include 'db.php';
include 'header.php';

// جلب جميع البطولات من قاعدة البيانات
$sql = "SELECT * FROM tournaments ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
?>

<style>
    body { 
        background-color: #f8fafc; 
        font-family: 'Cairo', sans-serif; 
    }
    
    .tournament-card { 
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); 
        border: 1px solid #cbd5e1 !important; /* حدود أوضح للبطاقة */
        background-color: #ffffff;
    }
    
    .tournament-card:hover { 
        transform: translateY(-8px); 
        box-shadow: 0 12px 25px rgba(0, 0, 0, 0.1) !important; 
        border-color: #94a3b8 !important;
    }

    /* هيدر البطاقة */
    .card-header-icon {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
    }

    /* تعديل ألوان اسم البطولة وتاريخ البدء لتباين تام 🌟 */
    .tournament-title {
        color: #00d285 !important; /* لون أسود/أزرق داكن جداً واضح */
        font-weight: 800;
        font-size: 1.25rem;
    }

    .start-date-container {
        color: #ffffff !important; /* لون نص داكن وواضح */
        font-weight: 700;
        font-size: 0.9rem;
    }

    .start-date-badge {
        background-color: #00d285;
        color: #1e293b;
        border: 1px solid #cbd5e1;
        padding: 4px 10px;
        border-radius: 8px;
        font-weight: 700;
        display: inline-block;
    }

    /* تحسين زر إدارة البطولة */
    .btn-manage {
        background-color: #1a237e;
        color: #ffffff !important;
        border: none;
        font-weight: 700;
        padding: 10px;
        transition: all 0.2s ease;
    }
    .btn-manage:hover {
        background-color: #0d47a1;
        color: #334155 !important;
        box-shadow: 0 4px 12px rgba(26, 35, 126, 0.25);
    }

    /* تحسين الزر الدائري للترتيب */
    .btn-icon-action { 
        width: 42px; 
        height: 42px; 
        display: inline-flex; 
        align-items: center; 
        justify-content: center;
        border: 2px solid #2563eb;
        color: #1d4ed8;
        background-color: #eff6ff;
        font-size: 1.1rem;
        transition: all 0.2s ease;
    }
    .btn-icon-action:hover {
        background-color: #2563eb;
        color: #ffffff !important;
        border-color: #2563eb;
        transform: scale(1.05);
    }
</style>

<div class="container py-5" style="direction: rtl; text-align: right;">
    <!-- عنوان الصفحة -->
    <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
        <h2 class="fw-bold text-white mb-0"><i class="fas fa-trophy text-warning ms-2"></i> البطولات المتاحة</h2>
    </div>

    <div class="row g-4">
        <?php if($result && mysqli_num_rows($result) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 border-0 shadow-sm rounded-4 overflow-hidden tournament-card">
                        <!-- هيدر بطاقة البطولة -->
                        <div class="card-header-icon p-4 text-center">
                            <i class="fas fa-trophy fa-3x text-warning opacity-75"></i>
                        </div>
                        
                        <!-- جسم البطاقة -->
                        <div class="card-body p-4 d-flex flex-column justify-content-between">
                            <div>
                                <!-- اسم البطولة باللون الداكن 🌟 -->
                                <h5 class="card-title tournament-title mb-3"><?php echo htmlspecialchars($row['name']); ?></h5>
                                
                                <!-- تاريخ البدء بخلفية متباينة وواضحة 🌟 -->
                                <div class="start-date-container mb-4">
                                    <i class="fas fa-calendar-alt ms-1 text-primary"></i> تاريخ البدء: 
                                    <span class="start-date-badge ms-1">
                                        <?php echo htmlspecialchars($row['start_date'] ?? 'غير محدد'); ?>
                                    </span>
                                </div>
                            </div>
                            
                            <!-- أزرار الإجراءات -->
                            <div class="d-flex align-items-center gap-2 mt-auto">
                                <a href="tournament_dashboard.php?id=<?php echo $row['id']; ?>" class="btn btn-manage w-100 rounded-pill text-center">
                                    <i class="fas fa-cog ms-1"></i> إدارة البطولة
                                </a>
                               
                                <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
                                    <a href="setup_matches.php?tour_id=<?php echo $row['id']; ?>" class="btn btn-icon-action rounded-circle flex-shrink-0" title="عرض وتعديل الترتيب والمباريات">
                                        <i class="fas fa-table"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-info text-center py-5 rounded-4 shadow-sm border-0">
                    <i class="fas fa-info-circle fa-3x text-info mb-3"></i>
                    <h5 class="fw-bold text-dark">لا توجد بطولات</h5>
                    <p class="text-muted mb-0">لا توجد بطولات منشأة حالياً في النظام. يمكنك البدء بإضافة بطولتك الأولى!</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'footer.php'; ?>