<?php
include 'db.php';

if (isset($_POST['save_result'])) {
    $match_id = (int)$_POST['match_id'];
    $score_home = (int)$_POST['score_home'];
    $score_away = (int)$_POST['score_away'];

    // 1. تحديث نتيجة المباراة الحالية
    $update_q = "UPDATE matches SET 
                 score_home = $score_home, 
                 score_away = $score_away, 
                 is_finished = 1 
                 WHERE id = $match_id";
    mysqli_query($conn, $update_q);

    // تحديد الفائز (ID الفريق)
    $winner_id = 0;
    if ($score_home > $score_away) {
        $winner_id = $_POST['team_home_id'];
    } elseif ($score_away > $score_home) {
        $winner_id = $_POST['team_away_id'];
    }

    // 2. إذا كانت مباراة إقصائية، نبحث عن المباراة التالية المرتبطة بها
    // نحتاج لمعرفة رقم المباراة الحالية في دورها (مثلاً هي كانت المباراة رقم 1 في الدور 1)
    $current_match_info = mysqli_fetch_assoc(mysqli_query($conn, "SELECT round_level, tournament_id FROM matches WHERE id = $match_id"));
    $round = $current_match_info['round_level'];
    $tournament_id = $current_match_info['tournament_id'];

    // الحصول على ترتيب المباراة الحالية بالنسبة لمباريات نفس الدور (لنعرف رقمها M1, M2...)
    $all_round_matches = mysqli_query($conn, "SELECT id FROM matches WHERE tournament_id = $tournament_id AND round_level = $round ORDER BY id ASC");
    $match_index = 0;
    $i = 1;
    while($row = mysqli_fetch_assoc($all_round_matches)) {
        if($row['id'] == $match_id) { $match_index = $i; break; }
        $i++;
    }

    if ($winner_id > 0) {
        // نبحث عن المباراة في الدور التالي (Round + 1) التي تنتظر الفائز من R[current]_M[index]
        $source_string = "R{$round}_M{$match_index}";

        // تحديث المباراة التالية إذا كان الفائز هو الفريق صاحب الأرض (Home) في الماتش الجاي
        mysqli_query($conn, "UPDATE matches SET team_home_id = $winner_id 
                             WHERE tournament_id = $tournament_id AND home_source = '$source_string'");

        // تحديث المباراة التالية إذا كان الفائز هو الفريق الضيف (Away) في الماتش الجاي
        mysqli_query($conn, "UPDATE matches SET team_away_id = $winner_id 
                             WHERE tournament_id = $tournament_id AND away_source = '$source_string'");
    }

    echo "<script>alert('تم حفظ النتيجة وترحيل الفائز بنجاح'); window.location='matches_list.php';</script>";
}
?>