<?php 
include 'db.php'; 
include 'header.php'; 

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<div class='alert alert-danger text-center mt-5'>لم يتم تحديد فريق.</div>";
    include 'footer.php'; exit;
}

$team_id = mysqli_real_escape_string($conn, $_GET['id']);

// 1. جلب بيانات الفريق
$team_q = mysqli_query($conn, "SELECT * FROM teams WHERE id = $team_id");
$team = mysqli_fetch_assoc($team_q);

// 2. إحصائيات عامة محسوبة
$totals = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT 
        COUNT(*) as total_m,
        SUM(CASE WHEN (team_home_id = $team_id AND score_home > score_away) OR (team_away_id = $team_id AND score_away > score_home) THEN 1 ELSE 0 END) as wins,
        SUM(CASE WHEN score_home = score_away THEN 1 ELSE 0 END) as draws,
        SUM(CASE WHEN (team_home_id = $team_id AND score_home < score_away) OR (team_away_id = $team_id AND score_away < score_home) THEN 1 ELSE 0 END) as losses
    FROM matches WHERE (team_home_id = $team_id OR team_away_id = $team_id) AND status = 'finished'
"));

// جلب قائمة البطولات للفريق لاستخدامها في الفلاتر
$tours_sql = "SELECT DISTINCT tr.* FROM tournaments tr JOIN matches m ON tr.id = m.tournament_id WHERE m.team_home_id = $team_id OR m.team_away_id = $team_id";
$tours_res = mysqli_query($conn, $tours_sql);
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

<style>
    :root {
        --primary-color: #1a237e;
        --accent-color: #00d2ff;
        --bg-light: #f8f9fa;
    }

    body { background-color: var(--bg-light); font-family: 'Cairo', sans-serif; }

    /* هيدر الفريق الاحترافي */
    .hero-card {
        background: linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%);
        border-radius: 0 0 40px 40px;
        padding: 60px 20px 100px 20px; /* زيادة البادينج السفلي لمنع التداخل */
        color: white;
        position: relative;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    }

    .signature-brand {
        position: absolute;
        top: 20px;
        left: 30px;
        opacity: 0.2;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: 2px;
        font-size: 0.8rem;
    }

    .logo-container {
        background: white;
        width: 120px; height: 120px;
        border-radius: 25px;
        padding: 15px;
        display: inline-flex;
        align-items: center; justify-content: center;
        box-shadow: 0 8px 20px rgba(0,0,0,0.2);
        margin-bottom: 20px;
    }

    /* حل مشكلة التداخل في التبويبات */
    .tabs-wrapper {
        margin-top: -45px; /* رفع التبويبات قليلاً فوق الهيدر بشكل جمالي */
        position: relative;
        z-index: 10;
        text-align: center;
        margin-bottom: 40px;
    }

    .nav-pills-custom {
        background: white;
        display: inline-flex;
        padding: 8px;
        border-radius: 50px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        gap: 5px;
    }

    /* تعديل ألوان الخطوط لتكون واضحة جداً */
    .nav-pills-custom .nav-link {
        border-radius: 50px;
        padding: 12px 25px;
        font-weight: 700;
        color: #2c3e50 !important; /* لون داكن واضح */
        transition: 0.3s;
        border: none;
        background: transparent;
    }

    .nav-pills-custom .nav-link.active {
        background: var(--primary-color) !important;
        color: white !important;
        box-shadow: 0 5px 15px rgba(26, 35, 126, 0.4);
    }

    /* البطاقات التفاعلية */
    .data-card {
        background: white;
        border: none;
        border-radius: 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        transition: 0.3s ease;
        overflow: hidden;
        cursor: pointer;
    }
    .data-card:hover { transform: translateY(-8px); box-shadow: 0 12px 30px rgba(0,0,0,0.1); }

    .match-row {
        border-radius: 15px;
        background: white;
        margin-bottom: 12px;
        padding: 15px;
        border-right: 5px solid #ddd;
        transition: 0.3s;
    }
    .match-row:hover { transform: scale(1.01); background: #fdfdfd; }
</style>

<div class="hero-card animate__animated animate__fadeInDown">
    <div class="signature-brand">BY: Ibrahim Elkhooly</div>
    <div class="container text-center">
        <div class="logo-container animate__animated animate__zoomIn animate__delay-1s">
            <img src="uploads/logos/<?php echo $team['logo']; ?>" style="max-width: 100%; max-height: 100%;">
        </div>
        <h1 class="fw-bold mb-0 text-white"><?php echo $team['team_name']; ?></h1>
        <div class="d-flex justify-content-center gap-4 mt-4">
            <div class="text-center"><h4 class="mb-0"><?php echo $totals['total_m']; ?></h4><small>مباراة</small></div>
            <div class="text-center text-success"><h4 class="mb-0"><?php echo $totals['wins']; ?></h4><small>فوز</small></div>
            <div class="text-center text-warning"><h4 class="mb-0"><?php echo $totals['draws']; ?></h4><small>تعادل</small></div>
            <div class="text-center text-danger"><h4 class="mb-0"><?php echo $totals['losses']; ?></h4><small>خسارة</small></div>
        </div>
    </div>
</div>

<div class="container">
    <div class="tabs-wrapper animate__animated animate__fadeInUp animate__delay-1s">
       <ul class="nav nav-pills nav-pills-custom shadow" id="mainTabs">
  		  <li class="nav-item"><button class="nav-link active" data-bs-toggle="pill" data-bs-target="#tab-players">التشكيلة</button></li>
    	  <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-matches">المباريات</button></li>
   	 	  <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-standings">الترتيب</button></li>
  		  <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-scorers">الهدافين والأفضل</button></li>
  		  <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-tours">البطولات</button></li>
	</ul>

    </div>

    <div class="tab-content">
        
        <div class="tab-pane fade show active" id="tab-players">
            <div class="row g-4">
                <?php 
                $players = mysqli_query($conn, "SELECT * FROM players WHERE team_id = $team_id ORDER BY FIELD(position, 'GK', 'DF', 'MF', 'FW')");
                while($p = mysqli_fetch_assoc($players)): ?>
                <div class="col-md-4 col-lg-3 animate__animated animate__fadeInUp">
                    <div class="data-card p-3 text-center" onclick="location.href='player_profile.php?id=<?php echo $p['id']; ?>'">
                        <img src="uploads/players/<?php echo $p['image'] ?: 'default.png'; ?>" class="rounded-circle mb-3 border border-3 border-info" width="80" height="80" style="object-fit: cover;">
                        <h6 class="fw-bold mb-0"><?php echo $p['player_name']; ?></h6>
                        <small class="text-muted"><?php echo $p['position']; ?></small>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>

        <div class="tab-pane fade" id="tab-matches">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <?php 
                    $matches = mysqli_query($conn, "SELECT m.*, t1.team_name as h_name, t1.logo as h_logo, t2.team_name as a_name, t2.logo as a_logo FROM matches m JOIN teams t1 ON m.team_home_id = t1.id JOIN teams t2 ON m.team_away_id = t2.id WHERE team_home_id = $team_id OR team_away_id = $team_id ORDER BY match_date DESC");
                    while($m = mysqli_fetch_assoc($matches)): 
                        $res_color = ($m['score_home'] == $m['score_away']) ? '#ffc107' : (($m['team_home_id'] == $team_id && $m['score_home'] > $m['score_away']) || ($m['team_away_id'] == $team_id && $m['score_away'] > $m['score_home']) ? '#28a745' : '#dc3545');
                    ?>
                    <div class="match-row shadow-sm d-flex align-items-center text-center" onclick="location.href='match_details.php?id=<?php echo $m['id']; ?>'" style="border-right-color: <?php echo $res_color; ?>; cursor:pointer;">
                        <div class="col-4 d-flex align-items-center justify-content-end">
                            <span class="fw-bold me-2"><?php echo $m['h_name']; ?></span>
                            <img src="uploads/logos/<?php echo $m['h_logo']; ?>" width="35" height="35">
                        </div>
                        <div class="col-4">
                            <span class="badge bg-dark px-3 py-2"><?php echo $m['score_home']; ?> - <?php echo $m['score_away']; ?></span>
                            <div class="small text-muted mt-1"><?php echo date('d/m/Y', strtotime($m['match_date'])); ?></div>
                        </div>
                        <div class="col-4 d-flex align-items-center">
                            <img src="uploads/logos/<?php echo $m['a_logo']; ?>" width="35" height="35">
                            <span class="fw-bold ms-2"><?php echo $m['a_name']; ?></span>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>

        <div class="tab-pane fade" id="tab-scorers">
            <div class="card data-card p-4">
                <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
                    <h5 class="fw-bold mb-0">ترتيب اللاعبين بالأهداف والتقييم</h5>
                    <select id="tourFilter" class="form-select w-auto" onchange="filterDynamic()">
                        <option value="all">كل البطولات مجموع</option>
                        <?php 
                        mysqli_data_seek($tours_res, 0);
                        while($tr = mysqli_fetch_assoc($tours_res)) echo "<option value='tour-".$tr['id']."'>".$tr['name']."</option>";
                        ?>
                    </select>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>اللاعب</th>
                                <th class="text-center">الأهداف</th>
                                <th class="text-center">الأسيست</th>
                                <th class="text-center">متوسط التقييم</th>
                            </tr>
                        </thead>
                        <tbody id="dynamicBody"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="tab-pane fade" id="tab-tours">
            <div class="row g-4">
                <?php 
                mysqli_data_seek($tours_res, 0);
                while($tr = mysqli_fetch_assoc($tours_res)):
                    $tid = $tr['id'];
                    $m_real = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM matches WHERE tournament_id = $tid AND (team_home_id = $team_id OR team_away_id = $team_id)"))['c'];
                    $avg_real = mysqli_fetch_assoc(mysqli_query($conn, "SELECT AVG(rating) as r FROM player_match_stats ps JOIN matches m ON ps.match_id = m.id WHERE m.tournament_id = $tid AND ps.player_id IN (SELECT id FROM players WHERE team_id = $team_id)"))['r'];
                ?>
                <div class="col-md-6 animate__animated animate__zoomIn">
                    <div class="data-card overflow-hidden">
                        <div class="bg-primary p-3 text-white fw-bold">🏆 <?php echo $tr['name']; ?></div>
                        <div class="p-3 row text-center">
                            <div class="col-4 border-end"><h6>المباريات</h6><h4 class="fw-bold"><?php echo $m_real; ?></h4></div>
                            <div class="col-4 border-end"><h6>أداء الفريق</h6><h4 class="fw-bold text-primary"><?php echo number_format($avg_real, 1); ?></h4></div>
                            <div class="col-4"><h6>الأهداف</h6>
                                <?php 
                                $goal_c = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM goals g JOIN matches m ON g.match_id = m.id WHERE m.tournament_id = $tid AND g.player_id IN (SELECT id FROM players WHERE team_id = $team_id)"))['c'];
                                echo "<h4 class='fw-bold text-success'>$goal_c</h4>";
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>

    </div>
</div>

<?php 
// تجهيز البيانات لـ JS
$data_sql = "SELECT p.id, p.player_name, p.image, m.tournament_id, 
                    COUNT(DISTINCT CASE WHEN g.player_id = p.id THEN g.id END) as goals,
                    COUNT(DISTINCT CASE WHEN g.assist_player_id = p.id THEN g.id END) as assists,
                    AVG(ps.rating) as avg_rating
             FROM players p
             LEFT JOIN goals g ON (p.id = g.player_id OR p.id = g.assist_player_id)
             LEFT JOIN player_match_stats ps ON p.id = ps.player_id
             LEFT JOIN matches m ON (g.match_id = m.id OR ps.match_id = m.id)
             WHERE p.team_id = $team_id
             GROUP BY p.id, m.tournament_id";
$data_res = mysqli_query($conn, $data_sql);
$player_data = [];
while($r = mysqli_fetch_assoc($data_res)) { $player_data[] = $r; }
?>

<script>
const rawData = <?php echo json_encode($player_data); ?>;

function filterDynamic() {
    const filter = document.getElementById('tourFilter').value;
    const body = document.getElementById('dynamicBody');
    body.innerHTML = '';
    let processed = {};

    rawData.forEach(item => {
        const tourKey = 'tour-' + item.tournament_id;
        if (filter === 'all' || tourKey === filter) {
            if (!processed[item.id]) {
                processed[item.id] = { name: item.player_name, img: item.image || 'default.png', goals: 0, assists: 0, ratings: [], id: item.id };
            }
            processed[item.id].goals += parseInt(item.goals) || 0;
            processed[item.id].assists += parseInt(item.assists) || 0;
            if(item.avg_rating) processed[item.id].ratings.push(parseFloat(item.avg_rating));
        }
    });

    let sorted = Object.values(processed).sort((a, b) => b.goals - a.goals || (b.ratings.length ? (b.ratings.reduce((x,y)=>x+y)/b.ratings.length) : 0) - (a.ratings.length ? (a.ratings.reduce((x,y)=>x+y)/a.ratings.length) : 0));

    sorted.forEach(p => {
        let avg = p.ratings.length ? (p.ratings.reduce((a,b) => a+b) / p.ratings.length).toFixed(1) : '0.0';
        body.innerHTML += `
            <tr onclick="location.href='player_profile.php?id=${p.id}'" style="cursor:pointer">
                <td><img src="uploads/players/${p.img}" class="rounded-circle me-2 border" width="35" height="35"> <b>${p.name}</b></td>
                <td class="text-center"><span class="badge bg-success">${p.goals}</span></td>
                <td class="text-center"><span class="badge bg-info text-dark">${p.assists}</span></td>
                <td class="text-center fw-bold text-primary">${avg} ⭐</td>
            </tr>`;
    });
}
window.onload = filterDynamic;
</script>

<?php include 'footer.php'; ?>







<div class="tab-pane fade" id="tab-tours">
</div>

<div class="tab-pane fade" id="tab-tours">
     <div class="row g-4">
     </div>
 </div>