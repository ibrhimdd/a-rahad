<?php
include 'db.php';

if (isset($_POST['generate_advanced'])) {
    $tournament_id = $_POST['tournament_id'];
    $teams = $_POST['teams'];
    $type = $_POST['type'];
    
    if (count($teams) < 2) die("خطأ: اختر فريقين على الأقل.");

    $default_date = date('Y-m-d H:i:s');
    $default_text = "يحدد لاحقاً";

    if ($type === 'league') {
        generateRoundRobin($teams, $tournament_id, $conn, $default_date, $default_text);
    } else {
        $num_groups = intval($_POST['num_groups']);
        shuffle($teams); 
        $groups = array_chunk($teams, ceil(count($teams) / $num_groups));
        foreach ($groups as $group_teams) {
            generateRoundRobin($group_teams, $tournament_id, $conn, $default_date, $default_text);
        }
    }

    header("Location: setup_matches.php?tour_id=$tournament_id");
    exit();
}

function generateRoundRobin($teams, $tour_id, $conn, $date, $text) {
    if (count($teams) % 2 != 0) $teams[] = "BYE";
    $count = count($teams);
    $rounds = $count - 1;

    for ($i = 0; $i < $rounds; $i++) {
        for ($j = 0; $j < $count / 2; $j++) {
            $home = $teams[$j];
            $away = $teams[$count - 1 - $j];

            if ($home !== "BYE" && $away !== "BYE" && $home != $away) {
                // تعديل: استخدام referee_id بدلاً من referee
                $sql = "INSERT INTO matches (tournament_id, team_home_id, team_away_id, match_date, referee_id, commentator, status, score_home, score_away, stadium) 
                        VALUES ('$tour_id', '$home', '$away', '$date', '1', '$text', 'pending', 0, 0, 'يحدد لاحقاً')";
                
                if (!mysqli_query($conn, $sql)) {
                    die("خطأ في الإدخال: " . mysqli_error($conn));
                }
            }
        }
        $last = array_pop($teams);
        array_splice($teams, 1, 0, [$last]);
    }
}
?>