<?php 
include 'db.php'; 
include 'header.php'; 

// 1. فحص هل هو أدمن عام للنظام؟
$is_super_admin = (isset($_SESSION['role']) && $_SESSION['role'] == 'admin');

// 2. فحص هل هو ادمن فريق (قمنا بالبحث عن أي سيشن فريق متوثق عنده)
$team_id_from_url = isset($_GET['team_id']) ? intval($_GET['team_id']) : 0;
$authorized_team_id = 0;

// البحث عن الفريق المصرح به في السيشن
if ($team_id_from_url > 0 && isset($_SESSION['team_auth_' . $team_id_from_url]) && $_SESSION['team_auth_' . $team_id_from_url] === true) {
    $authorized_team_id = $team_id_from_url;
} else {
    // لو لم يتم القراءة من الـ URL، نبحث في كل السيشنز المتاحة
    foreach ($_SESSION as $key => $value) {
        if (strpos($key, 'team_auth_') === 0 && $value === true) {
            $authorized_team_id = intval(str_replace('team_auth_', '', $key));
            break;
        }
    }
}

// 3. منع الوصول إذا لم يكن أدمن عام ولا يملك سيشن فريق موثق
if (!$is_super_admin && $authorized_team_id == 0) {
    echo "<div class='container mt-5'><div class='alert alert-danger text-center fw-bold'>عذراً، غير مسموح لك بالدخول لهذه الصفحة. يجب إدخال الرقم السري للفريق أولاً من صفحة الفريق.</div></div>";
    include 'footer.php';
    exit;
}

// جلب اسم الفريق المحدد تلقائياً لـ ادمن الفريق
$team_name_fixed = "";
if ($authorized_team_id > 0) {
    $t_q = mysqli_query($conn, "SELECT team_name FROM teams WHERE id = $authorized_team_id");
    if ($t_row = mysqli_fetch_assoc($t_q)) {
        $team_name_fixed = $t_row['team_name'];
    }
}
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm p-4 border-0">
            <h3 class="text-center mb-4"><i class="fas fa-user-plus text-success me-2"></i> إشهار / إضافة لاعب جديد</h3>
            
            <form action="save_player.php" method="POST" enctype="multipart/form-data">
                
                <div class="mb-3">
                    <label class="form-label fw-bold">اسم اللاعب</label>
                    <input type="text" name="player_name" class="form-control" placeholder="اسم اللاعب الثلاثي" required>
                </div>

                <!-- حقل اختيار أو تثبيت الفريق بناءً على الصلاحية -->
                <div class="mb-3">
                    <label class="form-label fw-bold">الفريق</label>
                    
                    <?php if ($is_super_admin): ?>
                        <!-- الأدمن العام يختار أي فريق -->
                        <select name="team_id" class="form-select" required>
                            <option value="">اختر الفريق...</option>
                            <?php
                            $res = mysqli_query($conn, "SELECT * FROM teams");
                            while($row = mysqli_fetch_assoc($res)) {
                                $selected = ($row['id'] == $authorized_team_id) ? 'selected' : '';
                                echo "<option value='".$row['id']."' $selected>".$row['team_name']."</option>";
                            }
                            ?>
                        </select>
                    <?php else: ?>
                        <!-- ادمن الفريق محدد له الفريق تلقائياً ومغلق للعدم التغيير -->
                        <input type="text" class="form-control bg-light fw-bold text-primary" value="<?php echo $team_name_fixed; ?>" readonly>
                        <input type="hidden" name="team_id" value="<?php echo $authorized_team_id; ?>">
                    <?php endif; ?>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">المركز (Position)</label>
                    <select name="position" class="form-select">
                        <option value="GK">حارس مرمى (GK)</option>
                        <option value="DF">دفاع (DF)</option>
                        <option value="MF">وسط (MF)</option>
                        <option value="FW">هجوم (FW)</option>
                    </select>
                </div>

                <!-- رقم قميص اللاعب -->
                <div class="mb-3">
                    <label class="form-label fw-bold">رقم القميص (التيشيرت)</label>
                    <input type="number" name="shirt_number" class="form-control" min="1" max="99" placeholder="مثال: 10">
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">صورة اللاعب</label>
                    <input type="file" name="player_image" class="form-control">
                </div>

                <button type="submit" class="btn btn-success w-100 py-2 fw-bold">تسجيل اللاعب</button>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>