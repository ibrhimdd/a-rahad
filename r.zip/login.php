<?php
include 'db.php';
session_start();

if (isset($_POST['login'])) {
    $user = mysqli_real_escape_string($conn, $_POST['username']);
    $pass = $_POST['password'];

    $result = mysqli_query($conn, "SELECT * FROM users WHERE username='$user'");
    if ($row = mysqli_fetch_assoc($result)) {
        if (password_verify($pass, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = $row['role'];
            header("Location: index.php");
            exit();
        }
    }
    $error = "بيانات الدخول غير صحيحة!";
}
?>
<?php include 'header.php'; ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card border-0 shadow-lg rounded-4 p-4">
                <h3 class="text-center fw-bold mb-4">تسجيل الدخول</h3>
                <?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label small">اسم المستخدم</label>
                        <input type="text" name="username" class="form-control rounded-pill" required>
                    </div>
                    <div class="mb-4">
                        <label class="form-label small">كلمة المرور</label>
                        <input type="password" name="password" class="form-control rounded-pill" required>
                    </div>
                    <button type="submit" name="login" class="btn btn-primary w-100 rounded-pill py-2 fw-bold">دخول</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>