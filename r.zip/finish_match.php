<?php
include 'db.php';
include 'header.php';

$match_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$match_id) {
    echo "<div class='container py-5'><div class='alert alert-danger text-center'>لم يتم تحديد مباراة.</div></div>";
    include 'footer.php';
    exit;
}

// جلب تفاصيل المباراة
$match_q = mysqli_query($conn, "SELECT m.*, t1.team_name as home_name, t2.team_name as away_name 
                                FROM matches m 
                                JOIN teams t1 ON m.team_home_id = t1.id 
                                JOIN teams t2 ON m.team_away_id = t2.id 
                                WHERE m.id = $match_id");
$match = mysqli_fetch_assoc($match_q);

if (!$match) {
    echo "<div class='container py-5'><div class='alert alert-danger text-center'>المباراة غير موجودة.</div></div>";
    include 'footer.php';
    exit;
}

// 1. معالجة حذف هدف
if (isset($_GET['action']) && $_GET['action'] === 'delete_goal' && isset($_GET['goal_id'])) {
    $goal_id = intval($_GET['goal_id']);
    
    $g_q = mysqli_query($conn, "SELECT team_id FROM goals WHERE id = $goal_id AND match_id = $match_id");
    if ($g_data = mysqli_fetch_assoc($g_q)) {
        $goal_team_id = intval($g_data['team_id']);
        
        mysqli_query($conn, "DELETE FROM goals WHERE id = $goal_id AND match_id = $match_id");
        
        $m_q = mysqli_query($conn, "SELECT team_home_id FROM matches WHERE id = $match_id");
        $m_data = mysqli_fetch_assoc($m_q);
        
        if ($goal_team_id === intval($m_data['team_home_id'])) {
            mysqli_query($conn, "UPDATE matches SET score_home = GREATEST(0, score_home - 1) WHERE id = $match_id");
        } else {
            mysqli_query($conn, "UPDATE matches SET score_away = GREATEST(0, score_away - 1) WHERE id = $match_id");
        }
    }

    header("Location: " . $_SERVER['PHP_SELF'] . "?id=" . $match_id);
    exit;
}

// 2. معالجة حفظ البيانات والعمليات الحية (POST)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // تحديث حالة المباراة والنتيجة المباشرة
    if (isset($_POST['status'])) {
        $status = mysqli_real_escape_string($conn, $_POST['status']);
        $score_home = isset($_POST['score_home']) ? intval($_POST['score_home']) : (int)$match['score_home'];
        $score_away = isset($_POST['score_away']) ? intval($_POST['score_away']) : (int)$match['score_away'];
        
        mysqli_query($conn, "UPDATE matches SET status = '$status', score_home = $score_home, score_away = $score_away WHERE id = $match_id");

        // ==========================================
        // 🚀 معالجة احتساب نقاط التوقعات عند إنهاء المباراة
        // ==========================================
        if ($status === 'finished') {
            $actual_result = '';
            if ($score_home > $score_away) {
                $actual_result = 'home_win';
            } else if ($score_away > $score_home) {
                $actual_result = 'away_win';
            } else {
                $actual_result = 'draw';
            }

            $tournament_id = intval($match['tournament_id']);
            $points_for_correct = 3; // عدد النقاط المستحقة للتوقع الصحيح

            // جلب التوقعات التي لم تحسب لها نقاط بعد لهذه المباراة
            $preds_q = mysqli_query($conn, "SELECT id, user_id, predicted_result FROM predictions WHERE match_id = $match_id AND points_awarded = 0");

            if ($preds_q && mysqli_num_rows($preds_q) > 0) {
                while ($pred = mysqli_fetch_assoc($preds_q)) {
                    if ($pred['predicted_result'] === $actual_result) {
                        $p_user_id = intval($pred['user_id']);
                        $pred_id = intval($pred['id']);

                        // 1. تسجيل النقاط في سجل التوقع
                        mysqli_query($conn, "UPDATE predictions SET points_awarded = $points_for_correct WHERE id = $pred_id");

                        // 2. تحديث إجمالي نقاط المستخدم الخاصة بهذه البطولة
                        mysqli_query($conn, "
                            INSERT INTO user_tournament_points (user_id, tournament_id, total_points) 
                            VALUES ($p_user_id, $tournament_id, $points_for_correct)
                            ON DUPLICATE KEY UPDATE total_points = total_points + $points_for_correct
                        ");
                    }
                }
            }
        }
    }

    // إضافة هدف جديد
    if (!empty($_POST['goal_player_id'])) {
        $p_id = intval($_POST['goal_player_id']);
        $goal_minute = intval($_POST['goal_minute']);
        $goal_type = mysqli_real_escape_string($conn, $_POST['goal_type']);
        $a_id_val = !empty($_POST['assist_player_id']) ? intval($_POST['assist_player_id']) : "NULL";
        
        $p_team_q = mysqli_query($conn, "SELECT team_id FROM players WHERE id = $p_id");
        $p_team = mysqli_fetch_assoc($p_team_q);
        $player_team_id = intval($p_team['team_id']);
        
        $match_info_q = mysqli_query($conn, "SELECT team_home_id, team_away_id FROM matches WHERE id = $match_id");
        $match_info = mysqli_fetch_assoc($match_info_q);
        
        $home_id = intval($match_info['team_home_id']);
        $away_id = intval($match_info['team_away_id']);

        $target_team_id = $player_team_id;

        if ($goal_type === 'own_goal') {
            $target_team_id = ($player_team_id === $home_id) ? $away_id : $home_id;
        }

        $insert_goal_sql = "INSERT INTO goals (match_id, team_id, player_id, assist_player_id, goal_minute, goal_type) 
                            VALUES ($match_id, $target_team_id, $p_id, $a_id_val, $goal_minute, '$goal_type')";
        
        if (mysqli_query($conn, $insert_goal_sql)) {
            if ($target_team_id === $home_id) {
                mysqli_query($conn, "UPDATE matches SET score_home = score_home + 1 WHERE id = $match_id");
            } else if ($target_team_id === $away_id) {
                mysqli_query($conn, "UPDATE matches SET score_away = score_away + 1 WHERE id = $match_id");
            }
        }
    }

    // إضافة تبديل جديد
    if (!empty($_POST['sub_player_out']) && !empty($_POST['sub_player_in'])) {
        $p_out = intval($_POST['sub_player_out']);
        $p_in = intval($_POST['sub_player_in']);
        
        $p_team_q = mysqli_query($conn, "SELECT team_id FROM players WHERE id = $p_out");
        $p_team = mysqli_fetch_assoc($p_team_q);
        $team_id = intval($p_team['team_id']);
        
        $min = !empty($_POST['sub_minute']) ? intval($_POST['sub_minute']) : 0;
        
        mysqli_query($conn, "INSERT INTO substitutions (match_id, team_id, player_out_id, player_in_id, minute) 
                             VALUES ($match_id, $team_id, $p_out, $p_in, $min)");
    }

    // إضافة إنذارات
    if (!empty($_POST['card_player_id'])) {
        $c_p_id = intval($_POST['card_player_id']);
        
        $p_team_q = mysqli_query($conn, "SELECT team_id FROM players WHERE id = $c_p_id");
        $p_team = mysqli_fetch_assoc($p_team_q);
        $c_team_id = intval($p_team['team_id']);
        
        $c_type = mysqli_real_escape_string($conn, $_POST['card_type']);
        $c_min = !empty($_POST['card_minute']) ? intval($_POST['card_minute']) : 0;

        mysqli_query($conn, "INSERT INTO cards (match_id, team_id, player_id, card_type, minute) 
                             VALUES ($match_id, $c_team_id, $c_p_id, '$c_type', $c_min)");
    }

    // حفظ الإحصائيات
    if (isset($_POST['home_possession'])) {
        $h_pos = intval($_POST['home_possession']);
        $a_pos = intval($_POST['away_possession']);
        $h_shots = intval($_POST['home_shots']);
        $a_shots = intval($_POST['away_shots']);
        $h_target = intval($_POST['home_shots_on_target']);
        $a_target = intval($_POST['away_shots_on_target']);
        $h_corners = intval($_POST['home_corners']);
        $a_corners = intval($_POST['away_corners']);

        mysqli_query($conn, "DELETE FROM match_stats WHERE match_id = $match_id");
        mysqli_query($conn, "INSERT INTO match_stats (match_id, home_possession, away_possession, home_shots, away_shots, home_shots_on_target, away_shots_on_target, home_corners, away_corners) 
                             VALUES ($match_id, $h_pos, $a_pos, $h_shots, $a_shots, $h_target, $a_target, $h_corners, $a_corners)");
    }

    // حفظ التقييمات و MVP
    if (isset($_POST['ratings']) && is_array($_POST['ratings'])) {
        $mvp_player_id = isset($_POST['is_mvp']) ? intval($_POST['is_mvp']) : 0;

        mysqli_query($conn, "DELETE FROM player_match_stats WHERE match_id = $match_id");

        foreach ($_POST['ratings'] as $p_id => $rating_val) {
            $p_id = intval($p_id);
            $rating_val = floatval($rating_val);
            $is_mvp = ($p_id == $mvp_player_id) ? 1 : 0;

            mysqli_query($conn, "INSERT INTO player_match_stats (match_id, player_id, rating, is_mvp) 
                                 VALUES ($match_id, $p_id, $rating_val, $is_mvp)");
        }
    }

    echo "<script>alert('تم التحديث وحفظ البيانات وبناء النقاط بنجاح!'); window.location.href='finish_match.php?id=$match_id';</script>";
}

// جلب جميع لاعبي الفريقين
$players_q = mysqli_query($conn, "SELECT id, player_name, team_id FROM players WHERE team_id IN ({$match['team_home_id']}, {$match['team_away_id']}) ORDER BY team_id, player_name");
$players = [];
while($p = mysqli_fetch_assoc($players_q)) { $players[] = $p; }

// جلب الإحصائيات الحالية
$stats_q = mysqli_query($conn, "SELECT * FROM match_stats WHERE match_id = $match_id");
$current_stats = mysqli_fetch_assoc($stats_q);
?>

<!-- تنسيقات اختصاصية للثيم الداكن الخاص بمربعات الإدخال والمودال -->
<style>
    .form-control, .form-select {
        background-color: #121829 !important;
        color: #ffffff !important;
        border: 1px solid rgba(255, 255, 255, 0.15) !important;
    }
    .form-control:focus, .form-select:focus {
        background-color: #1a2238 !important;
        color: #ffffff !important;
        border-color: #00d285 !important;
        box-shadow: 0 0 0 0.25rem rgba(0, 210, 133, 0.25) !important;
    }
    .form-select option {
        background-color: #1a2238 !important;
        color: #ffffff !important;
    }
    .card-header {
        border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
    }
    .dark-box {
        background-color: #121829 !important;
        border: 1px solid rgba(255, 255, 255, 0.08) !important;
    }
</style>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold mb-0">إدارة المباراة: <span class="text-success" style="color: #00d285 !important;"><?php echo htmlspecialchars($match['home_name']) . " vs " . htmlspecialchars($match['away_name']); ?></span></h3>
        <a href="match_details.php?id=<?php echo $match_id; ?>" class="btn btn-outline-light btn-sm rounded-pill px-3" target="_blank"><i class="fas fa-external-link-alt me-1"></i> معاينة شاشة العرض</a>
    </div>

    <form method="POST">
        <!-- 1. النتيجة وحالة المباراة -->
        <div class="card shadow-sm mb-4 border-0">
            <div class="card-header bg-dark text-white fw-bold">النتيجة وحالة المباراة</div>
            <div class="card-body">
                <div class="row text-center align-items-center">
                    <div class="col-md-4 mb-3 mb-md-0">
                        <label class="fw-bold mb-1 text-white"><?php echo htmlspecialchars($match['home_name']); ?></label>
                        <input type="number" name="score_home" class="form-control form-control-lg text-center fw-bold" value="<?php echo (int)$match['score_home']; ?>" required>
                    </div>
                    <div class="col-md-4 mb-3 mb-md-0">
                        <label class="fw-bold mb-1 text-white">حالة اللقاء</label>
                        <select name="status" class="form-select text-center fw-bold">
                            <option value="upcoming" <?php if($match['status']=='upcoming') echo 'selected'; ?>>قادمة</option>
                            <option value="live" <?php if($match['status']=='live') echo 'selected'; ?>>مباشر الآن 🔴</option>
                            <option value="finished" <?php if($match['status']=='finished') echo 'selected'; ?>>انتهت المباراة</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="fw-bold mb-1 text-white"><?php echo htmlspecialchars($match['away_name']); ?></label>
                        <input type="number" name="score_away" class="form-control form-control-lg text-center fw-bold" value="<?php echo (int)$match['score_away']; ?>" required>
                    </div>
                </div>
            </div>
        </div>

        <!-- 2. إضافة أهداف / تبديلات / إنذارات -->
        <div class="row">
            <!-- تسجيل هدف -->
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm h-100 border-0">
                    <div class="card-header bg-success text-white fw-bold"><i class="fas fa-futbol me-1"></i> تسجِيل هدف</div>
                    <div class="card-body">
                        <div class="mb-2">
                            <label class="small text-light">مسجل الهدف</label>
                            <select name="goal_player_id" class="form-select">
                                <option value="">اختر اللاعب...</option>
                                <?php foreach($players as $p): ?>
                                    <option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['player_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-2">
                            <label class="small text-light">صانع الهدف (اختياري)</label>
                            <select name="assist_player_id" class="form-select">
                                <option value="">بدون صانع...</option>
                                <?php foreach($players as $p): ?>
                                    <option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['player_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-2">
                            <label class="small text-light">نوع الهدف</label>
                            <select name="goal_type" class="form-select">
                                <option value="normal">هدف عادي ⚽</option>
                                <option value="penalty">ضربة جزاء 🎯</option>
                                <option value="own_goal">هدف في مرماه ❌</option>
                            </select>
                        </div>
                        <div>
                            <label class="small text-light">الدقيقة</label>
                            <input type="number" name="goal_minute" class="form-control" placeholder="مثال: 45">
                        </div>
                    </div>
                </div>
            </div>

            <!-- تسجيل تبديل -->
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm h-100 border-0">
                    <div class="card-header bg-warning text-dark fw-bold"><i class="fas fa-exchange-alt me-1"></i> تسجِيل تبديل</div>
                    <div class="card-body">
                        <div class="mb-2">
                            <label class="small text-light">اللاعب الخارج 🔴</label>
                            <select name="sub_player_out" class="form-select">
                                <option value="">اختر اللاعب...</option>
                                <?php foreach($players as $p): ?>
                                    <option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['player_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-2">
                            <label class="small text-light">اللاعب الداخل 🟢</label>
                            <select name="sub_player_in" class="form-select">
                                <option value="">اختر اللاعب...</option>
                                <?php foreach($players as $p): ?>
                                    <option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['player_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mt-4">
                            <label class="small text-light">الدقيقة</label>
                            <input type="number" name="sub_minute" class="form-control" placeholder="مثال: 60">
                        </div>
                    </div>
                </div>
            </div>

            <!-- تسجيل بطاقة -->
            <div class="col-md-4 mb-4">
                <div class="card shadow-sm h-100 border-0">
                    <div class="card-header bg-danger text-white fw-bold"><i class="fas fa-clone me-1"></i> تسجِيل إنذار / بطاقة</div>
                    <div class="card-body">
                        <div class="mb-2">
                            <label class="small text-light">اللاعب المستحق</label>
                            <select name="card_player_id" class="form-select">
                                <option value="">اختر اللاعب...</option>
                                <?php foreach($players as $p): ?>
                                    <option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['player_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-2">
                            <label class="small text-light">نوع البطاقة</label>
                            <select name="card_type" class="form-select">
                                <option value="yellow">كرت أصفر 🟨</option>
                                <option value="red">كرت أحمر 🟥</option>
                            </select>
                        </div>
                        <div class="mt-4">
                            <label class="small text-light">الدقيقة</label>
                            <input type="number" name="card_minute" class="form-control" placeholder="مثال: 75">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 3. إحصائيات المباراة -->
        <div class="card shadow-sm mb-4 border-0">
            <div class="card-header bg-primary text-white fw-bold"><i class="fas fa-chart-line me-1"></i> إحصائيات اللقاء</div>
            <div class="card-body">
                
                <!-- قسم شريط سحب الاستحواذ التفاعلي -->
                <div class="p-3 mb-4 rounded dark-box">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="fw-bold" style="color: #00d285 !important;">
                            <?php echo htmlspecialchars($match['home_name']); ?>: 
                            <span id="home_possession_label" class="fs-5"><?php echo $current_stats['home_possession'] ?? 50; ?></span>%
                        </span>
                        <span class="badge bg-secondary px-3 py-2">نسبة الاستحواذ</span>
                        <span class="fw-bold text-danger">
                            <?php echo htmlspecialchars($match['away_name']); ?>: 
                            <span id="away_possession_label" class="fs-5"><?php echo $current_stats['away_possession'] ?? 50; ?></span>%
                        </span>
                    </div>

                    <!-- شريط السحب Range Slider -->
                    <input type="range" class="form-range" id="possession_range" min="0" max="100" 
                           value="<?php echo $current_stats['home_possession'] ?? 50; ?>" 
                           oninput="updatePossession(this.value)">

                    <input type="hidden" name="home_possession" id="home_possession_input" value="<?php echo $current_stats['home_possession'] ?? 50; ?>">
                    <input type="hidden" name="away_possession" id="away_possession_input" value="<?php echo $current_stats['away_possession'] ?? 50; ?>">
                </div>

                <div class="row g-3">
                    <div class="col-6 col-md-3">
                        <label class="small text-light">تسديدات <?php echo htmlspecialchars($match['home_name']); ?></label>
                        <input type="number" name="home_shots" class="form-control" value="<?php echo $current_stats['home_shots'] ?? 0; ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="small text-light">تسديدات <?php echo htmlspecialchars($match['away_name']); ?></label>
                        <input type="number" name="away_shots" class="form-control" value="<?php echo $current_stats['away_shots'] ?? 0; ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="small text-light">على المرمى <?php echo htmlspecialchars($match['home_name']); ?></label>
                        <input type="number" name="home_shots_on_target" class="form-control" value="<?php echo $current_stats['home_shots_on_target'] ?? 0; ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="small text-light">على المرمى <?php echo htmlspecialchars($match['away_name']); ?></label>
                        <input type="number" name="away_shots_on_target" class="form-control" value="<?php echo $current_stats['away_shots_on_target'] ?? 0; ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="small text-light">ركنيات <?php echo htmlspecialchars($match['home_name']); ?></label>
                        <input type="number" name="home_corners" class="form-control" value="<?php echo $current_stats['home_corners'] ?? 0; ?>">
                    </div>
                    <div class="col-6 col-md-3">
                        <label class="small text-light">ركنيات <?php echo htmlspecialchars($match['away_name']); ?></label>
                        <input type="number" name="away_corners" class="form-control" value="<?php echo $current_stats['away_corners'] ?? 0; ?>">
                    </div>
                </div>
            </div>
        </div>

        <script>
        function updatePossession(val) {
            let homeVal = parseInt(val);
            let awayVal = 100 - homeVal;

            document.getElementById('home_possession_label').innerText = homeVal;
            document.getElementById('away_possession_label').innerText = awayVal;

            document.getElementById('home_possession_input').value = homeVal;
            document.getElementById('away_possession_input').value = awayVal;
        }
        </script>

        <!-- 4. تقييمات اللاعبين ورجل المباراة (MVP) -->
        <div class="card shadow-sm mb-4 border-0">
            <div class="card-header bg-info text-white fw-bold"><i class="fas fa-star me-1"></i> تقييمات اللاعبين ورجل المباراة (MVP)</div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr class="dark-box">
                            <th class="ps-3 text-white">اللاعب</th>
                            <th class="text-center text-white" style="width: 200px;">التقييم (10 - 1)</th>
                            <th class="text-center text-white" style="width: 180px;">رجل المباراة (MVP)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        foreach($players as $p): 
                            $p_id = $p['id'];
                            $p_stat_q = mysqli_query($conn, "SELECT rating, is_mvp FROM player_match_stats WHERE match_id = $match_id AND player_id = $p_id");
                            $p_stat = mysqli_fetch_assoc($p_stat_q);
                        ?>
                        <tr>
                            <td class="fw-bold ps-3 text-white"><?php echo htmlspecialchars($p['player_name']); ?></td>
                            <td class="text-center">
                                <input type="number" step="0.1" min="1" max="10" name="ratings[<?php echo $p_id; ?>]" class="form-control text-center mx-auto" style="max-width: 100px;" value="<?php echo $p_stat['rating'] ?? 6.0; ?>">
                            </td>
                            <td class="text-center">
                                <input type="radio" name="is_mvp" value="<?php echo $p_id; ?>" class="form-check-input" style="cursor: pointer; transform: scale(1.2);" <?php if(!empty($p_stat['is_mvp'])) echo 'checked'; ?>>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <button type="submit" class="btn btn-success btn-lg w-100 fw-bold py-3 mb-5 shadow" style="background-color: #00d285; border: none; color: #121829 !important;"><i class="fas fa-save me-2"></i> حفظ وتحديث البيانات</button>
    </form>
</div>

<?php include 'footer.php'; ?>