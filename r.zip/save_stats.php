<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $match_id = $_POST['match_id'];
    $score_home = $_POST['score_home'];
    $score_away = $_POST['score_away'];

    // 1. تحديث نتيجة المباراة وحالتها
    mysqli_query($conn, "UPDATE matches SET score_home=$score_home, score_away=$score_away, status='finished' WHERE id=$match_id");

    // 2. حفظ الأهداف والأسيست
    if (!empty($_POST['goal_player'])) {
        foreach ($_POST['goal_player'] as $key => $player_id) {
            if ($player_id != "") {
                $assist_id = $_POST['assist_player'][$key] != "" ? $_POST['assist_player'][$key] : "NULL";
                $min = $_POST['goal_min'][$key];
                mysqli_query($conn, "INSERT INTO goals (match_id, player_id, assist_player_id, goal_minute) VALUES ($match_id, $player_id, $assist_id, $min)");
            }
        }
    }

    // 3. حفظ تقييمات اللاعبين والبطاقات والـ MVP
    foreach ($_POST['rating'] as $p_id => $rate) {
        $yellow = $_POST['yellow'][$p_id];
        $red = $_POST['red'][$p_id];
        $is_mvp = ($_POST['mvp'] == $p_id) ? 1 : 0;
        
        if ($rate != "" || $yellow > 0 || $red > 0) {
            mysqli_query($conn, "INSERT INTO player_match_stats (match_id, player_id, rating, yellow_cards, red_cards, is_mvp) 
                                 VALUES ($match_id, $p_id, $rate, $yellow, $red, $is_mvp)");
        }
    }

    header("Location: index.php?msg=match_finished");
}
?>