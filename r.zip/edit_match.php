<?php
include 'db.php';
include 'header.php';

// 1. جلب بيانات المباراة
if (isset($_GET['id'])) {
    $m_id = (int)$_GET['id'];
    $res = mysqli_query($conn, "SELECT m.*, t1.team_name as h_team, t2.team_name as a_team 
                                FROM matches m 
                                LEFT JOIN teams t1 ON m.team_home_id = t1.id 
                                LEFT JOIN teams t2 ON m.team_away_id = t2.id 
                                WHERE m.id = $m_id");
    $match = mysqli_fetch_assoc($res);
}

if (!$match) { die("<div class='container mt-5 alert alert-danger text-center'>المباراة غير موجودة</div>"); }

// 2. تحديث البيانات عند الضغط على حفظ
if (isset($_POST['update_match'])) {
    $score_h = (int)$_POST['score_home'];
    $score_a = (int)$_POST['score_away'];
    $is_fin = isset($_POST['is_finished']) ? 1 : 0; // تحويل حالة الـ Checkbox لـ 1 أو 0

    $update = mysqli_query($conn, "UPDATE matches SET 
                                   score_home = $score_h, 
                                   score_away = $score_a, 
                                   is_finished = $is_fin 
                                   WHERE id = $m_id");

    if ($update) {
        echo "<div class='container mt-3 alert alert-success text-center'>تم تحديث النتيجة بنجاح! جاري العودة...</div>";
        echo "<script>setTimeout(() => { window.location.href='tournament_dashboard.php?id=".$match['tournament_id']."'; }, 2000);</script>";
    }
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
                <div class="card-header bg-dark text-white text-center py-4">
                    <h4 class="mb-0 fw-bold">تحديث نتيجة المباراة</h4>
                    <small class="text-warning"><?php echo $match['group_name']; ?> - بطولة رقم <?php echo $match['tournament_id']; ?></small>
                </div>
                <div class="card-body p-5 bg-light">
                    <form method="POST">
                        <div class="row align-items-center text-center">
                            <div class="col-md-5">
                                <h5 class="fw-bold mb-3"><?php echo $match['h_team']; ?></h5>
                                <input type="number" name="score_home" class="form-control form-control-lg text-center fw-bold border-primary shadow-sm" 
                                       value="<?php echo $match['score_home']; ?>" min="0">
                            </div>

                            <div class="col-md-2 my-3">
                                <span class="badge bg-secondary rounded-pill px-3 py-2">VS</span>
                            </div>

                            <div class="col-md-5">
                                <h5 class="fw-bold mb-3"><?php echo $match['a_team']; ?></h5>
                                <input type="number" name="score_away" class="form-control form-control-lg text-center fw-bold border-primary shadow-sm" 
                                       value="<?php echo $match['score_away']; ?>" min="0">
                            </div>
                        </div>

                        <hr class="my-5">

                        <div class="d-flex justify-content-center mb-4">
                            <div class="form-check form-switch p-3 bg-white rounded-4 shadow-sm border border-2 border-warning">
                                <input class="form-check-input ms-2" type="checkbox" name="is_finished" id="isFin" 
                                       <?php echo ($match['is_finished'] == 1) ? 'checked' : ''; ?> style="width: 50px; height: 25px; cursor:pointer;">
                                <label class="form-check-label fw-bold h5 mb-0" for="isFin" style="cursor:pointer;">تم انتهاء المباراة وحفظ النتيجة</label>
                            </div>
                        </div>

                        <div class="text-center mt-4 d-grid gap-2">
                            <button type="submit" name="update_match" class="btn btn-primary btn-lg rounded-pill fw-bold shadow">
                                <i class="fas fa-save ms-2"></i> حفظ التغييرات وتحديث الجدول
                            </button>
                            <a href="tournament_dashboard.php?id=<?php echo $match['tournament_id']; ?>" class="btn btn-link text-muted mt-2">إلغاء والعودة</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    body { background: #f4f7f6; }
    .form-control:focus { border-color: #1a237e; box-shadow: 0 0 10px rgba(26,35,126,0.2); }
</style>

<?php include 'footer.php'; ?>