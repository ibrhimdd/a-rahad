<?php include 'db.php'; include 'header.php'; ?>
<?php include 'check_admin.php'; ?>
<div class="row justify-content-center">
    <div class="col-md-10"> <div class="card p-4 shadow-sm border-0">
            <h3 class="text-center mb-4"><i class="fas fa-trophy text-warning"></i> إنشاء بطولة جديدة شاملة</h3>
            <form action="save_tournament.php" method="POST" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="fw-bold">اسم البطولة</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="fw-bold">تاريخ البداية</label>
                        <input type="date" name="start_date" class="form-control" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="fw-bold">شعار البطولة</label>
                    <input type="file" name="image" class="form-control">
                </div>

                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="fw-bold text-primary">الفرق المشاركة:</label>
                        <div class="border p-2 rounded bg-light" style="max-height: 150px; overflow-y: auto;">
                            <?php
                            $teams = mysqli_query($conn, "SELECT * FROM teams");
                            while($t = mysqli_fetch_assoc($teams)) {
                                echo "<div class='form-check'><input class='form-check-input' type='checkbox' name='teams[]' value='".$t['id']."'> ".$t['team_name']."</div>";
                            }
                            ?>
                        </div>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="fw-bold text-danger">حكام البطولة:</label>
                        <div class="border p-2 rounded bg-light" style="max-height: 150px; overflow-y: auto;">
                            <?php
                            $officials = mysqli_query($conn, "SELECT * FROM officials WHERE role='referee'");
                            while($o = mysqli_fetch_assoc($officials)) {
                                echo "<div class='form-check'><input class='form-check-input' type='checkbox' name='officials[]' value='".$o['id']."'> ".$o['name']."</div>";
                            }
                            ?>
                        </div>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="fw-bold text-info">معلقي البطولة:</label>
                        <div class="border p-2 rounded bg-light" style="max-height: 150px; overflow-y: auto;">
                            <?php
                            $commentators = mysqli_query($conn, "SELECT * FROM officials WHERE role='commentator'");
                            while($c = mysqli_fetch_assoc($commentators)) {
                                echo "<div class='form-check'><input class='form-check-input' type='checkbox' name='commentators[]' value='".$c['id']."'> ".$c['name']."</div>";
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-warning w-100 fw-bold mt-3 py-2">حفظ البطولة وتسكين الطاقم</button>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>