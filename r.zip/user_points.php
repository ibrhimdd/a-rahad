<?php
session_start();
include 'db.php';
include 'header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = intval($_SESSION['user_id']);

// جلب نقاط المستخدم في كل بطولة
$points_q = mysqli_query($conn, "
    SELECT utp.total_points, t.name as tournament_name 
    FROM user_tournament_points utp
    JOIN tournaments t ON utp.tournament_id = t.id
    WHERE utp.user_id = $user_id
    ORDER BY utp.total_points DESC
");
?>

<div class="container py-4" style="max-width: 600px;">
    <h3 class="fw-bold text-white mb-4 text-center"><i class="fas fa-trophy text-warning me-2"></i> نقاطي حسب البطولات</h3>
    
    <div class="card bg-dark text-white border-0 shadow">
        <div class="card-body p-0">
            <ul class="list-group list-group-flush bg-transparent">
                <?php if (mysqli_num_rows($points_q) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($points_q)): ?>
                        <li class="list-group-item bg-transparent text-white d-flex justify-content-between align-items-center border-secondary py-3">
                            <span class="fw-bold"><?php echo htmlspecialchars($row['tournament_name']); ?></span>
                            <span class="badge rounded-pill px-3 py-2 fs-6" style="background-color: #00d285; color: #121829;">
                                <?php echo $row['total_points']; ?> نقطة
                            </span>
                        </li>
                    <?php endwhile; ?>
                <?php else: ?>
                    <li class="list-group-item bg-transparent text-white text-center py-4">لم تقم بتجميع أي نقاط بعد. ابدأ بالتوقع الآن!</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>