<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $start_date = $_POST['start_date'];
    
    // رفع الصورة
    $img_name = "";
    if(!empty($_FILES['image']['name'])){
        $img_name = time() . "_" . $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "uploads/logos/".$img_name);
    }

    // 1. حفظ البطولة
    $sql = "INSERT INTO tournaments (name, start_date, image) VALUES ('$name', '$start_date', '$img_name')";
    mysqli_query($conn, $sql);
    $tournament_id = mysqli_insert_id($conn);

    // 2. حفظ الفرق
    if(!empty($_POST['teams'])) {
        foreach($_POST['teams'] as $team_id) {
            mysqli_query($conn, "INSERT INTO tournament_teams (tournament_id, team_id) VALUES ('$tournament_id', '$team_id')");
        }
    }

    // 3. حفظ الحكام
    if(!empty($_POST['officials'])) {
        foreach($_POST['officials'] as $off_id) {
            mysqli_query($conn, "INSERT INTO tournament_officials (tournament_id, official_id) VALUES ('$tournament_id', '$off_id')");
        }
    }

    // 4. حفظ المعلقين (الجديد)
    if(!empty($_POST['commentators'])) {
        foreach($_POST['commentators'] as $comm_id) {
            mysqli_query($conn, "INSERT INTO tournament_commentators (tournament_id, official_id) VALUES ('$tournament_id', '$comm_id')");
        }
    }

    header("Location: admin.php?msg=tournament_ready");
}
?>