<?php 
include 'db.php'; 
include 'header.php'; 
?>

<style>
    :root {
        --bg-main: #f8fafc;
        --card-bg: #ffffff;
        --team-green: #00d285; /* اللون المخصص لاسم الفريق 🌟 */
        --text-stadium: #334155; /* رمادي غامق ممتاز للتباين على الخلفية البيضاء 🌟 */
        --accent-blue: #2563eb;
        --accent-hover: #1d4ed8;
        --border-color: #e2e8f0;
    }

    body { 
        background-color: var(--bg-main); 
        font-family: 'Cairo', sans-serif;
    }

    /* 🌟 تصميم الكارت العصري */
    .ux-team-card {
        background: var(--card-bg);
        border: 1px solid var(--border-color);
        border-radius: 20px;
        position: relative;
        overflow: hidden;
        transition: all 0.35s cubic-bezier(0.34, 1.56, 0.64, 1);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.03), 0 2px 4px -2px rgba(0, 0, 0, 0.03);
    }

    /* شريط علوي أنيق يظهر عند مرور الماوس */
    .ux-team-card::before {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        height: 4px;
        background: linear-gradient(90deg, #00d285, #3b82f6);
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .ux-team-card:hover {
        transform: translateY(-8px);
        border-color: #cbd5e1;
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.07), 0 8px 10px -6px rgba(0, 0, 0, 0.04) !important;
    }

    .ux-team-card:hover::before {
        opacity: 1;
    }

    /* 🌟 حاوية اللوجو */
    .logo-container {
        position: relative;
        width: 96px;
        height: 96px;
        margin: 0 auto;
        border-radius: 50%;
        background: #ffffff;
        padding: 6px;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.06);
        transition: transform 0.35s ease;
    }

    .ux-team-card:hover .logo-container {
        transform: scale(1.08);
    }

    .logo-img-wrapper {
        width: 100%;
        height: 100%;
        border-radius: 50%;
        background-color: #f8fafc;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 10px;
        border: 1px solid var(--border-color);
    }

    .team-logo {
        max-width: 100%;
        max-height: 100%;
        object-fit: contain;
        filter: drop-shadow(0 2px 4px rgba(0,0,0,0.08));
    }

    /* 🌟 اسم الفريق باللون الأخضر المخصص #00d285 */
    .team-name {
        color: var(--team-green) !important;
        font-weight: 800;
        font-size: 1.2rem;
        letter-spacing: -0.2px;
    }

    /* 🌟 اسم الملعب بالرمادي الغامق الشديد التباين */
    .stadium-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        background-color: #f1f5f9;
        color: var(--text-stadium) !important; /* لون رمادي غامق واضع جداً */
        font-weight: 700;
        font-size: 0.85rem;
        padding: 6px 14px;
        border-radius: 30px;
        border: 1px solid #cbd5e1;
    }

    /* 🌟 الزر التفاعلي */
    .btn-stats {
        background-color: var(--accent-blue);
        color: #ffffff !important;
        border: none;
        font-weight: 700;
        font-size: 0.9rem;
        padding: 10px 16px;
        border-radius: 12px;
        transition: all 0.25s ease;
    }

    .btn-stats:hover {
        background-color: var(--accent-hover);
        box-shadow: 0 6px 16px rgba(37, 99, 235, 0.3);
    }

    /* أنيميشن دخول الكروت */
    .team-item {
        animation: fadeInUp 0.5s ease backwards;
    }

    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    <?php for($i=1; $i<=20; $i++) { 
        echo ".team-item:nth-child($i) { animation-delay: " . ($i * 0.04) . "s; }";
    } ?>
</style>

<div class="container py-5" style="direction: rtl; text-align: right;">
    
    <!-- Header الصفحة -->
    <div class="text-center mb-5">
        <span class="badge bg-primary-subtle text-primary fw-bold px-3 py-2 rounded-pill mb-2">
            <i class="fas fa-shield-alt me-1"></i> الفرق المشاركة
        </span>
        <h2 class="fw-black display-6 text-whiet mb-2" style="font-weight: 800;">الأندية والمنتخبات</h2>
        <p class="text-secondary fw-semibold">استكشف كافة الفرق والمنتخبات المسجلة في البطولة إحصائياً</p>
    </div>

    <div class="row g-4">
        <?php
        $result = mysqli_query($conn, "SELECT * FROM teams");
        if($result && mysqli_num_rows($result) > 0) {
            while($team = mysqli_fetch_assoc($result)) {
        ?>
        <div class="col-6 col-md-4 col-lg-3 team-item">
            <div class="card ux-team-card h-100 border-0 p-3">
                <div class="card-body p-2 d-flex flex-column justify-content-between text-center">
                    
                    <div>
                        <!-- شعار الفريق -->
                        <div class="logo-container mb-3">
                            <div class="logo-img-wrapper">
                                <img src="uploads/logos/<?php echo htmlspecialchars($team['logo']); ?>" 
                                     class="img-fluid team-logo" 
                                     alt="<?php echo htmlspecialchars($team['team_name']); ?>">
                            </div>
                        </div>
                        
                        <!-- اسم الفريق (لون #00d285) 🌟 -->
                        <h5 class="team-name mb-2 text-truncate" title="<?php echo htmlspecialchars($team['team_name']); ?>">
                            <?php echo htmlspecialchars($team['team_name']); ?>
                        </h5>
                        
                        <!-- الملعب المخصص (رمادي غامق) 🌟 -->
                        <div class="mb-4">
                            <span class="stadium-badge text-truncate" style="max-width: 100%;">
                                <i class="fas fa-map-pin text-danger"></i> 
                                <?php echo !empty($team['stadium_name']) ? htmlspecialchars($team['stadium_name']) : 'ملعب افتراضي'; ?>
                            </span>
                        </div>
                    </div>
                    
                    <!-- زر الإحصائيات -->
                    <div class="d-grid mt-auto">
                        <a href="team_profile.php?id=<?php echo $team['id']; ?>" class="btn btn-stats w-100">
                            <i class="fas fa-chart-pie ms-1"></i> الإحصائيات
                        </a>
                    </div>

                </div>
            </div>
        </div>
        <?php 
            }
        } else {
            echo '
            <div class="col-12 text-center py-5">
                <div class="bg-white border rounded-4 p-5 shadow-sm">
                    <i class="fas fa-folder-open fa-3x text-muted mb-3 opacity-50"></i>
                    <h5 class="fw-bold text-dark">لا توجد فرق حالياً</h5>
                    <p class="text-secondary mb-0 small">لم يتم إضافة أي أندية أو منتخبات في قاعدة البيانات بعد.</p>
                </div>
            </div>';
        }
        ?>
    </div>
</div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<?php include 'footer.php'; ?>