<?php include 'db.php'; include 'header.php'; ?>
<?php include 'check_admin.php'; ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-lg border-0 p-4">
            <h3 class="text-center mb-4 text-secondary">
                <i class="fas fa-microphone-alt"></i> إضافة طاقم جديد
            </h3>
            <form action="save_official.php" method="POST">
                <div class="mb-3">
                    <label class="form-label fw-bold">الاسم بالكامل</label>
                    <input type="text" name="name" class="form-control" placeholder="مثلاً: عصام الشوالي" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-bold">نوع الوظيفة</label>
                    <select name="role" class="form-select" required>
                        <option value="commentator">معلق رياضي</option>
                        <option value="referee">حكم ساحة</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">الجنسية</label>
                    <input type="text" name="nationality" class="form-control" placeholder="مثلاً: تونسي">
                </div>

                <button type="submit" class="btn btn-dark w-100 py-2 fw-bold">حفظ في النظام</button>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>