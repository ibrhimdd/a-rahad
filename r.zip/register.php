<?php
include 'db.php';
session_start();

// لو المستخدم مسجل دخول بالفعل، يرجعه للرئيسية
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$error = "";
$success = "";

if (isset($_POST['register'])) {
    $user = mysqli_real_escape_string($conn, $_POST['username']);
    $pass = $_POST['password'];
    $confirm_pass = $_POST['confirm_password'];

    // فحص هل كلمة السر متطابقة؟
    if ($pass !== $confirm_pass) {
        $error = "كلمتا السر غير متطابقتين!";
    } else {
        // فحص هل اسم المستخدم موجود مسبقاً؟
        $check_user = mysqli_query($conn, "SELECT id FROM users WHERE username='$user'");
        if (mysqli_num_rows($check_user) > 0) {
            $error = "اسم المستخدم هذا محجوز مسبقاً، اختر اسماً آخر.";
        } else {
            // تشفير كلمة السر للأمان
            $hashed_pass = password_hash($pass, PASSWORD_DEFAULT);
            
            // إدخال المستخدم الجديد (الرتبة الافتراضية user)
            $sql = "INSERT INTO users (username, password, role) VALUES ('$user', '$hashed_pass', 'user')";
            if (mysqli_query($conn, $sql)) {
                $success = "تم إنشاء الحساب بنجاح! يمكنك الآن تسجيل الدخول.";
            } else {
                $error = "حدث خطأ أثناء التسجيل، حاول مرة أخرى.";
            }
        }
    }
}
?>

<?php include 'header.php'; ?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card border-0 shadow-lg rounded-4 p-4 overflow-hidden">
                <div class="text-center mb-4">
                    <div class="icon-box bg-primary text-white mx-auto shadow-sm mb-3">
                        <i class="fas fa-user-plus fa-lg"></i>
                    </div>
                    <h3 class="fw-bold">إنشاء حساب جديد</h3>
                    <p class="text-muted small">انضم لجمهور ملعب أحمد رشاد وتابع بطولاتك المفضلة</p>
                </div>

                <?php if($error): ?>
                    <div class="alert alert-danger py-2 small border-0 shadow-sm"><i class="fas fa-exclamation-circle me-2"></i><?php echo $error; ?></div>
                <?php endif; ?>

                <?php if($success): ?>
                    <div class="alert alert-success py-2 small border-0 shadow-sm"><i class="fas fa-check-circle me-2"></i><?php echo $success; ?></div>
                <?php endif; ?>

                <form method="POST" class="mt-3">
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark">اسم المستخدم</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-0"><i class="fas fa-user text-muted"></i></span>
                            <input type="text" name="username" class="form-control bg-light border-0 shadow-none rounded-end" placeholder="مثلاً: ahmed_2026" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark">كلمة المرور</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-0"><i class="fas fa-lock text-muted"></i></span>
                            <input type="password" name="password" class="form-control bg-light border-0 shadow-none rounded-end" placeholder="********" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label small fw-bold text-dark">تأكيد كلمة المرور</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light border-0"><i class="fas fa-shield-alt text-muted"></i></span>
                            <input type="password" name="confirm_password" class="form-control bg-light border-0 shadow-none rounded-end" placeholder="********" required>
                        </div>
                    </div>

                    <button type="submit" name="register" class="btn btn-primary w-100 rounded-pill py-2 fw-bold shadow-sm mb-3">
                        إنشاء الحساب الآن
                    </button>

                    <div class="text-center">
                        <span class="text-muted small">لديك حساب بالفعل؟</span>
                        <a href="login.php" class="text-primary small fw-bold text-decoration-none">تسجيل الدخول</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    body { background-color: #f1f3f6; }
    .icon-box {
        width: 60px;
        height: 60px;
        line-height: 60px;
        border-radius: 50%;
        font-size: 20px;
    }
    .form-control:focus {
        background-color: #e9ecef !important;
    }
    .card {
        background-color: #ffffff;
    }
</style>

<?php include 'footer.php'; ?>