<?php
include 'db.php';

// =========================================================================
// 1. التعامل مع طلبات AJAX (جلب إحصائيات التوقعات ونسب الجمهور)
// =========================================================================
if (isset($_GET['match_id']) && (!isset($_SERVER['HTTP_ACCEPT']) || strpos($_SERVER['HTTP_ACCEPT'], 'text/html') === false)) {
    header('Content-Type: application/json');
    $match_id = intval($_GET['match_id']);

    // جلب إجمالي الأعداد لكل نوع توقع
    $sql = "SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN predicted_result = 'home_win' THEN 1 ELSE 0 END) as home_votes,
                SUM(CASE WHEN predicted_result = 'draw' THEN 1 ELSE 0 END) as draw_votes,
                SUM(CASE WHEN predicted_result = 'away_win' THEN 1 ELSE 0 END) as away_votes
            FROM predictions 
            WHERE match_id = $match_id";

    $res = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($res);

    $total = (int)$data['total'];
    $home_votes = (int)$data['home_votes'];
    $draw_votes = (int)$data['draw_votes'];
    $away_votes = (int)$data['away_votes'];

    if ($total > 0) {
        $home_percent = round(($home_votes / $total) * 100);
        $draw_percent = round(($draw_votes / $total) * 100);
        $away_percent = round(($away_votes / $total) * 100);
    } else {
        $home_percent = 0;
        $draw_percent = 0;
        $away_percent = 0;
    }

    echo json_encode([
        'status' => 'success',
        'total_votes' => $total,
        'home_percent' => $home_percent,
        'draw_percent' => $draw_percent,
        'away_percent' => $away_percent
    ]);
    exit;
}

// =========================================================================
// 2. عرض واجهة صفحة التوقع للمستخدم (HTML)
// =========================================================================
include 'header.php';

if (!isset($_SESSION['user_id'])) {
    echo "<div class='container py-5 text-center'><div class='alert alert-warning'>عذراً، يجب تسجيل الدخول لتتمكن من تقديم توقعك.</div></div>";
    include 'footer.php';
    exit;
}

$user_id = intval($_SESSION['user_id']);
$match_id = isset($_GET['match_id']) ? intval($_GET['match_id']) : 0;

// جلب تفاصيل المباراة
$match_q = mysqli_query($conn, "SELECT m.*, 
                                       t1.team_name AS h_team, t1.logo AS h_logo,
                                       t2.team_name AS a_team, t2.logo AS a_logo,
                                       tour.name AS tour_name
                                FROM matches m
                                LEFT JOIN teams t1 ON m.team_home_id = t1.id
                                LEFT JOIN teams t2 ON m.team_away_id = t2.id
                                LEFT JOIN tournaments tour ON m.tournament_id = tour.id
                                WHERE m.id = $match_id");

$match = mysqli_fetch_assoc($match_q);

if (!$match) {
    echo "<div class='container py-5 text-center'><div class='alert alert-danger'>المباراة غير موجودة.</div></div>";
    include 'footer.php';
    exit;
}

// حظر التوقع إذا كانت المباراة قد انتهت
if (!empty($match['is_finished']) || $match['status'] == 'finished') {
    echo "<div class='container py-5 text-center'><div class='alert alert-danger'>عذراً، هذه المباراة انتهت ولا يمكن التوقع عليها الآن.</div></div>";
    include 'footer.php';
    exit;
}

// معالجة حفظ أو تحديث التوقع (POST)
$msg = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['predicted_result'])) {
    $predicted_result = mysqli_real_escape_string($conn, $_POST['predicted_result']);

    // فحص ما إذا كان المستخدم توقع لهذه المباراة من قبل
    $check_q = mysqli_query($conn, "SELECT id FROM predictions WHERE user_id = $user_id AND match_id = $match_id");
    
    if (mysqli_num_rows($check_q) > 0) {
        // تحديث التوقع الحالي
        mysqli_query($conn, "UPDATE predictions SET predicted_result = '$predicted_result' WHERE user_id = $user_id AND match_id = $match_id");
        $msg = "<div class='alert alert-success text-center'>تم تحديث توقعك بنجاح! 🎯</div>";
    } else {
        // إضافة توقع جديد
        mysqli_query($conn, "INSERT INTO predictions (user_id, match_id, predicted_result) VALUES ($user_id, $match_id, '$predicted_result')");
        $msg = "<div class='alert alert-success text-center'>تم تسجيل توقعك بنجاح! بالتوفيق 🚀</div>";
    }
}

// جلب التوقع السابق للمستخدم إن وجد
$user_pred_q = mysqli_query($conn, "SELECT predicted_result FROM predictions WHERE user_id = $user_id AND match_id = $match_id");
$current_pred = ($user_pred = mysqli_fetch_assoc($user_pred_q)) ? $user_pred['predicted_result'] : '';
?>

<style>
    body { background-color: #0f172a; color: #fff; font-family: 'Cairo', sans-serif; direction: rtl; }
    .card-predict { background-color: #1e293b; border: 1px solid rgba(255,255,255,0.1); border-radius: 20px; }
    .team-img-lg { width: 80px; height: 80px; object-fit: contain; }
    
    /* تنسيق أزرار التوقع التفاعلية */
    .btn-check:checked + .btn-outline-custom {
        background-color: #00d285 !important;
        color: #0f172a !important;
        border-color: #00d285 !important;
        font-weight: bold;
        box-shadow: 0 0 15px rgba(0, 210, 133, 0.4);
    }
    .btn-outline-custom {
        border: 2px solid rgba(255, 255, 255, 0.2);
        color: #fff;
        padding: 15px;
        border-radius: 12px;
        transition: all 0.3s ease;
    }
    .btn-outline-custom:hover {
        border-color: #00d285;
        color: #00d285;
    }
</style>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            
            <?php echo $msg; ?>

            <div class="card card-predict shadow-lg p-4">
                <div class="text-center border-bottom border-secondary pb-3 mb-4">
                    <span class="badge bg-primary px-3 py-2 rounded-pill"><?php echo htmlspecialchars($match['tour_name'] ?? 'بطولة'); ?></span>
                    <h5 class="text-muted mt-2 mb-0"><i class="fas fa-bullhorn text-warning me-1"></i> توقّع نتيجة المباراة</h5>
                </div>

                <!-- تفاصيل الفريقين -->
                <div class="row align-items-center text-center mb-4">
                    <div class="col-5">
                        <img src="uploads/logos/<?php echo htmlspecialchars($match['h_logo']); ?>" class="team-img-lg mb-2" onerror="this.src='uploads/logos/default.png';">
                        <h6 class="fw-bold mb-0"><?php echo htmlspecialchars($match['h_team']); ?></h6>
                    </div>
                    <div class="col-2">
                        <span class="fw-bold fs-4 text-warning">VS</span>
                    </div>
                    <div class="col-5">
                        <img src="uploads/logos/<?php echo htmlspecialchars($match['a_logo']); ?>" class="team-img-lg mb-2" onerror="this.src='uploads/logos/default.png';">
                        <h6 class="fw-bold mb-0"><?php echo htmlspecialchars($match['a_team']); ?></h6>
                    </div>
                </div>

                <!-- نموذج الاختيار -->
                <form method="POST">
                    <div class="d-grid gap-3 mb-4">
                        
                        <input type="radio" class="btn-check" name="predicted_result" id="pred_home" value="home_win" autocomplete="off" <?php if($current_pred == 'home_win') echo 'checked'; ?> required>
                        <label class="btn btn-outline-custom text-center" for="pred_home">
                            <i class="fas fa-trophy me-2"></i> فوز <?php echo htmlspecialchars($match['h_team']); ?>
                        </label>

                        <input type="radio" class="btn-check" name="predicted_result" id="pred_draw" value="draw" autocomplete="off" <?php if($current_pred == 'draw') echo 'checked'; ?>>
                        <label class="btn btn-outline-custom text-center" for="pred_draw">
                            🤝 التعادل بين الفريقين
                        </label>

                        <input type="radio" class="btn-check" name="predicted_result" id="pred_away" value="away_win" autocomplete="off" <?php if($current_pred == 'away_win') echo 'checked'; ?>>
                        <label class="btn btn-outline-custom text-center" for="pred_away">
                            <i class="fas fa-trophy me-2"></i> فوز <?php echo htmlspecialchars($match['a_team']); ?>
                        </label>

                    </div>

                    <button type="submit" class="btn btn-success btn-lg w-100 fw-bold py-3 rounded-3" style="background-color: #00d285; border: none; color: #0f172a;">
                        <i class="fas fa-paper-plane me-1"></i> تأكيد التوقع
                    </button>
                </form>

                <div class="text-center mt-3">
                    <a href="match_details.php?id=<?php echo $match_id; ?>" class="text-muted text-decoration-none small"><i class="fas fa-arrow-right me-1"></i> العودة لصفحة المباراة</a>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include 'footer.php'; ?>