<?php
include 'db.php';
$id = $_GET['id'];

// جلب الفرق
$teams_res = mysqli_query($conn, "SELECT teams.id, teams.team_name FROM teams 
             JOIN tournament_teams ON teams.id = tournament_teams.team_id 
             WHERE tournament_teams.tournament_id = $id");
$teams = [];
while($row = mysqli_fetch_assoc($teams_res)) {
    $teams[] = ['id' => $row['id'], 'name' => $row['team_name']];
}

// جلب الحكام
$refs_res = mysqli_query($conn, "SELECT officials.id, officials.name FROM officials 
            JOIN tournament_officials ON officials.id = tournament_officials.official_id 
            WHERE tournament_officials.tournament_id = $id");
$referees = [];
while($row = mysqli_fetch_assoc($refs_res)) {
    $referees[] = ['id' => $row['id'], 'name' => $row['name']];
}

echo json_encode(['teams' => $teams, 'referees' => $referees]);
?>