<?php 
include 'db.php'; 
include 'header.php'; 

// حماية الصفحة: لو مش مسجل دخول يروح لصفحة الدخول
if (!isset($_SESSION['user_id'])) {
    echo "<script>window.location='login.php';</script>";
    exit();
}

$user_id = $_SESSION['user_id'];
$success_msg = "";

// 1. جلب بيانات المستخدم
$query = mysqli_query($conn, "SELECT * FROM users WHERE id = '$user_id'");
$user_data = mysqli_fetch_assoc($query);

// 2. تحديث البيانات (الصورة أو الباسوورد)
if (isset($_POST['update_profile'])) {
    // تحديث الصورة
    if (!empty($_FILES['profile_pic']['name'])) {
        $img_name = time() . '_' . $_FILES['profile_pic']['name'];
        if(move_uploaded_file($_FILES['profile_pic']['tmp_name'], "uploads/users/" . $img_name)) {
            mysqli_query($conn, "UPDATE users SET image = '$img_name' WHERE id = '$user_id'");
        }
    }

    // تحديث كلمة السر
    if (!empty($_POST['new_password'])) {
        $hashed_pass = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        mysqli_query($conn, "UPDATE users SET password = '$hashed_pass' WHERE id = '$user_id'");
    }
    
    echo "<script>alert('تم التحديث بنجاح'); window.location='profile.php';</script>";
}

$current_img = (!empty($user_data['image'])) ? "uploads/users/".$user_data['image'] : "https://cdn-icons-png.flaticon.com/512/149/149071.png";
?>

<div class="container py-5 position-relative">
    <div class="watermark-bg">AHMED RASHAD</div>

    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card profile-card border-0 shadow-lg animate__animated animate__fadeInUp">
                <div class="upper-cover"></div>
                <div class="card-body p-5 text-center position-relative">
                    
                    <div class="profile-avatar-container shadow">
                        <img src="<?php echo $current_img; ?>" id="preview_img" alt="User">
                        <label for="upload_img" class="edit-icon"><i class="fas fa-pen"></i></label>
                    </div>

                    <h3 class="fw-bold mt-3"><?php echo $user_data['username']; ?></h3>
                    <p class="text-muted mb-4 small">عضو في ملعب أحمد رشاد</p>

                    <form method="POST" enctype="multipart/form-data" class="text-end mt-4">
                        <input type="file" name="profile_pic" id="upload_img" hidden onchange="document.getElementById('preview_img').src = window.URL.createObjectURL(this.files[0])">
                        
                        <div class="mb-4">
                            <label class="form-label small fw-bold"><i class="fas fa-lock me-1"></i> كلمة مرور جديدة</label>
                            <input type="password" name="new_password" class="form-control rounded-pill border-0 bg-light" placeholder="اتركها فارغة لعدم التغيير">
                        </div>

                        <button type="submit" name="update_profile" class="btn btn-primary w-100 rounded-pill py-2 fw-bold shadow-sm">
                            حفظ التغييرات
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    body { background-color: #f4f7f6; overflow-x: hidden; }
    
    /* التوقيع في الخلفية */
    .watermark-bg {
        position: fixed;
        top: 50%; left: 50%;
        transform: translate(-50%, -50%) rotate(-25deg);
        font-size: 10vw;
        font-weight: 900;
        color: rgba(0,0,0,0.02);
        z-index: -1;
        white-space: nowrap;
        user-select: none;
    }

    .profile-card { border-radius: 25px; z-index: 1; }
    .upper-cover { height: 100px; background: #1a237e; margin: -3rem -3rem 0 -3rem; border-radius: 25px 25px 0 0; }

    .profile-avatar-container {
        width: 120px; height: 120px;
        margin: -60px auto 0;
        border-radius: 50%;
        border: 5px solid #fff;
        position: relative;
        background: #fff;
    }

    .profile-avatar-container img { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; }

    .edit-icon {
        position: absolute; bottom: 0; right: 0;
        background: #ffca28; width: 35px; height: 35px;
        border-radius: 50%; display: flex; align-items: center; justify-content: center;
        cursor: pointer; border: 3px solid #fff;
    }
</style>

<?php include 'footer.php'; ?>