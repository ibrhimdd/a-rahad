<?php 
include 'db.php'; 
include 'header.php'; 
include 'check_admin.php'; 
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

<style>
    :root {
        --glass-bg: rgba(255, 255, 255, 0.9);
        --primary-gradient: linear-gradient(135deg, #1a237e 0%, #00d2ff 100%);
    }

    body {
        background: #f0f2f5;
        font-family: 'Cairo', sans-serif;
    }

    /* حاوية الكارت الرئيسية */
    .add-team-container {
        max-width: 600px;
        margin: 50px auto;
        padding: 20px;
    }

    .glass-card {
        background: var(--glass-bg);
        backdrop-filter: blur(10px);
        border-radius: 30px;
        border: 1px solid rgba(255, 255, 255, 0.3);
        box-shadow: 0 20px 40px rgba(0,0,0,0.1);
        padding: 40px;
        position: relative;
        overflow: hidden;
    }

    .glass-card::before {
        content: '';
        position: absolute;
        top: 0; left: 0; width: 100%; height: 5px;
        background: var(--primary-gradient);
    }

    /* تنسيق منطقة معاينة الصورة */
    .image-upload-wrapper {
        position: relative;
        width: 150px;
        height: 150px;
        margin: 0 auto 30px;
    }

    .preview-box {
        width: 100%;
        height: 100%;
        border-radius: 25px;
        border: 3px dashed #ddd;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        background: #fafafa;
        transition: 0.3s;
    }

    #logoPreview {
        width: 100%;
        height: 100%;
        object-fit: contain;
        display: none; /* مخفي حتى اختيار صورة */
    }

    .upload-icon {
        font-size: 40px;
        color: #bbb;
    }

    .btn-upload-custom {
        position: absolute;
        bottom: -10px;
        right: -10px;
        background: #1a237e;
        color: white;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        border: 3px solid white;
        box-shadow: 0 5px 10px rgba(0,0,0,0.2);
    }

    /* تنسيق المدخلات */
    .form-group label {
        font-weight: 700;
        color: #333;
        margin-bottom: 8px;
        margin-right: 10px;
    }

    .custom-input {
        border-radius: 15px !important;
        border: 1.5px solid #eee !important;
        padding: 12px 20px !important;
        background: #fdfdfd !important;
        transition: 0.3s;
    }

    .custom-input:focus {
        border-color: #00d2ff !important;
        box-shadow: 0 0 0 0.25 red rgba(0, 210, 255, 0.1) !important;
        background: white !important;
    }

    .btn-submit {
        background: var(--primary-gradient);
        border: none;
        border-radius: 15px;
        padding: 15px;
        color: white;
        font-weight: 800;
        font-size: 1.1rem;
        transition: 0.3s;
        margin-top: 20px;
        box-shadow: 0 10px 20px rgba(26, 35, 126, 0.2);
    }

    .btn-submit:hover {
        transform: translateY(-3px);
        box-shadow: 0 15px 30px rgba(26, 35, 126, 0.4);
        color: white;
    }
</style>

<div class="container animate__animated animate__fadeIn">
    <div class="add-team-container text-end">
        <div class="glass-card">
            <h2 class="text-center fw-black mb-4" style="color: #1a237e;">
                تأسيس فريق جديد
                <br><small class="text-muted fs-6 fw-normal">أدخل بيانات النادي الرسمية</small>
            </h2>

            <form action="save_team.php" method="POST" enctype="multipart/form-data">
                
                <div class="image-upload-wrapper">
                    <div class="preview-box" id="previewBox">
                        <i class="fas fa-shield-alt upload-icon" id="placeholderIcon"></i>
                        <img id="logoPreview" src="#" alt="Preview">
                    </div>
                    <label for="logoInput" class="btn-upload-custom shadow">
                        <i class="fas fa-camera"></i>
                    </label>
                    <input type="file" name="logo" id="logoInput" class="d-none" accept="image/*" onchange="previewImage(this)">
                </div>

                <div class="row">
                    <div class="col-md-12 mb-3">
                        <div class="form-group">
                            <label><i class="fas fa-flag text-primary me-1"></i> اسم الفريق</label>
                            <input type="text" name="team_name" class="form-control custom-input" placeholder="مثلاً: ريال مدريد" required>
                        </div>
                    </div>

                    <div class="col-md-12 mb-3">
                        <div class="form-group">
                            <label><i class="fas fa-user-tie text-primary me-1"></i> المدير الفني</label>
                            <input type="text" name="coach_name" class="form-control custom-input" placeholder="مثلاً: كارلو أنشيلوتي">
                        </div>
                    </div>

                    <div class="col-md-12 mb-3">
                        <div class="form-group">
                            <label><i class="fas fa-landmark text-primary me-1"></i> الملعب الرسمي</label>
                            <input type="text" name="stadium_name" class="form-control custom-input" placeholder="مثلاً: سانتياغو برنابيو">
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-submit w-100">
                    <i class="fas fa-check-circle me-2"></i> اعتماد وحفظ الفريق
                </button>
                
                <a href="teams.php" class="btn btn-link w-100 text-muted mt-2 text-decoration-none">إلغاء والعودة</a>
            </form>
        </div>
    </div>
</div>

<script>
    // وظيفة المعاينة الفورية للصورة
    function previewImage(input) {
        const preview = document.getElementById('logoPreview');
        const icon = document.getElementById('placeholderIcon');
        const box = document.getElementById('previewBox');

        if (input.files && input.files[0]) {
            const reader = new FileReader();

            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
                icon.style.display = 'none';
                box.style.borderStyle = 'solid';
                box.style.borderColor = '#1a237e';
            }

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>

<?php include 'footer.php'; ?>