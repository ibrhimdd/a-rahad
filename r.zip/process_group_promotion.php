<?php
include 'db.php';

if (isset($_POST['promote_groups'])) {
    $t_id = (int)$_POST['tournament_id'];

    // --- المرحلة 1: ترحيل المتأهلين من المجموعات ---
    $groups_q = mysqli_query($conn, "SELECT DISTINCT group_name FROM matches WHERE tournament_id = $t_id AND group_name IS NOT NULL AND group_name != ''");
    $g_idx = 1; 

    while ($g = mysqli_fetch_assoc($groups_q)) {
        $gn = $g['group_name'];
        // جلب أول 2 من كل مجموعة بناءً على النقاط وفارق الأهداف
        $s_sql = "SELECT t.id FROM teams t 
                  JOIN matches m ON (t.id = m.team_home_id OR t.id = m.team_away_id)
                  WHERE m.tournament_id = $t_id AND m.group_name = '$gn' AND m.is_finished = 1
                  GROUP BY t.id 
                  ORDER BY (SUM(CASE WHEN (m.team_home_id = t.id AND m.score_home > m.score_away) OR (m.team_away_id = t.id AND m.score_away > m.score_home) THEN 3 WHEN m.score_home = m.score_away THEN 1 ELSE 0 END)) DESC,
                  (SUM(CASE WHEN m.team_home_id = t.id THEN m.score_home ELSE m.score_away END) - SUM(CASE WHEN m.team_home_id = t.id THEN m.score_away ELSE m.score_home END)) DESC LIMIT 2";
        
        $res = mysqli_query($conn, $s_sql);
        $rank = 1;
        while($row = mysqli_fetch_assoc($res)) {
            $team_id = $row['id'];
            $source_code = "G{$g_idx}_{$rank}"; // مثال: G1_1
            
            // تحديث المباريات التي تنتظر هذا المتأهل
            mysqli_query($conn, "UPDATE matches SET team_home_id = $team_id WHERE tournament_id = $t_id AND home_source = '$source_code'");
            mysqli_query($conn, "UPDATE matches SET team_away_id = $team_id WHERE tournament_id = $t_id AND away_source = '$source_code'");
            $rank++;
        }
        $g_idx++;
    }

    // --- المرحلة 2: ترحيل الفائزين من الأدوار الإقصائية للأدوار التالية ---
    // جلب كل المباريات الإقصائية المنتهية
    $finished_knockout = mysqli_query($conn, "SELECT * FROM matches WHERE tournament_id = $t_id AND round_level > 0 AND is_finished = 1");

    while ($m = mysqli_fetch_assoc($finished_knockout)) {
        $winner_id = null;
        if ($m['score_home'] > $m['score_away']) {
            $winner_id = $m['team_home_id'];
        } elseif ($m['score_away'] > $m['score_home']) {
            $winner_id = $m['team_away_id'];
        }
        // ملاحظة: لو تعادل، المفروض يكون فيه ضربات جزاء أو آلية لتحديد الفائز

        if ($winner_id) {
            // تحديد الكود الذي ينتظره الدور التالي
            // مثال: الفائز من مباراة رقم 5 في الدور 1، الكود بتاعه هيكون R1_M5
            // نحن نحتاج لمعرفة ترتيب المباراة داخل الدور (ممكن نستخدم معرف المباراة ID أو ترتيبها)
            // سأفترض أن المصدر مخزن في قاعدة البيانات كـ R[level]_M[id_or_num]
            
            // لتبسيط الأمر، سنعتمد على نظام الـ ID في الـ Source:
            $match_source_code = "R" . $m['round_level'] . "_M" . $m['id']; 
            
            // لكن بما أن "المصمم الذكي" يعتمد على ترتيب المباراة (1, 2, 3) داخل الدور:
            // سنحتاج لمعرفة ترتيب هذه المباراة في دورها
            $current_level = $m['round_level'];
            $order_res = mysqli_query($conn, "SELECT id FROM matches WHERE tournament_id = $t_id AND round_level = $current_level ORDER BY id ASC");
            $order = 1;
            while($ord = mysqli_fetch_assoc($order_res)) {
                if($ord['id'] == $m['id']) break;
                $order++;
            }
            
            $source_code = "R{$current_level}_M{$order}";

            // تحديث الدور التالي
            mysqli_query($conn, "UPDATE matches SET team_home_id = $winner_id WHERE tournament_id = $t_id AND home_source = '$source_code'");
            mysqli_query($conn, "UPDATE matches SET team_away_id = $winner_id WHERE tournament_id = $t_id AND away_source = '$source_code'");
        }
    }

    header("Location: tournament_dashboard.php?id=$t_id&status=updated");
}