<?php 
include 'db.php'; 
include 'header.php'; 



if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<div class='alert alert-danger text-center mt-5'>لم يتم تحديد فريق.</div>";
    include 'footer.php'; exit;
}

$team_id = mysqli_real_escape_string($conn, $_GET['id']);
$msg = "";


// 1. جلب بيانات الفريق
$team_q = mysqli_query($conn, "SELECT * FROM teams WHERE id = $team_id");
$team = mysqli_fetch_assoc($team_q);

// --- التحقق من صلاحية الأدمن العام أو أدمن الفريق عبر الرقم السري ---
$is_super_admin = (isset($_SESSION['role']) && $_SESSION['role'] == 'admin');
$has_team_access = isset($_SESSION['team_auth_' . $team_id]) && $_SESSION['team_auth_' . $team_id] === true;
$can_edit = $is_super_admin || $has_team_access;

// --- معالجة إدخال الرقم السري ---
if (isset($_POST['verify_passcode'])) {
    $entered_code = mysqli_real_escape_string($conn, $_POST['passcode']);
    if ($entered_code === $team['passcode']) {
        $_SESSION['team_auth_' . $team_id] = true;
        $can_edit = true;
    } else {
        $msg = "<div class='alert alert-danger text-center mb-3'>الرقم السري غير صحيح!</div>";
    }
}

// --- معالجة التعديل (للأدمن أو لمسؤول الفريق المعتمد) ---
if ($can_edit && isset($_POST['update_team'])) {
    $new_name = mysqli_real_escape_string($conn, $_POST['team_name']);
    $new_coach = mysqli_real_escape_string($conn, $_POST['coach_name']);
    $new_pass = mysqli_real_escape_string($conn, $_POST['passcode']);
    
    if (!empty($_FILES['team_logo']['name'])) {
        $logo_name = time() . '_' . $_FILES['team_logo']['name'];
        if(move_uploaded_file($_FILES['team_logo']['tmp_name'], "uploads/logos/" . $logo_name)) {
            mysqli_query($conn, "UPDATE teams SET logo = '$logo_name' WHERE id = $team_id");
        }
    }
    mysqli_query($conn, "UPDATE teams SET team_name = '$new_name', coach_name = '$new_coach', passcode = '$new_pass' WHERE id = $team_id");
    echo "<script>window.location='team_profile.php?id=$team_id';</script>";
}

// 2. إحصائيات عامة
$totals = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT 
        COUNT(*) as total_m,
        SUM(CASE WHEN (team_home_id = $team_id AND score_home > score_away) OR (team_away_id = $team_id AND score_away > score_home) THEN 1 ELSE 0 END) as wins,
        SUM(CASE WHEN score_home = score_away AND status = 'finished' THEN 1 ELSE 0 END) as draws,
        SUM(CASE WHEN (team_home_id = $team_id AND score_home < score_away) OR (team_away_id = $team_id AND score_away < score_home) THEN 1 ELSE 0 END) as losses
    FROM matches WHERE (team_home_id = $team_id OR team_away_id = $team_id) AND status = 'finished'
"));

$tours_sql = "SELECT DISTINCT tr.* FROM tournaments tr JOIN matches m ON tr.id = m.tournament_id WHERE m.team_home_id = $team_id OR m.team_away_id = $team_id";
$tours_res = mysqli_query($conn, $tours_sql);
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

<style>
    :root { 
        --primary-color: #1a237e; 
        --accent-color: #d32f2f; 
        --bg-light: #f4f4f4; 
    }
    body { background-color: var(--bg-light); font-family: 'Cairo', sans-serif; direction: rtl; }

    /* الهيدر */
    .hero-card {
        background: linear-gradient(135deg, #0f2027 0%, #203a43 50%, #2c5364 100%);
        border-radius: 0 0 40px 40px; padding: 60px 20px 100px 20px;
        color: white; position: relative; box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    }
    .logo-container {
        background: white; width: 110px; height: 110px; border-radius: 20px; padding: 10px;
        display: inline-flex; align-items: center; justify-content: center;
        box-shadow: 0 8px 20px rgba(0,0,0,0.2); margin-bottom: 15px;
    }
    .edit-trigger { position: absolute; top: 20px; right: 20px; z-index: 100; }
    .btn-edit-glass { background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: white; width: 40px; height: 40px; border-radius: 50%; cursor: pointer; }

    /* التبويبات */
    .tabs-wrapper { margin-top: -45px; position: relative; z-index: 10; text-align: center; margin-bottom: 30px; }
    .nav-pills-custom { background: white; display: inline-flex; padding: 5px; border-radius: 50px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
    .nav-pills-custom .nav-link { border-radius: 50px; padding: 10px 20px; font-weight: 700; color: #444 !important; border: none; background: none; }
    .nav-pills-custom .nav-link.active { background: var(--primary-color) !important; color: white !important; }

    /* تنسيقات كروت الترتيب */
    .standing-table-container { background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
    .table-yk-style thead { background: #f8f9fa; }
    .table-yk-style th { font-size: 0.8rem; color: #444; border: none; padding: 15px 10px; }
    .table-yk-style td { vertical-align: middle; border-top: 1px solid #eee; padding: 12px 10px; font-weight: 600; }
    .team-highlight { background-color: #f1f3f9 !important; border-right: 4px solid var(--accent-color); }

    /* تنسيق المباريات */
    .match-row { background: dark; border-radius: 12px; margin-bottom: 10px; padding: 15px; border-right: 5px solid #ddd; transition: 0.3s; }
    
    #editTeamModal { background: rgba(0,0,0,0.8) !important; z-index: 999999 !important; }
    .modal-backdrop { display: none !important; }
</style>

<div class="hero-card animate__animated animate__fadeInDown text-center">
    <!-- أيقونة التعديل متاحة للجميع للضغط عليها -->
    <div class="edit-trigger">
        <button class="btn-edit-glass shadow" data-bs-toggle="modal" data-bs-target="#editTeamModal">
            <i class="fas <?php echo $can_edit ? 'fa-cog' : 'fa-lock'; ?>"></i>
        </button>
    </div>

    <div class="container">
        <div class="logo-container animate__animated animate__zoomIn">
            <img src="uploads/logos/<?php echo $team['logo']; ?>" style="max-width: 100%; max-height: 100%;">
        </div>
        <h1 class="fw-bold mb-0 text-white"><?php echo $team['team_name']; ?></h1>
        <p class="text-info mt-2">مدرب الفريق: <span class="text-white fw-bold"><?php echo $team['coach_name'] ?: 'غير محدد'; ?></span></p>
        
        <div class="d-flex justify-content-center gap-4 mt-4">
            <div class="text-center"><h4 class="mb-0"><?php echo $totals['total_m']; ?></h4><small>مباراة</small></div>
            <div class="text-center text-success"><h4 class="mb-0"><?php echo $totals['wins']; ?></h4><small>فوز</small></div>
            <div class="text-center text-warning"><h4 class="mb-0"><?php echo $totals['draws']; ?></h4><small>تعادل</small></div>
            <div class="text-center text-danger"><h4 class="mb-0"><?php echo $totals['losses']; ?></h4><small>خسارة</small></div>
        </div>
    </div>
</div>

<div class="container pb-5">
    <div class="tabs-wrapper">
        <ul class="nav nav-pills nav-pills-custom shadow-sm" id="mainTabs">
            <li class="nav-item"><button class="nav-link active" data-bs-toggle="pill" data-bs-target="#tab-players">التشكيلة</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-matches">المباريات</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-standings">الترتيب</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-scorers">الإحصائيات</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-tours">البطولات</button></li>
        </ul>
    </div>

    <div class="tab-content">
        <div class="tab-pane fade show active" id="tab-players">
            <div class="row g-3">
                <?php 
                $players = mysqli_query($conn, "SELECT * FROM players WHERE team_id = $team_id ORDER BY FIELD(position, 'GK', 'DF', 'MF', 'FW')");
                while($p = mysqli_fetch_assoc($players)): ?>
                <div class="col-6 col-md-3 text-center">
                    <div class="bg-white p-3 rounded-4 shadow-sm" onclick="location.href='player_profile.php?id=<?php echo $p['id']; ?>'" style="cursor:pointer">
                        <img src="uploads/players/<?php echo $p['image'] ?: 'default.png'; ?>" class="rounded-circle mb-2 border border-2" width="70" height="70" style="object-fit:cover">
                        <h6 class="fw-bold mb-0 text-dark"><?php echo $p['player_name']; ?></h6>
                        <small class="text-muted"><?php echo $p['position']; ?></small>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>

        <div class="tab-pane fade" id="tab-matches">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <?php 
            $matches = mysqli_query($conn, "SELECT m.*, t1.team_name as h_name, t1.logo as h_logo, t2.team_name as a_name, t2.logo as a_logo FROM matches m JOIN teams t1 ON m.team_home_id = t1.id JOIN teams t2 ON m.team_away_id = t2.id WHERE team_home_id = $team_id OR team_away_id = $team_id ORDER BY match_date DESC");
            while($m = mysqli_fetch_assoc($matches)): 
                $res_color = ($m['score_home'] == $m['score_away']) ? '#555555' : (($m['team_home_id'] == $team_id && $m['score_home'] > $m['score_away']) || ($m['team_away_id'] == $team_id && $m['score_away'] > $m['score_home']) ? '#28a745' : '#dc3545');
                
                // تنسيق التاريخ والوقت
                $match_time = !empty($m['match_date']) ? date('h:i A', strtotime($m['match_date'])) : '';
                $match_date = !empty($m['match_date']) ? date('Y-m-d', strtotime($m['match_date'])) : '';
            ?>
            <div class="match-row shadow-sm d-flex align-items-center text-center p-2 mb-2 bg-dark rounded" onclick="location.href='match_details.php?id=<?php echo $m['id']; ?>'" style="border-right: 5px solid <?php echo $res_color; ?>; cursor:pointer">
                
                <!-- الفريق المستضيف -->
                <div class="col-4 d-flex align-items-center justify-content-end">
                    <span class="fw-bold me-2"><?php echo htmlspecialchars($m['h_name']); ?></span>
                    <img src="uploads/logos/<?php echo htmlspecialchars($m['h_logo']); ?>" width="30" height="30" style="object-fit:contain;">
                </div>

                <!-- النتيجة والوقت/التاريخ -->
                <div class="col-4">
                    <?php if ($m['status'] == 'finished' || $m['is_finished'] == 1): ?>
                        <span class="badge bg- px-3 py-2 fs-6"><?php echo $m['score_home']; ?> - <?php echo $m['score_away']; ?></span>
                    <?php else: ?>
                        <span class="badge bg-secondary px-3 py-1 mb-1">VS</span>
                    <?php endif; ?>
                    
                    <?php if (!empty($match_date)): ?>
                        <div class="small text-white mt-1" style="font-size: 0.8rem;">
                            <i class="far font-calendar-alt me-1"></i><?php echo $match_date; ?>
                            <?php if(!empty($match_time)): ?>
                                | <i class="far fa-clock me-1"></i><?php echo $match_time; ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- الفريق الضيف -->
                <div class="col-4 d-flex align-items-center justify-content-start">
                    <img src="uploads/logos/<?php echo htmlspecialchars($m['a_logo']); ?>" width="30" height="30" style="object-fit:contain;">
                    <span class="fw-bold ms-2"><?php echo htmlspecialchars($m['a_name']); ?></span>
                </div>

            </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>

        <div class="tab-pane fade" id="tab-standings">
            <div class="mb-3 d-flex justify-content-between align-items-center">
                <h5 class="fw-bold m-0 text-dark">ترتيب الفريق في المجموعة</h5>
                <select id="standingTourFilter" class="form-select w-auto" onchange="loadStandings()">
                    <?php 
                    mysqli_data_seek($tours_res, 0);
                    while($tr = mysqli_fetch_assoc($tours_res)) echo "<option value='".$tr['id']."'>".$tr['name']."</option>";
                    ?>
                </select>
            </div>
            <div id="standings-result-container" class="standing-table-container"></div>
        </div>

        <div class="tab-pane fade" id="tab-scorers">
            <div class="card data-card p-4">
                <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
                    <h5 class="fw-bold mb-0">ترتيب اللاعبين بالأهداف والتقييم</h5>
                     <select id="tourFilter" class="form-select w-auto" onchange="filterDynamic()">
                      <option value="all">كل البطولات مجموع</option>
                     <?php 
                     mysqli_data_seek($tours_res, 0);
                     while($tr = mysqli_fetch_assoc($tours_res)) echo "<option value='tour-".$tr['id']."'>".$tr['name']."</option>";
                     ?>
                     </select>
                 </div>
                 <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-dark">
                            <tr>
                                <th>اللاعب</th>
                                <th class="text-center">الأهداف</th>
                                <th class="text-center">الأسيست</th>
                                <th class="text-center">متوسط التقييم</th>
                            </tr>
                        </thead>
                        <tbody id="dynamicBody"></tbody>
                    </table>
                </div>
            </div> 
        </div>

        <div class="tab-pane fade" id="tab-tours">
            <div class="row g-4">
                <?php 
                mysqli_data_seek($tours_res, 0);
                while($tr = mysqli_fetch_assoc($tours_res)):
                    $tid = $tr['id'];
                    $m_real = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM matches WHERE tournament_id = $tid AND (team_home_id = $team_id OR team_away_id = $team_id)"))['c'];
                    $avg_real = mysqli_fetch_assoc(mysqli_query($conn, "SELECT AVG(rating) as r FROM player_match_stats ps JOIN matches m ON ps.match_id = m.id WHERE m.tournament_id = $tid AND ps.player_id IN (SELECT id FROM players WHERE team_id = $team_id)"))['r'];
                ?>
                <div class="col-md-6 animate__animated animate__zoomIn">
                    <div class="data-card overflow-hidden">
                        <div class="bg-primary p-3 text-white fw-bold">🏆 <?php echo $tr['name']; ?></div>
                        <div class="p-3 row text-center">
                            <div class="col-4 border-end"><h6>المباريات</h6><h4 class="fw-bold"><?php echo $m_real; ?></h4></div>
                            <div class="col-4 border-end"><h6>أداء الفريق</h6><h4 class="fw-bold text-primary"><?php echo number_format($avg_real, 1); ?></h4></div>
                            <div class="col-4"><h6>الأهداف</h6>
                                <?php 
                                $goal_c = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM goals g JOIN matches m ON g.match_id = m.id WHERE m.tournament_id = $tid AND g.player_id IN (SELECT id FROM players WHERE team_id = $team_id)"))['c'];
                                echo "<h4 class='fw-bold text-success'>$goal_c</h4>";
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal التعديل أو التحقق من كلمة السر -->
<div class="modal fade" id="editTeamModal" tabindex="-1" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            
            <?php if (!$can_edit): ?>
            <!-- نموذج إدخال الرقم السري -->
            <div class="modal-header bg-dark text-white">
                <h5 class="fw-bold m-0"><i class="fas fa-lock me-2"></i>إدارة الفريق</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body text-center p-4">
                    <?php echo $msg; ?>
                    <p class="text-muted mb-3">أدخل الرقم السري للتحكم في بيانات الفريق وإضافة اللاعبين</p>
                    <div class="mb-3">
                        <input type="password" name="passcode" class="form-control text-center fs-4" placeholder="••••" required autofocus>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="submit" name="verify_passcode" class="btn btn-primary w-100 py-2 fw-bold">دخول</button>
                </div>
            </form>

            <?php else: ?>
            <!-- لوحة التحكم بالتعديل بعد التأكد من الرقم السري -->
            <div class="modal-header bg-primary text-white">
                <h5 class="fw-bold m-0"><i class="fas fa-user-gear me-2"></i>تعديل بيانات الفريق</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-body text-end p-4">
                    <div class="mb-3 text-center">
                        <img src="uploads/logos/<?php echo $team['logo']; ?>" id="logoPreview" class="rounded mb-2 border p-1" width="80" height="80" style="object-fit:contain">
                        <input type="file" name="team_logo" class="form-control form-control-sm" onchange="document.getElementById('logoPreview').src = window.URL.createObjectURL(this.files[0])">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">اسم الفريق</label>
                        <input type="text" name="team_name" class="form-control" value="<?php echo $team['team_name']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">المدرب</label>
                        <input type="text" name="coach_name" class="form-control" value="<?php echo $team['coach_name']; ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">الرقم السري للفريق</label>
                        <input type="text" name="passcode" class="form-control" value="<?php echo $team['passcode']; ?>" required>
                    </div>
                    
                    <hr class="my-4">
                    <!-- زر سريع للتوجه لإضافة لاعب مع تثبيت الفريق -->
                    <a href="add_player.php?team_id=<?php echo $team_id; ?>" class="btn btn-outline-success w-100 fw-bold">
                        <i class="fas fa-user-plus me-1"></i> إضافة لاعب جديد لهذا الفريق
                    </a>
                </div>
                <div class="modal-footer bg-light">
                    <button type="submit" name="update_team" class="btn btn-primary w-100 py-2 fw-bold">حفظ التغييرات</button>
                </div>
            </form>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php 
// جلب بيانات الترتيب والإحصائيات
$group_standings_data = [];
mysqli_data_seek($tours_res, 0);
while($tr = mysqli_fetch_assoc($tours_res)) {
    $tid = $tr['id'];
    $g_check = mysqli_query($conn, "SELECT group_name FROM matches WHERE tournament_id = $tid AND (team_home_id = $team_id OR team_away_id = $team_id) AND group_name IS NOT NULL LIMIT 1");
    $g_info = mysqli_fetch_assoc($g_check);
    $g_name = $g_info['group_name'] ?? 'بدون مجموعة';

    $st_sql = "SELECT t.id, t.team_name, t.logo,
        COUNT(m.id) as pld,
        SUM(CASE WHEN (m.team_home_id = t.id AND m.score_home > m.score_away) OR (m.team_away_id = t.id AND m.score_away > m.score_home) THEN 1 ELSE 0 END) as wins,
        SUM(CASE WHEN m.score_home = m.score_away AND m.status = 'finished' THEN 1 ELSE 0 END) as draws,
        SUM(CASE WHEN (m.team_home_id = t.id AND m.score_home < m.score_away) OR (m.team_away_id = t.id AND m.score_away < m.score_home) THEN 1 ELSE 0 END) as loss,
        SUM(CASE WHEN (m.team_home_id = t.id AND m.score_home > m.score_away) OR (m.team_away_id = t.id AND m.score_away > m.score_home) THEN 3 WHEN m.score_home = m.score_away AND m.status = 'finished' THEN 1 ELSE 0 END) as pts
        FROM teams t 
        INNER JOIN matches m ON (t.id = m.team_home_id OR t.id = m.team_away_id)
        WHERE m.tournament_id = $tid AND m.group_name = '$g_name' AND m.status = 'finished'
        GROUP BY t.id ORDER BY pts DESC";
    
    $st_res = mysqli_query($conn, $st_sql);
    while($s = mysqli_fetch_assoc($st_res)) {
        $s['tour_id'] = $tid;
        $s['group_label'] = $g_name;
        $group_standings_data[] = $s;
    }
}

$data_sql = "SELECT p.id, p.player_name, p.image, m.tournament_id, 
                    COUNT(DISTINCT CASE WHEN g.player_id = p.id THEN g.id END) as goals,
                    COUNT(DISTINCT CASE WHEN g.assist_player_id = p.id THEN g.id END) as assists,
                    AVG(ps.rating) as avg_rating
             FROM players p
             LEFT JOIN goals g ON (p.id = g.player_id OR p.id = g.assist_player_id)
             LEFT JOIN player_match_stats ps ON p.id = ps.player_id
             LEFT JOIN matches m ON (g.match_id = m.id OR ps.match_id = m.id)
             WHERE p.team_id = $team_id
             GROUP BY p.id, m.tournament_id";
$data_res = mysqli_query($conn, $data_sql);
$player_data = [];
while($r = mysqli_fetch_assoc($data_res)) { $player_data[] = $r; }
?>

<script>
const rawData = <?php echo json_encode($player_data); ?>;
const standingsData = <?php echo json_encode($group_standings_data); ?>;
const currentTeamId = "<?php echo $team_id; ?>";

function loadStandings() {
    const tourId = document.getElementById('standingTourFilter').value;
    const container = document.getElementById('standings-result-container');
    const filtered = standingsData.filter(s => s.tour_id == tourId);

    if(filtered.length === 0) {
        container.innerHTML = '<div class="p-4 text-center text-muted">لا توجد بيانات ترتيب لهذه المجموعة بعد.</div>';
        return;
    }

    let html = `
        <div class="p-2 bg-light text-center fw-bold border-bottom">${filtered[0].group_label}</div>
        <table class="table table-yk-style text-center mb-0">
            <thead>
                <tr><th>#</th><th class="text-start">الفريق</th><th>ل</th><th>ف</th><th>ت</th><th>خ</th><th>ن</th></tr>
            </thead>
            <tbody>`;
    
    filtered.forEach((s, i) => {
        const isCurrent = s.id == currentTeamId ? 'team-highlight' : '';
        html += `
            <tr class="${isCurrent}">
                <td>${i+1}</td>
                <td class="text-start"><img src="uploads/logos/${s.logo}" width="20" class="me-2">${s.team_name}</td>
                <td>${s.pld}</td><td>${s.wins}</td><td>${s.draws}</td><td>${s.loss}</td>
                <td class="text-primary fw-bold">${s.pts}</td>
            </tr>`;
    });
    html += `</tbody></table>`;
    container.innerHTML = html;
}

function filterDynamic() {
    const filter = document.getElementById('tourFilter').value;
    const body = document.getElementById('dynamicBody');
    if(!body) return;
    body.innerHTML = '';
    let processed = {};

    rawData.forEach(item => {
        const tourKey = 'tour-' + item.tournament_id;
        if (filter === 'all' || tourKey === filter) {
            if (!processed[item.id]) {
                processed[item.id] = { name: item.player_name, img: item.image || 'default.png', goals: 0, assists: 0, ratings: [], id: item.id };
            }
            processed[item.id].goals += parseInt(item.goals) || 0;
            processed[item.id].assists += parseInt(item.assists) || 0;
            if(item.avg_rating) processed[item.id].ratings.push(parseFloat(item.avg_rating));
        }
    });

    let sorted = Object.values(processed).sort((a, b) => b.goals - a.goals);

    sorted.forEach(p => {
        let avg = p.ratings.length ? (p.ratings.reduce((a,b) => a+b) / p.ratings.length).toFixed(1) : '0.0';
        body.innerHTML += `
            <tr onclick="location.href='player_profile.php?id=${p.id}'" style="cursor:pointer">
                <td><img src="uploads/players/${p.img}" class="rounded-circle me-2 border" width="35" height="35"> <b>${p.name}</b></td>
                <td class="text-center"><span class="badge bg-success">${p.goals}</span></td>
                <td class="text-center"><span class="badge bg-info text-dark">${p.assists}</span></td>
                <td class="text-center fw-bold text-primary">${avg} ⭐</td>
            </tr>`;
    });
}

window.onload = function() {
    filterDynamic();
    loadStandings();
};
</script>

<?php include 'footer.php'; ?>