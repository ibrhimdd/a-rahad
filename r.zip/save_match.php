<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // استقبال البيانات من النموذج
    $tournament_id = mysqli_real_escape_string($conn, $_POST['tournament_id']);
    $team_home_id  = mysqli_real_escape_string($conn, $_POST['team_home']);
    $team_away_id  = mysqli_real_escape_string($conn, $_POST['team_away']);
    $referee_id    = mysqli_real_escape_string($conn, $_POST['referee_id']);
    $commentator   = mysqli_real_escape_string($conn, $_POST['commentator']);
    $stadium       = mysqli_real_escape_string($conn, $_POST['stadium']);
    $match_date    = mysqli_real_escape_string($conn, $_POST['match_date']);

    // التحقق من عدم اختيار نفس الفريق مرتين
    if ($team_home_id == $team_away_id) {
        die("<div style='color:red; text-align:center; margin-top:50px;'>خطأ: لا يمكن للفريق أن يلعب ضد نفسه!</div>");
    }

    // استعلام الإدخال في جدول المباريات
    $sql = "INSERT INTO matches (
                tournament_id, 
                team_home_id, 
                team_away_id, 
                match_date, 
                stadium, 
                referee_id, 
                commentator, 
                status
            ) VALUES (
                '$tournament_id', 
                '$team_home_id', 
                '$team_away_id', 
                '$match_date', 
                '$stadium', 
                '$referee_id', 
                '$commentator', 
                'upcoming'
            )";

    if (mysqli_query($conn, $sql)) {
        // النجاح: الانتقال لصفحة عرض المباريات
        header("Location: matches.php?msg=match_scheduled");
        exit();
    } else {
        echo "خطأ في الجدولة: " . mysqli_error($conn);
    }
} else {
    // منع الوصول المباشر
    header("Location: add_match.php");
}
?>