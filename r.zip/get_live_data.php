<?php
include 'db.php';
header('Content-Type: application/json');

$match_id = isset($_GET['match_id']) ? intval($_GET['match_id']) : 0;

if (!$match_id) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Match ID']);
    exit;
}

// 1. جلب النتيجة ومعرفات الفريقين
$match_q = mysqli_query($conn, "SELECT score_home, score_away, status, team_home_id, team_away_id FROM matches WHERE id = $match_id");
$match = mysqli_fetch_assoc($match_q);

if (!$match) {
    echo json_encode(['status' => 'error', 'message' => 'Match not found']);
    exit;
}

// 2. جلب الأهداف مع team_id
$goals_sql = "SELECT g.*, 
                     g.goal_minute AS minute, 
                     p1.player_name AS scorer, 
                     p2.player_name AS assistant 
              FROM goals g
              LEFT JOIN players p1 ON g.player_id = p1.id 
              LEFT JOIN players p2 ON g.assist_player_id = p2.id 
              WHERE g.match_id = $match_id 
              ORDER BY g.goal_minute ASC, g.id ASC";

$goals_res = mysqli_query($conn, $goals_sql);
$goals = [];
if ($goals_res) { 
    while ($g = mysqli_fetch_assoc($goals_res)) { 
        $goals[] = $g; 
    } 
}

// 3. جلب التبديلات مع team_id
$subs_sql = "SELECT s.*, p1.player_name AS p_out, p2.player_name AS p_in 
             FROM substitutions s
             LEFT JOIN players p1 ON s.player_out_id = p1.id 
             LEFT JOIN players p2 ON s.player_in_id = p2.id 
             WHERE s.match_id = $match_id 
             ORDER BY s.minute ASC, s.id ASC";

$subs_res = mysqli_query($conn, $subs_sql);
$subs = [];
if ($subs_res) { 
    while ($s = mysqli_fetch_assoc($subs_res)) { 
        $subs[] = $s; 
    } 
}

// 4. جلب الإنذارات/البطاقات مع team_id
$cards_sql = "SELECT c.*, p.player_name 
              FROM cards c 
              LEFT JOIN players p ON c.player_id = p.id 
              WHERE c.match_id = $match_id 
              ORDER BY c.minute ASC, c.id ASC";

$cards_res = mysqli_query($conn, $cards_sql);
$cards = [];
if ($cards_res) { 
    while ($c = mysqli_fetch_assoc($cards_res)) { 
        $cards[] = $c; 
    } 
}

// 5. جلب الإحصائيات
$stats_sql = "SELECT * FROM match_stats WHERE match_id = $match_id";
$stats_res = mysqli_query($conn, $stats_sql);
$stats = ($stats_res && mysqli_num_rows($stats_res) > 0) ? mysqli_fetch_assoc($stats_res) : null;

echo json_encode([
    'status' => 'success',
    'score_home' => (int)$match['score_home'],
    'score_away' => (int)$match['score_away'],
    'team_home_id' => (int)$match['team_home_id'],
    'team_away_id' => (int)$match['team_away_id'],
    'match_status' => $match['status'],
    'goals' => $goals,
    'subs' => $subs,
    'cards' => $cards,
    'stats' => $stats
]);