<?php
// 1. بدء الجلسة للوصول إليها
session_start();

// 2. مسح جميع متغيرات الجلسة (user_id, username, role)
$_SESSION = array();

// 3. تدمير الجلسة بالكامل من السيرفر
session_destroy();

// 4. توجيه المستخدم إلى الصفحة الرئيسية أو صفحة تسجيل الدخول
header("Location: index.php");
exit();
?>