<?php 
include 'db.php'; 
include 'header.php'; 
?>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-5 animate__animated animate__fadeIn">
        <div>
            <h2 class="fw-bold mb-0 text-wheit"><i class="fas fa-running text-success me-2"></i>نجوم الملاعب</h2>
            <p class="text-wheit small">استعرض قائمة اللاعبين وإحصائياتهم الفنية</p>
        </div>
        
        
        
    </div>

    <div class="row g-4">
        <?php
        $sql = "SELECT players.*, teams.team_name 
                FROM players 
                LEFT JOIN teams ON players.team_id = teams.id 
                ORDER BY players.id DESC";
        
        $result = mysqli_query($conn, $sql);

        if ($result && mysqli_num_rows($result) > 0) {
            while($player = mysqli_fetch_assoc($result)) {
                $img = (!empty($player['image'])) ? $player['image'] : 'default_player.png';
        ?>
        <div class="col-lg-3 col-md-4 col-6 player-item">
            <div class="card player-card border-0 shadow-sm mt-5">
                <div class="player-img-container">
                    <img src="uploads/players/<?php echo $img; ?>" class="player-avatar shadow" alt="player">
                </div>
                
                <div class="card-body pt-5 text-center">
                    <h6 class="fw-bold text-wheit mb-1 mt-2"><?php echo $player['player_name']; ?></h6>
                    
                    <div class="mb-2">
                        <span class="badge bg-soft-success text-success rounded-pill px-3 py-1 small">
                            <?php echo $player['position']; ?>
                        </span>
                    </div>

                    <p class="text-success rounded-pill px-3 py-1 small">
                        <i class="fas fa-shield-alt text-primary opacity-50"></i> 
                        <?php echo $player['team_name'] ? $player['team_name'] : 'بدون فريق'; ?>
                    </p>
                    
                    <a href="player_profile.php?id=<?php echo $player['id']; ?>" class="btn btn-dark btn-sm w-100 rounded-pill py-2 view-profile-btn">
                        عرض الإحصائيات
                    </a>
                </div>
            </div>
        </div>
        <?php 
            }
        } else {
            echo "<div class='col-12 text-center py-5'><p class='text-muted'>لا يوجد لاعبون حالياً.</p></div>";
        }
        ?>
    </div>
</div>

<style>
    body { background-color: #f4f7f6; }

    /* تنسيق الكارت */
    .player-card {
        border-radius: 20px;
        transition: all 0.3s ease;
        position: relative;
    }

    /* حاوية الصورة الدائرية */
    .player-img-container {
        position: absolute;
        top: -50px; /* تبرز الصورة من الأعلى */
        left: 50%;
        transform: translateX(-50%);
        width: 100px;
        height: 100px;
        z-index: 2;
    }

    /* الصورة الدائرية نفسها */
    .player-avatar {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 50%; /* دائرة كاملة */
        border: 4px solid #fff;
        background: #eee;
        transition: transform 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }

    /* تأثيرات عند الوقوف بالماوس */
    .player-card:hover {
        transform: translateY(5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important;
    }

    .player-card:hover .player-avatar {
        transform: scale(1.15) rotate(5deg);
        border-color: #198754; /* لون التميز عند الوقوف */
    }

    /* تنسيقات الألوان الإضافية */
    .bg-soft-success {
        background-color: rgba(25, 135, 84, 0.1);
    }

    .view-profile-btn {
        font-size: 0.8rem;
        font-weight: 600;
        transition: background 0.3s;
    }

    .player-card:hover .view-profile-btn {
        background-color: #198754;
        border-color: #198754;
    }

    /* أنيميشن الدخول */
    .player-item {
        animation: slideIn 0.5s ease-out forwards;
    }

    @keyframes slideIn {
        from { opacity: 0; transform: scale(0.9); }
        to { opacity: 1; transform: scale(1); }
    }
</style>
<?php include 'footer.php'; ?>