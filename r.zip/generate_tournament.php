<?php 
include 'db.php'; 
include 'header.php'; 
include 'check_admin.php'; 

$tours_q = mysqli_query($conn, "SELECT * FROM tournaments");
$teams_res = mysqli_query($conn, "SELECT * FROM teams");
$all_teams = [];
while($t = mysqli_fetch_assoc($teams_res)) $all_teams[] = $t;
?>

<div class="container py-5" style="direction: rtl; text-align: right;">
    <div class="card shadow-lg border-0 rounded-4">
        <div class="card-header bg-dark text-white p-4 text-center">
            <h3 class="text-warning mb-0"><i class="fas fa-project-diagram ms-2"></i> المصمم الذكي لمسار البطولة</h3>
            <p class="small mb-0 opacity-75">وزع الفرق في المجموعات وسيتم ربط كل مباراة بمجموعتها تلقائياً</p>
        </div>
        
        <div class="card-body p-4 bg-light">
            <form action="process_full_tournament.php" method="POST">
                
                <div class="row g-3 mb-4 bg-white p-3 rounded shadow-sm border-end border-4 border-primary">
                    <div class="col-md-4">
                        <label class="form-label fw-bold">اختر البطولة:</label>
                        <select name="tournament_id" class="form-select" required>
                            <?php foreach($tours_q as $t) echo "<option value='".$t['id']."'>".$t['name']."</option>"; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">عدد المجموعات:</label>
                        <input type="number" id="num_groups" name="num_groups" class="form-control" value="2" min="1" max="8" onchange="updateAll()">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">الصاعدين من كل مجموعة:</label>
                        <select id="advancers_count" name="advancers_count" class="form-select" onchange="updateAll()">
                            <option value="1">الأول فقط</option>
                            <option value="2" selected>الأول والثاني</option>
                        </select>
                    </div>
                </div>

                <div id="groupsContainer" class="row g-3 mb-5"></div>

                <hr>

                <div id="bracketSection">
                    <h4 class="fw-bold text-center text-primary mb-4">تحديد مسار الأدوار النهائية</h4>
                    <div id="roundsWrapper"></div>
                </div>

                <button type="submit" class="btn btn-primary btn-lg w-100 mt-5 shadow rounded-pill fw-bold">
                    <i class="fas fa-save ms-2"></i> اعتماد المسار وإنشاء البطولة
                </button>
            </form>
        </div>
    </div>
</div>

<script>
const teams = <?php echo json_encode($all_teams); ?>;

function updateAll() {
    generateGroups();
    generateInteractiveBracket();
}

function generateGroups() {
    const numGroups = document.getElementById('num_groups').value;
    const container = document.getElementById('groupsContainer');
    container.innerHTML = '<h5 class="fw-bold text-dark w-100 mb-3 border-bottom pb-2">1. توزيع الفرق حسب المجموعات:</h5>';

    for (let i = 1; i <= numGroups; i++) {
        let groupLetter = String.fromCharCode(64 + i);
        let html = `
            <div class="col-md-4">
                <div class="card border-0 shadow-sm mb-3">
                    <div class="card-header bg-secondary text-white py-1 text-center fw-bold">المجموعة ${groupLetter}</div>
                    <div class="card-body p-2 border">
                        <div id="group_list_${i}"></div>
                        <button type="button" class="btn btn-outline-secondary btn-sm w-100 mt-1" onclick="addTeamToGroup(${i}, '${groupLetter}')">+ إضافة فريق</button>
                    </div>
                </div>
            </div>`;
        container.insertAdjacentHTML('beforeend', html);
    }
}

function addTeamToGroup(groupId, groupLetter) {
    const list = document.getElementById(`group_list_${groupId}`);
    let selectHtml = `
        <div class="d-flex mb-1 gap-1 align-items-center">
            <input type="hidden" name="group_names[${groupId}][]" value="المجموعة ${groupLetter}">
            <select name="group_teams[${groupId}][]" class="form-select form-select-sm" required>
                <option value="">-- اختر فريق --</option>
                ${teams.map(t => `<option value="${t.id}">${t.team_name}</option>`).join('')}
            </select>
            <button type="button" class="btn btn-sm text-danger" onclick="this.parentElement.remove()">×</button>
        </div>`;
    list.insertAdjacentHTML('beforeend', selectHtml);
}

function generateInteractiveBracket() {
    const numGroups = parseInt(document.getElementById('num_groups').value);
    const advCount = parseInt(document.getElementById('advancers_count').value);
    const wrapper = document.getElementById('roundsWrapper');
    wrapper.innerHTML = '';

    let totalAdvancers = numGroups * advCount;
    let currentMatchCount = totalAdvancers / 2;

    let optionsFromGroups = "";
    for (let g = 1; g <= numGroups; g++) {
        let letter = String.fromCharCode(64 + g);
        optionsFromGroups += `<option value="G${g}_1">أول المجموعة ${letter}</option>`;
        if (advCount === 2) optionsFromGroups += `<option value="G${g}_2">ثاني المجموعة ${letter}</option>`;
    }
    
    createRoundUI(currentMatchCount, "الدور الأول (بعد المجموعات)", optionsFromGroups, "match_r1", true);

    let prevRoundMatches = currentMatchCount;
    let currentRoundLevel = 2;

    while (prevRoundMatches >= 2) {
        let matchesInThisRound = prevRoundMatches / 2;
        let roundName = (matchesInThisRound === 1) ? "المباراة النهائية" : (matchesInThisRound === 2 ? "نصف النهائي" : "دور الـ " + (matchesInThisRound*2));
        
        let optionsFromPrevRound = "";
        for (let m = 1; m <= prevRoundMatches; m++) {
            optionsFromPrevRound += `<option value="R${currentRoundLevel-1}_M${m}">الفائز من مباراة ${m}</option>`;
        }

        createRoundUI(matchesInThisRound, roundName, optionsFromPrevRound, `match_r${currentRoundLevel}`, false);
        
        prevRoundMatches = matchesInThisRound;
        currentRoundLevel++;
    }
}

function createRoundUI(matchCount, roundName, options, inputName, isFirst) {
    const wrapper = document.getElementById('roundsWrapper');
    let roundHtml = `
        <div class="mb-5 p-4 bg-white rounded shadow-sm border-start border-4 border-warning">
            <h5 class="fw-bold mb-4 text-dark"><i class="fas fa-chevron-left ms-2 text-warning"></i> ${roundName}</h5>
            <div class="row g-3">
    `;

    for (let i = 1; i <= matchCount; i++) {
        roundHtml += `
            <div class="col-md-6 col-lg-4">
                <div class="p-3 border rounded bg-light">
                    <div class="text-center small fw-bold mb-2 text-primary">مباراة رقم (${i})</div>
                    <div class="d-flex flex-column gap-2">
                        <select name="${inputName}_home[${i}]" class="form-select form-select-sm shadow-sm">${options}</select>
                        <div class="text-center x-small fw-bold text-muted">ضد</div>
                        <select name="${inputName}_away[${i}]" class="form-select form-select-sm shadow-sm">${options}</select>
                    </div>
                </div>
            </div>`;
    }

    roundHtml += `</div></div>`;
    wrapper.insertAdjacentHTML('beforeend', roundHtml);
}

window.onload = updateAll;
</script>