<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // استقبال البيانات وتنظيفها من أي ثغرات
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $role = mysqli_real_escape_string($conn, $_POST['role']); // سيكون إما 'referee' أو 'commentator'
    $nationality = mysqli_real_escape_string($conn, $_POST['nationality']);

    // التأكد من أن الحقول المطلوبة ليست فارغة
    if (!empty($name) && !empty($role)) {
        
        // استعلام الإدخال في جدول officials
        $sql = "INSERT INTO officials (name, role, nationality) 
                VALUES ('$name', '$role', '$nationality')";

        if (mysqli_query($conn, $sql)) {
            // النجاح: العودة للوحة التحكم مع رسالة نجاح
            header("Location: admin.php?msg=official_added");
            exit();
        } else {
            // خطأ في قاعدة البيانات
            echo "خطأ في قاعدة البيانات: " . mysqli_error($conn);
        }
    } else {
        // إذا حاول أحد الوصول للملف بدون بيانات
        echo "من فضلك أكمل البيانات المطلوبة.";
    }
} else {
    // حماية الملف: منع الوصول المباشر عبر الرابط
    header("Location: admin.php");
}
?>