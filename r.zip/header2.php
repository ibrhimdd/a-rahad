<?php
// بدء الجلسة
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function isLogged() {
    return isset($_SESSION['user_id']);
}

// تحديد الصفحة الحالية لإضافة لون تمييز للرابط النشط (Active)
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ملعب أحمد رشاد - إدارة البطولات</title>

    <!-- Bootstrap RTL -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">

    <!-- Icons & Animations -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

    <!-- Google Font -->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;900&display=swap');

        body {
            background-color: #f1f3f6;
            font-family: 'Cairo', sans-serif;
            padding-bottom: 75px; /* مساحة سفلى حتى لا يغطي الشريط على محتوى الصفحة */
        }

        /* الهيدر العلوي لشعار الموقع ودخول المستخدم */
        .top-header {
            background: #ffffff;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 10px 0;
            border-bottom: 1px solid #e2e8f0;
        }

        .user-avatar {
            width: 32px;
            height: 32px;
            background: #1a237e;
            color: #ffffff;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-left: 8px;
        }

        /* ------------------------------------ */
        /* تصميم الشريط السفلي المطابق للصورة */
        /* ------------------------------------ */
        .bottom-nav-bar {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: #ffffff;
            box-shadow: 0 -3px 15px rgba(0, 0, 0, 0.08);
            border-top: 1px solid #e2e8f0;
            z-index: 1030;
            height: 65px;
            display: flex;
            align-items: center;
            justify-content: space-around;
            padding: 0 5px;
        }

        .bottom-nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            flex: 1;
            text-decoration: none;
            color: #64748b;
            font-size: 0.72rem;
            font-weight: 700;
            transition: all 0.2s ease-in-out;
            padding: 4px 0;
            border: none;
            background: none;
        }

        .bottom-nav-item i {
            font-size: 1.25rem;
            margin-bottom: 3px;
            transition: all 0.2s ease-in-out;
        }

        .bottom-nav-item:hover {
            color: #1a237e;
        }

        /* العنصر النشط (Active Tab) */
        .bottom-nav-item.active {
            color: #0d6efd;
        }

        .bottom-nav-item.active i {
            transform: translateY(-2px);
            color: #0d6efd;
        }

        .dropdown-menu {
            border: none;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        }

        /* إصلاح المودال */
        .modal-backdrop { opacity: 0.5 !important; }
        .modal { z-index: 1055; }
    </style>
</head>
<body>

<!-- الهيدر العلوي: الشعار ومعلومات الحساب -->
<header class="top-header sticky-top">
    <div class="container d-flex align-items-center justify-content-between">
        <a class="navbar-brand text-dark fw-bold m-0" href="index.php">
            <i class="fas fa-trophy text-warning me-2"></i> ملعب أحمد رشاد
        </a>

        <div class="d-flex align-items-center">
            <?php if(isLogged()): ?>
                <div class="dropdown">
                    <a class="btn btn-light rounded-pill dropdown-toggle d-flex align-items-center px-3 border" href="#" data-bs-toggle="dropdown">
                        <span class="user-avatar">
                            <?php echo mb_substr($_SESSION['username'], 0, 1, 'utf-8'); ?>
                        </span>
                        <span class="fw-bold small"><?php echo $_SESSION['username']; ?></span>
                    </a>

                    <ul class="dropdown-menu dropdown-menu-end shadow mt-2">
                        <li><a class="dropdown-item" href="profile.php"><i class="fas fa-user-circle me-2"></i>ملفي الشخصي</a></li>
                        <?php if(isAdmin()): ?>
                            <li><a class="dropdown-item" href="add_match.php"><i class="fas fa-plus me-2"></i>إضافة مباراة</a></li>
                        <?php endif; ?>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>تسجيل الخروج</a></li>
                    </ul>
                </div>
            <?php else: ?>
                <a href="login.php" class="btn btn-outline-primary btn-sm rounded-pill px-3 me-2">دخول</a>
                <a href="register.php" class="btn btn-primary btn-sm rounded-pill px-3 fw-bold">اشتراك</a>
            <?php endif; ?>
        </div>
    </div>
</header>

<!-- الشريط السفلي (Bottom Navigation) مثل التطبيقات -->
<nav class="bottom-nav-bar">
    <a href="matches.php" class="bottom-nav-item <?php echo ($current_page == 'matches.php') ? 'active' : ''; ?>">
        <i class="fas fa-futbol"></i>
        <span>المباريات</span>
    </a>

    <a href="tournaments_list.php" class="bottom-nav-item <?php echo ($current_page == 'tournaments_list.php') ? 'active' : ''; ?>">
        <i class="fas fa-trophy"></i>
        <span>البطولات</span>
    </a>

    <a href="teams.php" class="bottom-nav-item <?php echo ($current_page == 'teams.php') ? 'active' : ''; ?>">
        <i class="fas fa-shield-alt"></i>
        <span>الفرق</span>
    </a>

    <a href="players.php" class="bottom-nav-item <?php echo ($current_page == 'players.php') ? 'active' : ''; ?>">
        <i class="fas fa-users"></i>
        <span>اللاعبين</span>
    </a>

    <?php if(isAdmin()): ?>
        <div class="dropup">
            <button class="bottom-nav-item dropdown-toggle border-0 bg-transparent <?php echo in_array($current_page, ['admin.php', 'setup_matches.php', 'reset_db.php']) ? 'active' : ''; ?>" type="button" data-bs-toggle="dropdown">
                <i class="fas fa-cog"></i>
                <span>الإدارة</span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow mb-2">
                <li><a class="dropdown-item" href="admin.php"><i class="fas fa-tachometer-alt me-2"></i>لوحة التحكم</a></li>
                <li><a class="dropdown-item" href="setup_matches.php"><i class="fas fa-tools me-2"></i>تجهيز المباريات</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger" href="reset_db.php"><i class="fas fa-trash-alt me-2"></i>تصفير البيانات</a></li>
            </ul>
        </div>
    <?php endif; ?>
</nav>

<div class="container mt-4 animate__animated animate__fadeIn">