<?php
include 'db.php';
include 'check_admin.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $team_name = mysqli_real_escape_string($conn, $_POST['team_name']);
    $coach_name = mysqli_real_escape_string($conn, $_POST['coach_name']); // استقبال اسم المدرب
    $stadium_name = mysqli_real_escape_string($conn, $_POST['stadium_name']);
    
    // معالجة رفع اللوجو
    $logo = 'default.png'; // القيمة الافتراضية
    if (!empty($_FILES['logo']['name'])) {
        $logo = time() . '_' . $_FILES['logo']['name'];
        move_uploaded_file($_FILES['logo']['tmp_name'], "uploads/logos/" . $logo);
    }

    // استعلام الإدخال مع العمود الجديد coach_name
    $sql = "INSERT INTO teams (team_name, coach_name, stadium_name, logo) 
            VALUES ('$team_name', '$coach_name', '$stadium_name', '$logo')";

    if (mysqli_query($conn, $sql)) {
        header("Location: teams.php?success=1");
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>