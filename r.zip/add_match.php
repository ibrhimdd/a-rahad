<?php include 'db.php'; include 'header.php'; ?>
<?php include 'check_admin.php'; ?>
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card shadow-lg p-4">
            <h2 class="text-center mb-4 text-danger"><i class="fas fa-calendar-check"></i> إنشاء كارت مباراة</h2>
            <form action="save_match.php" method="POST">
                <div class="row">
                    <div class="col-md-12 mb-4">
                        <label class="fw-bold">1. اختر البطولة</label>
                        <select name="tournament_id" id="tournament_select" class="form-select form-select-lg border-danger" required>
                            <option value="">-- اختر البطولة لتحديد الفرق المتاحة --</option>
                            <?php
                            $tours = mysqli_query($conn, "SELECT * FROM tournaments");
                            while($t = mysqli_fetch_assoc($tours)) {
                                echo "<option value='".$t['id']."'>".$t['name']."</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label>الفريق الأول (صاحب الأرض)</label>
                        <select name="team_home" id="team_home" class="form-select" required disabled>
                            <option>اختر البطولة أولاً</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>الفريق الثاني (الضيف)</label>
                        <select name="team_away" id="team_away" class="form-select" required disabled>
                            <option>اختر البطولة أولاً</option>
                        </select>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label>الحكم</label>
                        <select name="referee_id" id="referee_select" class="form-select" required disabled>
                            <option>اختر البطولة أولاً</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label>المعلق</label>
                        <select name="commentator" class="form-select">
                            <?php
                            $comm = mysqli_query($conn, "SELECT * FROM officials WHERE role='commentator'");
                            while($c = mysqli_fetch_assoc($comm)) {
                                echo "<option value='".$c['name']."'>".$c['name']."</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label>الملعب</label>
                        <input type="text" name="stadium" class="form-control" placeholder="اسم الملعب">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label>تاريخ وموعد المباراة</label>
                        <input type="datetime-local" name="match_date" class="form-control" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-danger w-100 mt-3 fw-bold">جدولة المباراة الآن</button>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('tournament_select').addEventListener('change', function() {
    var tournamentId = this.value;
    if(tournamentId) {
        fetch('get_tournament_data.php?id=' + tournamentId)
        .then(response => response.json())
        .then(data => {
            // تفعيل القوائم المنسدلة
            let home = document.getElementById('team_home');
            let away = document.getElementById('team_away');
            let referee = document.getElementById('referee_select');
            
            home.disabled = away.disabled = referee.disabled = false;
            home.innerHTML = away.innerHTML = '<option value="">اختر الفريق</option>';
            referee.innerHTML = '<option value="">اختر الحكم</option>';

            // تعبئة الفرق
            data.teams.forEach(team => {
                home.innerHTML += `<option value="${team.id}">${team.name}</option>`;
                away.innerHTML += `<option value="${team.id}">${team.name}</option>`;
            });

            // تعبئة الحكام
            data.referees.forEach(ref => {
                referee.innerHTML += `<option value="${ref.id}">${ref.name}</option>`;
            });
        });
    }
});
</script>

<?php include 'footer.php'; ?>