<?php 
include 'db.php'; 
include 'header.php'; 

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<div class='container py-5'><div class='alert alert-danger text-center bg-dark text-danger border-danger'>عذراً، لم يتم تحديد مباراة لعرضها.</div></div>";
    include 'footer.php';
    exit;
}

$match_id = intval($_GET['id']);

$sql = "SELECT matches.*, 
        t1.team_name AS home_name, t1.logo AS home_logo,
        t2.team_name AS away_name, t2.logo AS away_logo,
        tournaments.name AS tour_name,
        officials.name AS ref_name
        FROM matches 
        LEFT JOIN teams t1 ON matches.team_home_id = t1.id
        LEFT JOIN teams t2 ON matches.team_away_id = t2.id
        LEFT JOIN tournaments ON matches.tournament_id = tournaments.id
        LEFT JOIN officials ON matches.referee_id = officials.id
        WHERE matches.id = $match_id";

$result = mysqli_query($conn, $sql);
$match = mysqli_fetch_assoc($result);

if (!$match) {
    echo "<div class='container py-5'><div class='alert alert-danger text-center bg-dark text-danger border-danger'>المباراة غير موجودة في النظام.</div></div>";
    include 'footer.php';
    exit;
}
?>
<style>
    /* خلفية وتصميم هيدر المباراة الرئيسي - Dark Mode */
    .match-header-card {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
        border-radius: 20px;
        color: #f8fafc;
        position: relative;
        overflow: hidden;
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
    }

    /* كبسولة اسم البطولة */
    .league-badge-capsule {
        background: #334155;
        color: #f1f5f9;
        border-radius: 50px;
        padding: 6px 20px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        font-weight: 700;
        font-size: 0.9rem;
        border: 1px solid rgba(255, 255, 255, 0.05);
    }
    .league-logo {
        width: 22px;
        height: 22px;
        object-fit: contain;
    }

    /* أزرار التنقل الدائرية */
    .nav-circle-btn {
        width: 38px;
        height: 38px;
        background: #334155;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #cbd5e1;
        box-shadow: 0 2px 6px rgba(0,0,0,0.3);
        cursor: pointer;
        transition: all 0.2s;
    }
    .nav-circle-btn:hover {
        background: #475569;
        color: #ffffff;
        transform: scale(1.05);
    }

    /* الشعارات والفرق */
    .team-block {
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    .team-name-title {
        font-size: 1.1rem;
        font-weight: 800;
        color: #f8fafc;
        margin-bottom: 12px;
    }
    .team-logo-img {
        width: 75px;
        height: 75px;
        object-fit: contain;
        filter: drop-shadow(0 4px 10px rgba(0,0,0,0.5));
    }

    /* منطقة النتيجة والحالة */
    .status-badge-outline {
        background: rgba(51, 65, 85, 0.6);
        border: 1px solid #475569;
        color: #94a3b8;
        font-size: 0.8rem;
        font-weight: 700;
        border-radius: 20px;
        padding: 3px 14px;
        display: inline-block;
        margin-bottom: 8px;
    }
    .status-badge-live {
        background: rgba(153, 27, 27, 0.4);
        border: 1px solid #ef4444;
        color: #fca5a5;
    }

    .score-display {
        font-size: 2.8rem;
        font-weight: 900;
        color: #38bdf8;
        letter-spacing: 6px;
        line-height: 1;
        text-shadow: 0 2px 10px rgba(56, 189, 248, 0.3);
    }

    /* التذييل السفلي */
    .match-footer-info {
        font-size: 0.85rem;
        color: #94a3b8;
        font-weight: 600;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 15px;
        flex-wrap: wrap;
    }

    /* باقي تنسيقات الكروت */
    .stat-card { 
        border: 1px solid rgba(255, 255, 255, 0.08) !important; 
        border-radius: 12px; 
        background-color: #1e293b !important;
    }
    .exclusive-info-card {
        background: #1e293b;
        overflow: hidden;
    }
    .info-item-box {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 14px 18px;
        border-bottom: 1px dashed #334155;
    }
    .info-icon-wrapper {
        width: 40px; height: 40px; border-radius: 10px;
        display: flex; align-items: center; justify-content: center;
        font-size: 1.1rem; margin-left: 12px;
    }

    /* التبويبات - Tabs */
    .custom-tabs {
        background: #1e293b;
        border-radius: 12px;
        padding: 6px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        border-bottom: 1px solid #334155 !important;
    }
    .custom-tabs .nav-link {
        color: #94a3b8 !important;
        font-weight: 700;
        border: none;
        border-radius: 8px;
        padding: 10px 20px;
        transition: all 0.3s ease;
        background: transparent !important;
    }
    .custom-tabs .nav-link:hover {
        color: #f8fafc !important;
        background: #334155 !important;
    }
    .custom-tabs .nav-link.active {
        color: #ffffff !important;
        background: #2563eb !important;
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.4);
    }

    /* ألوان الجدول في المود الداكن */
    .table-dark-custom {
        color: #cbd5e1 !important;
    }
    .table-dark-custom thead {
        background-color: #0f172a !important;
        color: #94a3b8 !important;
    }
    .table-dark-custom td, .table-dark-custom th {
        border-color: #334155 !important;
    }
    .table-hover tbody tr:hover {
        color: #fff !important;
        background-color: rgba(255, 255, 255, 0.03) !important;
    }
</style>

<div class="container py-4">
    <!-- كارت شاشة المباراة الرئيسي -->
    <div class="match-header-card p-3 p-md-4 mb-4 text-center">
        <div class="d-flex align-items-center justify-content-between mb-4 px-2">
            <div class="nav-circle-btn">
                <i class="fas fa-chevron-right"></i>
            </div>
            
            <div class="league-badge-capsule">
                <span><?php echo htmlspecialchars($match['tour_name'] ?? 'الدوري الأمريكي لكرة القدم'); ?></span>
                <img src="uploads/logos/league_default.png" class="league-logo" onerror="this.style.display='none';">
            </div>

            <div class="nav-circle-btn">
                <i class="fas fa-share-alt"></i>
            </div>
        </div>

        <div class="row align-items-center my-2">
            <!-- الفريق الضيف / الأيسر -->
            <div class="col-4">
                <div class="team-block">
                    <h3 class="team-name-title"><?php echo htmlspecialchars($match['away_name'] ?? 'إنتر ميامي'); ?></h3>
                    <img src="uploads/logos/<?php echo htmlspecialchars($match['away_logo'] ?? 'default.png'); ?>" class="team-logo-img" onerror="this.src='uploads/logos/default.png';">
                </div>
            </div>

            <!-- النتيجة وحالة المباراة -->
            <div class="col-4">
                <div class="mb-1">
                    <?php if($match['status'] == 'finished'): ?>
                        <span class="status-badge-outline">انتهت المباراة</span>
                    <?php elseif($match['status'] == 'live'): ?>
                        <span class="status-badge-outline status-badge-live"><span class="live-pulse me-1"></span> مباشر</span>
                    <?php else: ?>
                        <span class="status-badge-outline">قادمة</span>
                    <?php endif; ?>
                </div>

                <div class="score-display" id="live-score">
                    <?php echo (int)$match['score_away']; ?> - <?php echo (int)$match['score_home']; ?>
                </div>
            </div>

            <!-- الفريق المضيف / الأيمن -->
            <div class="col-4">
                <div class="team-block">
                    <h3 class="team-name-title"><?php echo htmlspecialchars($match['home_name'] ?? 'كولومبوس كرو'); ?></h3>
                    <img src="uploads/logos/<?php echo htmlspecialchars($match['home_logo'] ?? 'default.png'); ?>" class="team-logo-img" onerror="this.src='uploads/logos/default.png';">
                </div>
            </div>
        </div>

        <div class="match-footer-info mt-4 pt-2">
            <span>
                <i class="fas fa-map-marker-alt ms-1 text-info"></i> 
                <?php echo htmlspecialchars($match['stadium'] ?: 'ملعب غير محدد'); ?>
            </span>
            <span>
                <i class="far fa-calendar-alt ms-1 text-info"></i> 
                <?php echo date('Y-m-d - h:i A', strtotime($match['match_date'])); ?>
            </span>
        </div>
    </div>

    <!-- بطاقة تفاصيل المباراة -->
    <div class="row">
        <div class="col-12">
            <div class="card stat-card shadow-sm exclusive-info-card mb-4">
                <div class="card-header border-0 py-3 px-4 d-flex align-items-center" style="background: #0f172a; border-bottom: 1px solid #334155 !important;">
                    <div class="info-icon-wrapper bg-info bg-opacity-20 text-info me-2">
                        <i class="fas fa-info-circle"></i>
                    </div>
                    <h5 class="mb-0 fw-bold text-white">بطاقة المباراة التفصيلية</h5>
                </div>
                <div class="card-body p-0">
                    <div class="row g-0">
                        <div class="col-md-6">
                            <div class="info-item-box">
                                <div class="d-flex align-items-center">
                                    <div class="info-icon-wrapper bg-warning bg-opacity-20 text-warning">
                                        <i class="fas fa-user-shield"></i>
                                    </div>
                                    <span class="text-slate-400 fw-semibold ms-2" style="color: #94a3b8;">الحكم الرئيسي:</span>
                                </div>
                                <span class="fw-bold text-white"><?php echo htmlspecialchars($match['ref_name'] ?: 'غير محدد'); ?></span>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="info-item-box">
                                <div class="d-flex align-items-center">
                                    <div class="info-icon-wrapper bg-primary bg-opacity-20 text-primary">
                                        <i class="fas fa-microphone"></i>
                                    </div>
                                    <span class="text-slate-400 fw-semibold ms-2" style="color: #94a3b8;">المعلق الصوتي:</span>
                                </div>
                                <span class="fw-bold text-white"><?php echo htmlspecialchars($match['commentator'] ?: 'غير محدد'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- قائمة التبويبات -->
<ul class="nav nav-tabs custom-tabs justify-content-center mb-4" id="matchTabs" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="events-tab" data-bs-toggle="tab" data-bs-target="#events-tab-pane" type="button" role="tab">
            <i class="fas fa-list-ul me-1"></i> أحداث المباراة
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="stats-tab" data-bs-toggle="tab" data-bs-target="#stats-tab-pane" type="button" role="tab">
            <i class="fas fa-chart-bar me-1"></i> إحصائيات اللقاء
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="ratings-tab" data-bs-toggle="tab" data-bs-target="#ratings-tab-pane" type="button" role="tab">
            <i class="fas fa-star me-1"></i> تقييمات اللاعبين
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="predictions-tab" data-bs-toggle="tab" data-bs-target="#predictions-tab-pane" type="button" role="tab">
            <i class="fas fa-chart-pie me-1"></i> توقعات الجمهور
        </button>
    </li>
</ul>

<!-- محتوى التبويبات -->
<div class="tab-content" id="matchTabsContent">

    <!-- 1. أحداث المباراة -->
    <div class="tab-pane fade show active" id="events-tab-pane" role="tabpanel">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="card stat-card shadow-sm mb-4">
                    <div class="card-header border-0 py-3 d-flex justify-content-between align-items-center" style="background: #0f172a;">
                        <span class="fw-bold small text-info"><?php echo htmlspecialchars($match['home_name']); ?></span>
                        <h5 class="mb-0 fw-bold text-white"><i class="fas fa-futbol text-success me-1"></i> الأهداف</h5>
                        <span class="fw-bold small text-danger"><?php echo htmlspecialchars($match['away_name']); ?></span>
                    </div>
                    <div class="card-body p-2" id="goals-list-container">
                        <p class="text-white text-center py-2 mb-0">جاري التحميل...</p>
                    </div>
                </div>

                <div class="card stat-card shadow-sm mb-4">
                    <div class="card-header border-0 py-3 d-flex justify-content-between align-items-center" style="background: #0f172a;">
                        <span class="fw-bold small text-info"><?php echo htmlspecialchars($match['home_name']); ?></span>
                        <h5 class="mb-0 fw-bold text-white"><i class="fas fa-exchange-alt text-warning me-1"></i> التبديلات</h5>
                        <span class="fw-bold small text-danger"><?php echo htmlspecialchars($match['away_name']); ?></span>
                    </div>
                    <div class="card-body p-2" id="subs-list-container">
                        <p class="text-white text-center py-2 mb-0">جاري التحميل...</p>
                    </div>
                </div>

                <div class="card stat-card shadow-sm mb-4">
                    <div class="card-header border-0 py-3 d-flex justify-content-between align-items-center" style="background: #0f172a;">
                        <span class="fw-bold small text-info"><?php echo htmlspecialchars($match['home_name']); ?></span>
                        <h5 class="mb-0 fw-bold text-white"><i class="fas fa-clone text-danger me-1"></i> البطاقات</h5>
                        <span class="fw-bold small text-danger"><?php echo htmlspecialchars($match['away_name']); ?></span>
                    </div>
                    <div class="card-body p-2" id="cards-list-container">
                        <p class="text-white text-center py-2 mb-0">جاري التحميل...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 2. إحصائيات اللقاء -->
    <div class="tab-pane fade" id="stats-tab-pane" role="tabpanel">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="card stat-card shadow-sm mb-4">
                    <div class="card-header border-0 py-3" style="background: #0f172a;">
                        <h5 class="mb-0 fw-bold text-white"><i class="fas fa-chart-bar text-info me-2"></i> إحصائيات المقارنة</h5>
                    </div>
                    <div class="card-body text-slate-300" id="team-stats-container">
                        <p class="text-white text-center py-2">جاري التحميل...</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 3. تقييمات اللاعبين -->
    <div class="tab-pane fade" id="ratings-tab-pane" role="tabpanel">
        <div class="card stat-card shadow-sm mb-4">
            <div class="card-header border-0 py-3" style="background: #0f172a;">
                <h5 class="mb-0 fw-bold text-white"><i class="fas fa-star text-warning me-2"></i> تقييمات وأداء اللاعبين</h5>
            </div>
            <div class="table-responsive">
                <table class="table align-middle table-hover mb-0 table-dark-custom">
                    <thead>
                        <tr>
                            <th class="ps-4">اللاعب</th>
                            <th>الفريق</th>
                            <th class="text-center">الأهداف</th>
                            <th class="text-center">الأسيست</th>
                            <th class="text-center">التقييم</th>
                            <th class="text-center">البطاقات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $stats_sql = "SELECT s.*, p.player_name, p.image, t.team_name,
                                      (SELECT COUNT(*) FROM goals WHERE player_id = s.player_id AND match_id = $match_id) as g_count,
                                      (SELECT COUNT(*) FROM goals WHERE assist_player_id = s.player_id AND match_id = $match_id) as a_count
                                      FROM player_match_stats s
                                      LEFT JOIN players p ON s.player_id = p.id
                                      LEFT JOIN teams t ON p.team_id = t.id
                                      WHERE s.match_id = $match_id 
                                      ORDER BY s.is_mvp DESC, s.rating DESC";
                        $stats_res = mysqli_query($conn, $stats_sql);
                        
                        if($stats_res && mysqli_num_rows($stats_res) > 0):
                            while($s = mysqli_fetch_assoc($stats_res)): 
                                $rating_class = ($s['rating'] >= 8) ? 'bg-success' : (($s['rating'] >= 6) ? 'bg-primary' : 'bg-danger');
                            ?>
                            <tr>
                                <td class="ps-4">
                                    <div class="d-flex align-items-center">
                                        <img src="uploads/players/<?php echo htmlspecialchars($s['image'] ?: 'default.png'); ?>" class="rounded-circle me-3" width="40" height="40" style="object-fit: cover; border: 1px solid #475569;" onerror="this.src='uploads/players/default.png';">
                                        <div>
                                            <a href="player_profile.php?id=<?php echo $s['player_id']; ?>" class="player-link fw-bold d-block text-decoration-none text-info">
                                                <?php echo htmlspecialchars($s['player_name'] ?: 'لاعب'); ?>
                                            </a>
                                            <?php if(!empty($s['is_mvp'])): ?>
                                                <span class="mvp-badge text-warning small"><i class="fas fa-crown me-1"></i> رجل المباراة</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                                <td><small class="text-white fw-bold"><?php echo htmlspecialchars($s['team_name'] ?: '-'); ?></small></td>
                                <td class="text-center">
                                    <?php echo ($s['g_count'] > 0) ? "<span class='badge bg-success rounded-pill'>{$s['g_count']} ⚽</span>" : "-"; ?>
                                </td>
                                <td class="text-center">
                                    <?php echo ($s['a_count'] > 0) ? "<span class='badge bg-info text-dark rounded-pill'>{$s['a_count']} 👟</span>" : "-"; ?>
                                </td>
                                <td class="text-center">
                                    <span class="badge <?php echo $rating_class; ?> px-3 py-2" style="font-size: 0.9rem;"><?php echo $s['rating']; ?></span>
                                </td>
                                <td class="text-center">
                                    <?php if(!empty($s['yellow_cards'])): ?> <i class="fas fa-square text-warning mx-1" title="كرت أصفر"></i> <?php endif; ?>
                                    <?php if(!empty($s['red_cards'])): ?> <i class="fas fa-square text-danger mx-1" title="كرت أحمر"></i> <?php endif; ?>
                                    <?php if(empty($s['yellow_cards']) && empty($s['red_cards'])): echo "-"; endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; 
                        else: ?>
                            <tr><td colspan="6" class="text-center py-4 text-white">لا توجد تقييمات لاعبين مطروحة لهذه المباراة حالياً.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- 4. توقعات الجمهور -->
    <div class="tab-pane fade" id="predictions-tab-pane" role="tabpanel">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card stat-card shadow-sm mb-4">
                    <div class="card-header border-0 py-3 text-center" style="background: #0f172a;">
                        <h5 class="mb-0 fw-bold text-white"><i class="fas fa-chart-pie text-info me-2"></i> توقعات الجمهور</h5>
                        <small class="text-white">نسب توقعات المتابعين لنتيجة المباراة</small>
                    </div>
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-white small fw-bold">إجمالي التوقعات:</span>
                            <span class="badge bg-slate-700 text-info fs-6 border border-secondary" id="total-votes-count">0</span>
                        </div>

                        <div class="progress mb-3" style="height: 28px; background-color: #334155; border-radius: 8px; overflow: hidden;">
                            <div id="bar-home" class="progress-bar bg-primary fw-bold" role="progressbar" style="width: 0%" title="فوز صاحب الأرض">0%</div>
                            <div id="bar-draw" class="progress-bar bg-secondary fw-bold" role="progressbar" style="width: 0%" title="تعادل">0%</div>
                            <div id="bar-away" class="progress-bar bg-warning text-dark fw-bold" role="progressbar" style="width: 0%" title="فوز الضيف">0%</div>
                        </div>

                        <div class="d-flex justify-content-between mt-3 text-center small fw-bold">
                            <span class="text-info"><i class="fas fa-square me-1"></i> <?php echo htmlspecialchars($match['home_name']); ?>: <span id="text-home-percent">0%</span></span>
                            <span class="text-secondary"><i class="fas fa-square me-1"></i> تعادل: <span id="text-draw-percent">0%</span></span>
                            <span class="text-warning"><i class="fas fa-square me-1"></i> <?php echo htmlspecialchars($match['away_name']); ?>: <span id="text-away-percent">0%</span></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- JavaScript والتحديث الحي (معدل بالتنسيق الداكن أيضاً) -->
<script>
const matchId = <?php echo $match_id; ?>;
const homeTeamId = <?php echo (int)$match['team_home_id']; ?>;

function refreshMatchLiveData() {
    fetch('get_live_data.php?match_id=' + matchId)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // تحديث النتيجة
                document.getElementById('live-score').innerText = `${data.score_away} - ${data.score_home}`;

                // 1. الأهداف
                let goalsHtml = '';
                if (data.goals && data.goals.length > 0) {
                    data.goals.forEach(g => {
                        let typeIcon = '⚽';
                        if(g.goal_type === 'penalty') typeIcon = '🎯';
                        if(g.goal_type === 'own_goal') typeIcon = '❌';

                        let minVal = g.goal_minute !== undefined ? g.goal_minute : (g.minute || 0);
                        let assistText = g.assistant ? `<small class="text-white d-block" style="font-size:0.75rem;">صناعة: ${g.assistant}</small>` : '';
                        let isHome = (parseInt(g.team_id) === homeTeamId);

                        goalsHtml += `
                            <div class="row align-items-center py-2 border-bottom border-secondary g-0" style="font-size: 0.88rem;">
                                <div class="col-5 text-end pe-2">
                                    ${isHome ? `<div class="text-white"><strong>${g.scorer || 'لاعب'}</strong> ${typeIcon}${assistText}</div>` : ''}
                                </div>
                                <div class="col-2 text-center">
                                    <span class="badge bg-dark text-light border border-secondary px-2 py-1">${minVal}'</span>
                                </div>
                                <div class="col-5 text-start ps-2">
                                    ${!isHome ? `<div class="text-white">${typeIcon} <strong>${g.scorer || 'لاعب'}</strong>${assistText}</div>` : ''}
                                </div>
                            </div>
                        `;
                    });
                } else {
                    goalsHtml = `<p class="text-white text-center py-3 mb-0">لا توجد أهداف حتى الآن</p>`;
                }
                document.getElementById('goals-list-container').innerHTML = goalsHtml;

                // 2. التبديلات
                let subsHtml = '';
                if (data.subs && data.subs.length > 0) {
                    data.subs.forEach(s => {
                        let isHome = (parseInt(s.team_id) === homeTeamId);
                        let subContent = `
                            <div class="text-success fw-bold" style="font-size: 0.8rem;">🟢 ${s.p_in || 'لاعب'}</div>
                            <div class="text-danger small" style="font-size: 0.75rem;">🔴 ${s.p_out || 'لاعب'}</div>
                        `;

                        subsHtml += `
                            <div class="row align-items-center py-2 border-bottom border-secondary g-0">
                                <div class="col-5 text-end pe-2">
                                    ${isHome ? subContent : ''}
                                </div>
                                <div class="col-2 text-center">
                                    <span class="badge bg-dark text-light border border-secondary px-2 py-1">${s.minute || 0}'</span>
                                </div>
                                <div class="col-5 text-start ps-2">
                                    ${!isHome ? subContent : ''}
                                </div>
                            </div>
                        `;
                    });
                } else {
                    subsHtml = `<p class="text-white text-center py-3 mb-0">لا توجد تبديلات في اللقاء</p>`;
                }
                document.getElementById('subs-list-container').innerHTML = subsHtml;

                // 3. البطاقات
                let cardsHtml = '';
                if (data.cards && data.cards.length > 0) {
                    data.cards.forEach(c => {
                        let isHome = (parseInt(c.team_id) === homeTeamId);
                        let isYellow = (c.card_type === 'yellow' || c.card_type === 'أصفر');
                        let cardBadge = isYellow 
                            ? `<span class="badge bg-warning text-dark me-1" style="border: 1px solid #d39e00;">🟨 أصفر</span>` 
                            : `<span class="badge bg-danger text-white me-1" style="border: 1px solid #bd2130;">🟥 أحمر</span>`;

                        let cardContent = `
                            <div class="d-inline-flex align-items-center text-white">
                                ${cardBadge}
                                <strong class="player-link">${c.player_name || 'لاعب'}</strong>
                            </div>
                        `;

                        cardsHtml += `
                            <div class="row align-items-center py-2 border-bottom border-secondary g-0" style="font-size: 0.88rem;">
                                <div class="col-5 text-end pe-2">
                                    ${isHome ? cardContent : ''}
                                </div>
                                <div class="col-2 text-center">
                                    <span class="badge bg-dark text-light border border-secondary px-2 py-1">${c.minute || 0}'</span>
                                </div>
                                <div class="col-5 text-start ps-2">
                                    ${!isHome ? cardContent : ''}
                                </div>
                            </div>
                        `;
                    });
                } else {
                    cardsHtml = `<p class="text-white text-center py-3 mb-0">لا توجد كروت في اللقاء</p>`;
                }
                document.getElementById('cards-list-container').innerHTML = cardsHtml;

                // 4. الإحصائيات
                if (data.stats) {
                    let st = data.stats;
                    let homePoss = st.home_possession || 50;
                    let awayPoss = st.away_possession || 50;
                    
                    document.getElementById('team-stats-container').innerHTML = `
                        <div class="mb-3">
                            <div class="d-flex justify-content-between small fw-bold mb-1 text-light">
                                <span>${homePoss}%</span>
                                <span>الاستحواذ</span>
                                <span>${awayPoss}%</span>
                            </div>
                            <div class="progress stat-progress" style="background-color: #334155;">
                                <div class="progress-bar bg-primary" style="width: ${homePoss}%"></div>
                                <div class="progress-bar bg-danger" style="width: ${awayPoss}%"></div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-between border-bottom border-secondary py-2 text-light">
                            <span class="fw-bold">${st.home_shots || 0}</span>
                            <span class="text-white small">إجمالي التسديدات</span>
                            <span class="fw-bold">${st.away_shots || 0}</span>
                        </div>
                        <div class="d-flex justify-content-between border-bottom border-secondary py-2 text-light">
                            <span class="fw-bold">${st.home_shots_on_target || 0}</span>
                            <span class="text-white small">التسديدات على المرمى</span>
                            <span class="fw-bold">${st.away_shots_on_target || 0}</span>
                        </div>
                        <div class="d-flex justify-content-between py-2 text-light">
                            <span class="fw-bold">${st.home_corners || 0}</span>
                            <span class="text-white small">الركنيات</span>
                            <span class="fw-bold">${st.away_corners || 0}</span>
                        </div>
                    `;
                } else {
                    document.getElementById('team-stats-container').innerHTML = `<p class="text-white text-center py-3 mb-0">لا توجد إحصائيات مدخلة للمباراة بعد</p>`;
                }
            }
        })
        .catch(err => console.error('خطأ في استدعاء البيانات الحية:', err));
}

function fetchPredictionStats() {
    fetch(`predict.php?match_id=${matchId}`)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                document.getElementById('total-votes-count').innerText = data.total_votes || 0;
                
                let homeP = data.home_percent || 0;
                let drawP = data.draw_percent || 0;
                let awayP = data.away_percent || 0;

                document.getElementById('bar-home').style.width = homeP + '%';
                document.getElementById('bar-home').innerText = homeP + '%';

                document.getElementById('bar-draw').style.width = drawP + '%';
                document.getElementById('bar-draw').innerText = drawP + '%';

                document.getElementById('bar-away').style.width = awayP + '%';
                document.getElementById('bar-away').innerText = awayP + '%';

                document.getElementById('text-home-percent').innerText = homeP + '%';
                document.getElementById('text-draw-percent').innerText = drawP + '%';
                document.getElementById('text-away-percent').innerText = awayP + '%';
            }
        })
        .catch(err => console.error('خطأ في استدعاء التوقعات:', err));
}

// تنفيذ التحديث الأولي والربط بالتوقيت
refreshMatchLiveData();
fetchPredictionStats();
setInterval(refreshMatchLiveData, 10000);
</script>

<?php include 'footer.php'; ?>