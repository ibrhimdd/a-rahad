<?php 
include 'db.php'; 
include 'header.php'; 

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<div class='alert alert-danger text-center mt-5'>لم يتم تحديد لاعب.</div>";
    include 'footer.php'; exit;
}

$player_id = mysqli_real_escape_string($conn, $_GET['id']);
$tour_id = isset($_GET['tour_id']) && !empty($_GET['tour_id']) ? mysqli_real_escape_string($conn, $_GET['tour_id']) : null;
$tour_filter = $tour_id ? "AND m.tournament_id = $tour_id" : "";

// --- 1. جلب بيانات اللاعب الأساسية أولاً لمعرفة الفريق ---
$player = mysqli_fetch_assoc(mysqli_query($conn, "SELECT players.*, teams.team_name, teams.logo as team_logo FROM players JOIN teams ON players.team_id = teams.id WHERE players.id = $player_id"));
if (!$player) { 
    echo "<div class='alert alert-danger text-center mt-5'>اللاعب غير موجود.</div>"; 
    include 'footer.php'; exit; 
}

// --------------------------------------------------------------------------
// 🔐 التحقق من صلاحيات الإدارة (الأدمن العام + أدمن فريق هذا اللاعب المحدد)
// --------------------------------------------------------------------------
$is_super_admin = (isset($_SESSION['role']) && $_SESSION['role'] == 'admin');
$player_team_id = $player['team_id'];
$is_team_admin  = (isset($_SESSION['team_auth_' . $player_team_id]) && $_SESSION['team_auth_' . $player_team_id] === true);

// هل يحق له إدارة هذا اللاعب؟
$can_manage_player = ($is_super_admin || $is_team_admin);
// --------------------------------------------------------------------------

// --- 2. معالجة العمليات (حذف وتعديل) عند وجود الصلاحية ---
if ($can_manage_player) {
    if (isset($_POST['delete_player'])) {
        $team_id_redirect = $_POST['team_id_redirect'];
        mysqli_query($conn, "DELETE FROM players WHERE id = $player_id");
        echo "<script>alert('تم حذف اللاعب بنجاح'); window.location='team_profile.php?id=$team_id_redirect';</script>"; exit;
    }
    if (isset($_POST['update_player'])) {
        $p_name = mysqli_real_escape_string($conn, $_POST['player_name']);
        $p_pos = mysqli_real_escape_string($conn, $_POST['position']);
        $p_nat = mysqli_real_escape_string($conn, $_POST['nationality']);
        $p_shirt = !empty($_POST['shirt_number']) ? (int)$_POST['shirt_number'] : "NULL";

        if (!empty($_FILES['player_img']['name'])) {
            $img_name = time() . '_' . $_FILES['player_img']['name'];
            move_uploaded_file($_FILES['player_img']['tmp_name'], "uploads/players/" . $img_name);
            mysqli_query($conn, "UPDATE players SET image = '$img_name' WHERE id = $player_id");
        }
        
        mysqli_query($conn, "UPDATE players SET player_name = '$p_name', position = '$p_pos', nationality = '$p_nat', shirt_number = $p_shirt WHERE id = $player_id");
        echo "<script>window.location='player_profile.php?id=$player_id';</script>"; exit;
    }
}

// --- 3. إحصائيات اللاعب مع مراعاة فلتر البطولة ---
// الأهداف المسجلة
$goals_total = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM goals g JOIN matches m ON g.match_id = m.id WHERE g.player_id = $player_id $tour_filter"))['total'];
// الأسيست
$assists_total = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM goals g JOIN matches m ON g.match_id = m.id WHERE g.assist_player_id = $player_id $tour_filter"))['total'];
// إحصائيات المباريات (كروت، تقييم، عدد مباريات)
$match_stats = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(ps.yellow_cards) as y, SUM(ps.red_cards) as r, AVG(ps.rating) as avg, COUNT(ps.id) as m FROM player_match_stats ps JOIN matches m ON ps.match_id = m.id WHERE ps.player_id = $player_id $tour_filter"));
// عدد مرات رجل المباراة
$mvp_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM player_match_stats ps JOIN matches m ON ps.match_id = m.id WHERE ps.player_id = $player_id AND ps.is_mvp = 1 $tour_filter"))['total'];

$img = !empty($player['image']) ? $player['image'] : 'default_player.png';
$rating_avg = number_format($match_stats['avg'] ?? 0, 1);
?>

<style>
    body { direction: rtl; text-align: right; background-color: #121829; color: #ffffff; font-family: 'Cairo', sans-serif; }
    
    /* هيدر مطور */
    .p-header-box { 
        background: linear-gradient(135deg, #1a2238, #222b45);
        color: white; border-radius: 20px; padding: 40px; margin-top: 20px;
        display: flex; justify-content: space-between; align-items: center; position: relative; overflow: hidden;
        border: 1px solid rgba(255, 255, 255, 0.08);
    }
    .p-header-box::after {
        content: "BY:IBRAHIM ELKHOOLY";
        position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%) rotate(-15deg);
        font-size: 50px; font-weight: 900; color: rgba(255, 255, 255, 0.03); pointer-events: none;
    }

    /* كارت اللاعب FIFA Card */
    .fifa-card {
        width: 140px; background: url('https://sellyoursquad.com/assets/cards/gold_rare.png') no-repeat center;
        background-size: contain; padding: 15px; text-align: center; color: #4b3b08; position: relative;
    }
    .fifa-rating { font-size: 28px; font-weight: 900; line-height: 1; margin-top: 10px; }
    .fifa-pos { font-size: 12px; font-weight: bold; text-transform: uppercase; }
    .fifa-img { width: 85px; height: 85px; object-fit: cover; border-radius: 50%; margin: 5px 0; }

    /* فلتر البطولة */
    .tour-filter-box { 
        background: #1a2238; padding: 15px; border-radius: 12px; margin: 20px 0; 
        border: 1px solid rgba(255, 255, 255, 0.08); box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); 
    }
    .tour-filter-box select {
        background-color: #252e48; color: #ffffff; border: 1px solid rgba(255, 255, 255, 0.1);
    }
    .tour-filter-box select option { background-color: #1a2238; color: #ffffff; }

    /* التبويبات */
    .nav-tabs { border: none; margin-top: 30px; gap: 10px; }
    .nav-tabs .nav-link { 
        color: #a0aec0 !important; background-color: #1a2238 !important;
        border-radius: 12px !important; padding: 12px 25px; border: 1px solid rgba(255, 255, 255, 0.05) !important; font-weight: bold;
        transition: all 0.3s ease;
    }
    .nav-tabs .nav-link:hover { background-color: #252e48 !important; color: #ffffff !important; }
    .nav-tabs .nav-link.active { 
        background-color: #00d285 !important; color: #121829 !important; 
        box-shadow: 0 4px 15px rgba(0, 210, 133, 0.3); border: none !important;
    }

    .tab-content { 
        background: #1a2238; padding: 30px; border-radius: 20px; margin-top: 15px; 
        border: 1px solid rgba(255, 255, 255, 0.08); box-shadow: 0 10px 30px rgba(0,0,0,0.3); 
    }

    /* ميني كارد والإحصائيات المصغرة */
    .stat-mini-card { 
        background: #252e48; border-radius: 15px; padding: 20px; text-align: center; 
        transition: all 0.3s ease; border: 1px solid rgba(255, 255, 255, 0.08);
    }
    .stat-mini-card:hover { 
        transform: translateY(-5px); 
        border-color: #00d285 !important; 
        box-shadow: 0 8px 20px rgba(0, 210, 133, 0.15); 
    }
    .stat-mini-card i { font-size: 1.5rem; margin-bottom: 10px; color: #ffc107 !important; }
    .stat-mini-card h3 { color: #ffffff !important; font-size: 2.2rem; font-weight: 800; margin-bottom: 5px; }

    /* قسم الأوسمة */
    .achievement-badge {
        display: inline-flex; align-items: center; background: rgba(255, 193, 7, 0.15);
        border: 1px solid rgba(255, 193, 7, 0.4); padding: 5px 15px; border-radius: 50px;
        margin: 5px; font-size: 13px; font-weight: bold; color: #ffc107;
    }

    /* ألوان إدخالات النموذج للثيم الداكن */
    .form-control {
        background-color: #252e48 !important; color: #ffffff !important;
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
    }
    .form-control:focus {
        border-color: #00d285 !important; box-shadow: 0 0 10px rgba(0, 210, 133, 0.2) !important;
    }
    .form-label { color: #e2e8f0; font-weight: 600; }

    /* الجداول للثيم الداكن */
    .table { color: #ffffff !important; border-color: rgba(255, 255, 255, 0.08) !important; }
    .table th, .table td { border-color: rgba(255, 255, 255, 0.05) !important; color: #ffffff !important; }
    .table-hover tbody tr:hover td { background-color: #252e48 !important; }
</style>

<div class="container">
    <div class="p-header-box shadow-lg">
        <div class="p-info-right">
            <div class="d-flex align-items-center gap-3 mb-3">
                <img src="uploads/logos/<?php echo $player['team_logo']; ?>" width="60" class="bg-white rounded-circle p-1 shadow">
                <div>
                    <h1 class="fw-black m-0 text-white"><?php echo $player['player_name']; ?></h1>
                    <span class="text-warning fw-bold fs-5"><?php echo $player['team_name']; ?></span>
                </div>
            </div>
            
            <div class="d-flex gap-2 flex-wrap mb-4">
                <?php if(!empty($player['shirt_number'])): ?>
                    <div class="achievement-badge" style="background: rgba(2, 136, 209, 0.15); border-color: rgba(129, 212, 250, 0.4); color: #81d4fa;">
                        <i class="fas fa-tshirt me-1"></i> رقم القميص: #<?php echo $player['shirt_number']; ?>
                    </div>
                <?php endif; ?>
                
                <div class="achievement-badge"><i class="fas fa-running me-1"></i> المركز: <?php echo $player['position']; ?></div>
                <div class="achievement-badge"><i class="fas fa-globe me-1"></i> <?php echo !empty($player['nationality']) ? $player['nationality'] : 'غير محدد'; ?></div>
                <div class="achievement-badge" style="background: rgba(46, 125, 50, 0.2); border-color: rgba(165, 214, 165, 0.4); color: #00d285;">
                    <i class="fas fa-star me-1"></i> متوسط التقييم: <?php echo $rating_avg; ?>
                </div>
                <?php if($mvp_count > 0): ?>
                    <div class="achievement-badge" style="background: rgba(13, 71, 161, 0.2); color: #64b5f6; border-color: rgba(187, 222, 251, 0.4);">
                        <i class="fas fa-crown me-1"></i> رجل المباراة: <?php echo $mvp_count; ?>
                    </div>
                <?php endif; ?>
                <?php if($goals_total >= 10): ?>
                    <div class="achievement-badge" style="background: rgba(216, 67, 21, 0.2); color: #ff8a65; border-color: rgba(255, 204, 188, 0.4);">
                        <i class="fas fa-fire me-1"></i> هداف بالفطرة
                    </div>
                <?php endif; ?>
            </div>

            <div class="d-flex gap-4">
                <div class="text-center"><h4 class="m-0 fw-bold text-white"><?php echo $match_stats['m'] ?: 0; ?></h4><small class="text-white-50">مباراة</small></div>
                <div class="vr bg-secondary"></div>
                <div class="text-center"><h4 class="m-0 fw-bold text-white"><?php echo $goals_total; ?></h4><small class="text-white-50">هدف</small></div>
                <div class="vr bg-secondary"></div>
                <div class="text-center"><h4 class="m-0 fw-bold text-white"><?php echo $assists_total; ?></h4><small class="text-white-50">أسيست</small></div>
            </div>
        </div>

        <div class="p-img-left d-none d-md-block">
            <div class="fifa-card shadow-lg">
                <div class="fifa-rating"><?php echo (int)($rating_avg * 10); ?></div>
                <div class="fifa-pos">
                    <?php echo substr($player['position'], 0, 3); ?> 
                    <?php echo !empty($player['shirt_number']) ? ' | #' . $player['shirt_number'] : ''; ?>
                </div>
                <img src="uploads/players/<?php echo $img; ?>" class="fifa-img">
            </div>
        </div>
    </div>

    <!-- فلتر البطولة -->
    <div class="tour-filter-box d-flex justify-content-between align-items-center">
        <h6 class="m-0 fw-bold text-white"><i class="fas fa-filter ms-1 text-warning"></i> عرض الإحصائيات حسب البطولة:</h6>
        <select class="form-select form-select-sm w-auto" onchange="location.href='player_profile.php?id=<?php echo $player_id; ?>&tour_id=' + this.value;">
            <option value="">كل البطولات</option>
            <?php 
            $tours_query = mysqli_query($conn, "SELECT DISTINCT t.id, t.name FROM tournaments t 
                                                 JOIN matches m ON t.id = m.tournament_id 
                                                 JOIN player_match_stats ps ON m.id = ps.match_id 
                                                 WHERE ps.player_id = $player_id");
            while($t = mysqli_fetch_assoc($tours_query)): ?>
                <option value="<?php echo $t['id']; ?>" <?php echo ($tour_id == $t['id']) ? 'selected' : ''; ?>><?php echo $t['name']; ?></option>
            <?php endwhile; ?>
        </select>
    </div>

    <ul class="nav nav-tabs justify-content-center" id="playerTabs">
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#statsTab">📊 الأرقام والنمو</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#matchesTab">⚽ سجل المشاركات</button></li>
        
        <?php if($can_manage_player): ?>
            <li class="nav-item"><button class="nav-link text-danger" data-bs-toggle="tab" data-bs-target="#adminTab">⚙️ الإدارة</button></li>
        <?php endif; ?>
    </ul>

    <div class="tab-content mb-5">
        <div class="tab-pane fade show active" id="statsTab">
            <div class="row g-4">
                <div class="col-6 col-md-3">
                    <div class="stat-mini-card">
                        <i class="fas fa-ban text-danger"></i>
                        <h3><?php echo $match_stats['r'] ?: 0; ?></h3>
                        <p class="text-white-50 m-0 small fw-bold">بطاقات حمراء</p>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-mini-card">
                        <i class="fas fa-bullseye text-danger"></i>
                        <h3><?php echo $goals_total; ?></h3>
                        <p class="text-white-50 m-0 small fw-bold">إجمالي الأهداف</p>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-mini-card">
                        <i class="fas fa-hands-helping text-primary"></i>
                        <h3><?php echo $assists_total; ?></h3>
                        <p class="text-white-50 m-0 small fw-bold">صناعة أهداف</p>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-mini-card">
                        <i class="fas fa-copy text-warning"></i>
                        <h3><?php echo $match_stats['y'] ?: 0; ?></h3>
                        <p class="text-white-50 m-0 small fw-bold">بطاقات صفراء</p>
                    </div>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-12">
                    <div class="p-4 border border-secondary border-opacity-25 rounded-4 style-chart-box shadow-sm" style="background-color: #252e48;">
                        <h5 class="fw-bold mb-4 text-white d-flex align-items-center">
                            <i class="fas fa-chart-line me-2 text-warning"></i> مستوى اللاعب في آخر 10 مباريات
                        </h5>
                        <canvas id="performanceChart" style="max-height: 300px;"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="tab-pane fade" id="matchesTab">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr style="background-color: #252e48;">
                            <th class="border-0 text-white">المباراة</th>
                            <th class="border-0 text-center text-white">الأداء</th>
                            <th class="border-0 text-center text-white">أهداف/أسيست</th>
                            <th class="border-0 text-center text-white">التقييم</th>
                            <th class="border-0 text-center text-white">التاريخ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $matches_q = mysqli_query($conn, "SELECT m.*, ps.rating, ps.is_mvp, t1.team_name as home, t2.team_name as away,
                                                                    (SELECT COUNT(*) FROM goals WHERE player_id = $player_id AND match_id = m.id) as g,
                                                                    (SELECT COUNT(*) FROM goals WHERE assist_player_id = $player_id AND match_id = m.id) as a
                                                                    FROM matches m 
                                                                    JOIN player_match_stats ps ON m.id = ps.match_id 
                                                                    JOIN teams t1 ON m.team_home_id = t1.id 
                                                                    JOIN teams t2 ON m.team_away_id = t2.id
                                                                    WHERE ps.player_id = $player_id $tour_filter 
                                                                    ORDER BY m.match_date DESC LIMIT 10");
                        
                        $chart_labels = []; $chart_data = [];
                        while($row = mysqli_fetch_assoc($matches_q)): 
                            $chart_labels[] = date('d/m', strtotime($row['match_date']));
                            $chart_data[] = $row['rating'];
                            $vs_team = ($row['home'] == $player['team_name']) ? $row['away'] : $row['home'];
                        ?>
                        <tr onclick="window.location='match_details.php?id=<?php echo $row['id']; ?>'" style="cursor: pointer;">
                            <td>
                                <div class="fw-bold text-white">ضد <?php echo $vs_team; ?></div>
                                <?php if($row['is_mvp']): ?><span class="badge bg-warning text-dark small"><i class="fas fa-crown"></i> MVP</span><?php endif; ?>
                            </td>
                            <td class="text-center">
                                <div class="progress" style="height: 6px; width: 80px; margin: 0 auto; background-color: #121829;">
                                    <div class="progress-bar bg-success" style="width: <?php echo ($row['rating']*10); ?>%"></div>
                                </div>
                            </td>
                            <td class="text-center">
                                <span class="badge rounded-pill bg-success-subtle text-success px-3"><?php echo $row['g']; ?>G</span>
                                <span class="badge rounded-pill bg-info-subtle text-info px-3"><?php echo $row['a']; ?>A</span>
                            </td>
                            <td class="text-center fw-black text-warning fs-5"><?php echo $row['rating']; ?></td>
                            <td class="text-center text-white-50 small"><?php echo date('Y-m-d', strtotime($row['match_date'])); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if($can_manage_player): ?>
        <div class="tab-pane fade" id="adminTab">
            <div class="row g-4">
                <div class="col-md-7 border-start border-secondary border-opacity-25">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="fw-bold m-0 text-white">تحديث البيانات الأساسية</h5>
                        <span class="badge bg-secondary">
                            <?php echo $is_super_admin ? 'أدمن عام' : 'أدمن فريق ' . $player['team_name']; ?>
                        </span>
                    </div>
                    <form method="POST" enctype="multipart/form-data">
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">الاسم الكامل</label>
                                <input type="text" name="player_name" class="form-control" value="<?php echo $player['player_name']; ?>" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">رقم القميص</label>
                                <input type="number" name="shirt_number" class="form-control" min="1" max="99" value="<?php echo $player['shirt_number'] ?? ''; ?>" placeholder="مثال: 10">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">المركز</label>
                                <input type="text" name="position" class="form-control" value="<?php echo $player['position']; ?>" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">الجنسية</label>
                                <input type="text" name="nationality" class="form-control" value="<?php echo $player['nationality']; ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label">تغيير الصورة الشخصية</label>
                                <input type="file" name="player_img" class="form-control">
                            </div>
                            <div class="col-12 pt-3">
                                <button type="submit" name="update_player" class="btn btn-primary w-100 fw-bold rounded-pill p-2" style="background-color: #00d285; border: none; color: #121829;">تحديث الملف</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-5">
                    <div class="alert alert-danger rounded-4 h-100 d-flex flex-column align-items-center justify-content-center text-center" style="background-color: rgba(220, 53, 69, 0.1); border-color: rgba(220, 53, 69, 0.3); color: #ff6b6b;">
                        <i class="fas fa-exclamation-triangle fa-3x mb-3"></i>
                        <h5 class="fw-bold">منطقة الخطر</h5>
                        <p class="small text-white-50">حذف اللاعب سيؤدي لمسح إحصائياته من كافة المباريات السابقة.</p>
                        <form method="POST" onsubmit="return confirm('هل أنت متأكد من الحذف النهائي؟');">
                            <input type="hidden" name="team_id_redirect" value="<?php echo $player['team_id']; ?>">
                            <button type="submit" name="delete_player" class="btn btn-danger rounded-pill px-5 fw-bold">حذف اللاعب نهائياً</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('performanceChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_reverse($chart_labels)); ?>,
            datasets: [{
                label: 'التقييم الفني',
                data: <?php echo json_encode(array_reverse($chart_data)); ?>,
                borderColor: '#00d285', // خط رسم تركواز مضيء
                backgroundColor: 'rgba(0, 210, 133, 0.1)',
                fill: true, tension: 0.4, pointRadius: 5, pointBackgroundColor: '#ffc107', borderWidth: 3
            }]
        },
        options: { 
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { 
                y: { 
                    min: 0, max: 10, position: 'right', 
                    grid: { color: 'rgba(255, 255, 255, 0.05)' },
                    ticks: { color: '#a0aec0' }
                },
                x: { 
                    grid: { display: false },
                    ticks: { color: '#a0aec0' }
                }
            }
        }
    });
</script>

<?php include 'footer.php'; ?>