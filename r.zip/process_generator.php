<?php
include 'db.php';

if (isset($_POST['generate'])) {
    $tournament_id = $_POST['tournament_id'];
    $teams = $_POST['teams'];

    if (count($teams) < 2) {
        die("يجب اختيار فريقين على الأقل.");
    }

    // إذا كان عدد الفرق فردياً، نضيف فريق "وهمي" للاستراحة
    if (count($teams) % 2 != 0) {
        $teams[] = "BYE"; 
    }

    $num_teams = count($teams);
    $rounds = $num_teams - 1;
    $matches_per_round = $num_teams / 2;

    for ($i = 0; $i < $rounds; $i++) {
        for ($j = 0; $j < $matches_per_round; $j++) {
            $home = $teams[$j];
            $away = $teams[$num_teams - 1 - $j];

            if ($home !== "BYE" && $away !== "BYE") {
                // إدخال المباراة ببيانات "يحدد لاحقاً"
                $sql = "INSERT INTO matches (tournament_id, team_home_id, team_away_id, status, referee, commentator) 
                        VALUES ('$tournament_id', '$home', '$away', 'upcoming', 'يحدد لاحقاً', 'يحدد لاحقاً')";
                mysqli_query($conn, $sql);
            }
        }
        // تدوير الفرق (Logic لضمان عدم التكرار)
        $last_team = array_pop($teams);
        array_splice($teams, 1, 0, [$last_team]);
    }

    header("Location: matches.php?success=1");
    exit();
}
?>