<?php include 'db.php'; include 'header.php'; 

$t_id = $_GET['id']; // رقم البطولة

// جلب اسم البطولة
$t_name_query = mysqli_query($conn, "SELECT name FROM tournaments WHERE id = $t_id");
$t_name = mysqli_fetch_assoc($t_name_query)['name'];
?>

<div class="container mt-4">
    <h2 class="text-center mb-5 fw-bold"><i class="fas fa-chart-line text-danger"></i> إحصائيات <?php echo $t_name; ?></h2>

    <div class="row">
        <div class="col-lg-12 mb-5">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-dark text-white py-3">
                    <h5 class="mb-0"><i class="fas fa-list-ol"></i> جدول ترتيب الفرق</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle text-center mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th>الترتيب</th>
                                <th class="text-start">الفريق</th>
                                <th>لعب</th>
                                <th>فوز</th>
                                <th>تعادل</th>
                                <th>خسارة</th>
                                <th>له</th>
                                <th>عليه</th>
                                <th>النقاط</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // استعلام ذكي لحساب النقاط والأهداف تلقائياً من جدول المباريات
                            $teams_sql = "
                                SELECT t.id, t.team_name, t.logo,
                                COUNT(m.id) as played,
                                SUM(CASE WHEN (m.team_home_id = t.id AND m.score_home > m.score_away) OR (m.team_away_id = t.id AND m.score_away > m.score_home) THEN 1 ELSE 0 END) as wins,
                                SUM(CASE WHEN m.score_home = m.score_away THEN 1 ELSE 0 END) as draws,
                                SUM(CASE WHEN (m.team_home_id = t.id AND m.score_home < m.score_away) OR (m.team_away_id = t.id AND m.score_away < m.score_home) THEN 1 ELSE 0 END) as loss,
                                SUM(CASE WHEN m.team_home_id = t.id THEN m.score_home ELSE m.score_away END) as goals_for,
                                SUM(CASE WHEN m.team_home_id = t.id THEN m.score_away ELSE m.score_home END) as goals_against
                                FROM teams t
                                JOIN tournament_teams tt ON t.id = tt.team_id
                                LEFT JOIN matches m ON (t.id = m.team_home_id OR t.id = m.team_away_id) 
                                     AND m.tournament_id = $t_id AND m.status = 'finished'
                                WHERE tt.tournament_id = $t_id
                                GROUP BY t.id
                                ORDER BY (wins*3 + draws) DESC, (goals_for - goals_against) DESC";
                            
                            $res = mysqli_query($conn, $teams_sql);
                            $rank = 1;
                            while($row = mysqli_fetch_assoc($res)) {
                                $points = ($row['wins'] * 3) + $row['draws'];
                                echo "<tr>
                                    <td><span class='badge bg-secondary rounded-circle'>$rank</span></td>
                                    <td class='text-start fw-bold'>
                                        <img src='uploads/logos/{$row['logo']}' width='30' class='me-2'> {$row['team_name']}
                                    </td>
                                    <td>{$row['played']}</td>
                                    <td class='text-success'>{$row['wins']}</td>
                                    <td>{$row['draws']}</td>
                                    <td class='text-danger'>{$row['loss']}</td>
                                    <td>{$row['goals_for']}</td>
                                    <td>{$row['goals_against']}</td>
                                    <td class='bg-light fw-bold text-primary'>$points</td>
                                </tr>";
                                $rank++;
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-success text-white py-3">
                    <h5 class="mb-0"><i class="fas fa-fire"></i> هدافو البطولة</h5>
                </div>
                <ul class="list-group list-group-flush">
                    <?php
                    $scorers = mysqli_query($conn, "
                        SELECT p.player_name, p.id, t.team_name, COUNT(g.id) as goals_count
                        FROM players p
                        JOIN goals g ON p.id = g.player_id
                        JOIN matches m ON g.match_id = m.id
                        JOIN teams t ON p.team_id = t.id
                        WHERE m.tournament_id = $t_id
                        GROUP BY p.id ORDER BY goals_count DESC LIMIT 5");
                    
                    while($s = mysqli_fetch_assoc($scorers)) {
                        echo "<li class='list-group-item d-flex justify-content-between align-items-center'>
                            <div>
                                <a href='player_profile.php?id={$s['id']}' class='text-decoration-none fw-bold text-dark'>{$s['player_name']}</a>
                                <div class='small text-muted'>{$s['team_name']}</div>
                            </div>
                            <span class='badge bg-success rounded-pill fs-6'>{$s['goals_count']} أهداف</span>
                        </li>";
                    } ?>
                </ul>
            </div>
        </div>

        <div class="col-md-6 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-primary text-white py-3">
                    <h5 class="mb-0"><i class="fas fa-magic"></i> ملوك الأسيست</h5>
                </div>
                <ul class="list-group list-group-flush">
                    <?php
                    $assisters = mysqli_query($conn, "
                        SELECT p.player_name, p.id, t.team_name, COUNT(g.id) as assist_count
                        FROM players p
                        JOIN goals g ON p.id = g.assist_player_id
                        JOIN matches m ON g.match_id = m.id
                        JOIN teams t ON p.team_id = t.id
                        WHERE m.tournament_id = $t_id
                        GROUP BY p.id ORDER BY assist_count DESC LIMIT 5");
                    
                    while($a = mysqli_fetch_assoc($assisters)) {
                        echo "<li class='list-group-item d-flex justify-content-between align-items-center'>
                            <div>
                                <a href='player_profile.php?id={$a['id']}' class='text-decoration-none fw-bold text-dark'>{$a['player_name']}</a>
                                <div class='small text-muted'>{$a['team_name']}</div>
                            </div>
                            <span class='badge bg-primary rounded-pill fs-6'>{$a['assist_count']} أسيست</span>
                        </li>";
                    } ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>