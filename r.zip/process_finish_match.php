<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $match_id = (int)$_POST['match_id'];
    $mvp_id = isset($_POST['mvp']) ? (int)$_POST['mvp'] : 0;
    
    // 1. جلب بيانات المباراة لمعرفة الفرق الأساسية
    $m_info = mysqli_fetch_assoc(mysqli_query($conn, "SELECT team_home_id, team_away_id FROM matches WHERE id = $match_id"));
    $home_id = $m_info['team_home_id'];
    $away_id = $m_info['team_away_id'];

    $score_home = 0;
    $score_away = 0;

    // تنظيف البيانات القديمة للمباراة (للسماح بتعديل النتيجة دون تكرار)
    mysqli_query($conn, "DELETE FROM goals WHERE match_id = $match_id");
    mysqli_query($conn, "DELETE FROM player_match_stats WHERE match_id = $match_id");

    // 2. تسجيل الأهداف وحساب النتيجة النهائية
    if (isset($_POST['goal_player'])) {
        foreach ($_POST['goal_player'] as $key => $player_id) {
            if(empty($player_id)) continue;

            $assist_id = (int)$_POST['assist_player'][$key];
            $minute = (int)$_POST['goal_minute'][$key];
            
            // تحديد فريق اللاعب المسجل لتحديث النتيجة التلقائية
            $p_info = mysqli_fetch_assoc(mysqli_query($conn, "SELECT team_id FROM players WHERE id = $player_id"));
            if ($p_info['team_id'] == $home_id) $score_home++;
            else $score_away++;

            // إدخال في جدول goals
            mysqli_query($conn, "INSERT INTO goals (match_id, player_id, assist_player_id, goal_minute) 
                                VALUES ($match_id, $player_id, $assist_id, $minute)");
        }
    }

    // 3. تحديث تقييمات اللاعبين والبطاقات (هنا كان الخطأ)
    if (isset($_POST['rating'])) {
        foreach ($_POST['rating'] as $p_id => $rating_val) {
            $p_id = (int)$p_id;
            $card_type = $_POST['cards'][$p_id]; 
            $is_mvp = ($p_id == $mvp_id) ? 1 : 0;
            
            // تحويل البطاقات لأرقام عشان صفحة البروفايل تجمعهم صح
            $yellow = ($card_type == 'yellow') ? 1 : 0;
            $red = ($card_type == 'red') ? 1 : 0;
            
            // التأكد من أن التقييم رقم عشري (مثلاً 7.5) وليس نصاً
            $rating_val = (!empty($rating_val) && is_numeric($rating_val)) ? (float)$rating_val : 0.0;

            // إدخال البيانات في جدول الإحصائيات
            // ملاحظة: تأكد أن الأعمدة في جدولك اسمها yellow_cards و red_cards
            $query_stats = "INSERT INTO player_match_stats (match_id, player_id, rating, yellow_cards, red_cards, is_mvp) 
                            VALUES ($match_id, $p_id, $rating_val, $yellow, $red, $is_mvp)";
            
            mysqli_query($conn, $query_stats);
        }
    }

    // 4. التحديث النهائي لجدول matches لإغلاق المباراة
    $update_match = "UPDATE matches SET 
                        score_home = $score_home, 
                        score_away = $score_away, 
                        status = 'finished', 
                        is_finished = 1 
                    WHERE id = $match_id";
    
    if(mysqli_query($conn, $update_match)) {
        // العودة لجدول المباريات عند النجاح
        header("Location: matches.php?status=success");
        exit();
    } else {
        echo "خطأ في التحديث: " . mysqli_error($conn);
    }
}