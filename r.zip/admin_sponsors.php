<?php
include 'db.php';
include 'header.php';

// التأكد من أن المستخدم مسؤول (Admin)
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo "<div class='container py-5'><div class='alert alert-danger text-center'>غير مصرح لك بالوصول لهذه الصفحة.</div></div>";
    include 'footer.php';
    exit;
}

// إضافة معلن جديد
if (isset($_POST['add_sponsor'])) {
    $title = trim($_POST['title']);
    $link = trim($_POST['link']);
    if (!empty($title)) {
        $stmt = $conn->prepare("INSERT INTO sponsors (title, link) VALUES (?, ?)");
        $stmt->bind_param("ss", $title, $link);
        $stmt->execute();
        $stmt->close();
        echo "<script>window.location.href='admin_sponsors.php';</script>";
    }
}

// حذف معلن
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM sponsors WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    echo "<script>window.location.href='admin_sponsors.php';</script>";
}

// تغيير حالة التفعيل (نشط / غير نشط)
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $stmt = $conn->prepare("UPDATE sponsors SET is_active = NOT is_active WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    echo "<script>window.location.href='admin_sponsors.php';</script>";
}

// جلب كل الرعاة
$sponsors = $conn->query("SELECT * FROM sponsors ORDER BY id DESC");
?>

<div class="container py-4">
    <h3 class="fw-bold mb-4 text-primary"><i class="fas fa-ad me-2"></i>إدارة الرعاة والمعلنين</h3>

    <!-- نموذج إضافة معلن -->
    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body p-4">
            <h5 class="fw-bold mb-3">إضافة معلن جديد</h5>
            <form action="" method="POST" class="row g-3">
                <div class="col-md-6">
                    <label class="form-label fw-bold">اسم المعلن / النص</label>
                    <input type="text" name="title" class="form-control" placeholder="مثال: راعي البطولة - شركة X" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold">رابط الموقع / الصفحة (اختياري)</label>
                    <input type="url" name="link" class="form-control" placeholder="https://example.com">
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" name="add_sponsor" class="btn btn-primary w-100 fw-bold">إضافة</button>
                </div>
            </form>
        </div>
    </div>

    <!-- قائمة الرعاة الحاليين -->
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle text-center mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>النص / اسم المعلن</th>
                        <th>الرابط</th>
                        <th>الحالة</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($sponsors->num_rows > 0): ?>
                        <?php while($row = $sponsors->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td class="fw-bold"><?php echo htmlspecialchars($row['title']); ?></td>
                            <td><a href="<?php echo htmlspecialchars($row['link']); ?>" target="_blank" class="text-decoration-none"><?php echo htmlspecialchars($row['link']); ?></a></td>
                            <td>
                                <a href="?toggle=<?php echo $row['id']; ?>" class="badge text-decoration-none <?php echo $row['is_active'] ? 'bg-success' : 'bg-secondary'; ?>">
                                    <?php echo $row['is_active'] ? 'نشط' : 'معطل'; ?>
                                </a>
                            </td>
                            <td>
                                <a href="?delete=<?php echo $row['id']; ?>" onclick="return confirm('هل أنت تأكد من الحذف؟')" class="btn btn-danger btn-sm">
                                    <i class="fas fa-trash"></i> حذف
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="py-4 text-muted">لا يوجد معلنين حالياً.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>